Apache HttpComponents Core
==========================
Welcome to the HttpCore component of the HttpComponents project.

Visit the project site at
   http://hc.apache.org/
for more information.

