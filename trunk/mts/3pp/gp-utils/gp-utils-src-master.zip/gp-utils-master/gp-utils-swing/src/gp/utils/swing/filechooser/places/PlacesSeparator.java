/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gp.utils.swing.filechooser.places;

/**
 *
 * @author gpasquiers
 */
public class PlacesSeparator {

}
