
package org.mobicents.servlet.sip.example;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.sip.Address;
import javax.servlet.sip.ServletTimer;
import javax.servlet.sip.SipApplicationSession;
import javax.servlet.sip.SipFactory;
import javax.servlet.sip.SipServlet;
import javax.servlet.sip.SipServletRequest;
import javax.servlet.sip.SipServletResponse;
import javax.servlet.sip.SipSession;
import javax.servlet.sip.SipURI;
import javax.servlet.sip.TimerListener;
import javax.servlet.sip.TimerService;
import javax.servlet.sip.SipSession.State;

import net.java.stun4j.stack.StunStack;

import org.apache.log4j.Logger;

/**
 * This example shows a simple User agent that can any accept call and reply to BYE or initiate BYE 
 * depending on the sender.
 * 
 * @author Jean Deruelle
 *
 */
public class SimpleSipServlet extends SipServlet{
	private static Logger logger = Logger.getLogger(SimpleSipServlet.class);
	public SimpleSipServlet() {
	}
	
	  private static final String CONTACT_HEADER = "Contact";
	   private SipFactory sipFactory;

	
	   @Override
       public void init(ServletConfig servletConfig) throws ServletException {
               super.init(servletConfig);
               logger.info("the simple sip servlet has been started");
               try {                   
                       // Getting the Sip factory from the JNDI Context
                       Properties jndiProps = new Properties();                        
                       Context initCtx = new InitialContext(jndiProps);
                       Context envCtx = (Context) initCtx.lookup("java:comp/env");
                       sipFactory = (SipFactory) envCtx.lookup("sip/org.mobicents.servlet.sip.example.SimpleApplication/SipFactory");
                       logger.info("Sip Factory ref from JNDI : " + sipFactory);
               } catch (NamingException e) {
                       throw new ServletException("Uh oh -- JNDI problem !", e);                       
               }
       }

	protected void doRegister(SipServletRequest req) throws ServletException, IOException {
        logger.info("Received register request: " + req.getTo());
        int response = SipServletResponse.SC_OK;
        SipServletResponse resp = req.createResponse(response);
        HashMap<String, String> users = (HashMap<String, String>) getServletContext().getAttribute("registeredUsersMap");
        if(users == null) users = new HashMap<String, String>();
        getServletContext().setAttribute("registeredUsersMap", users);
        
        Address address = req.getAddressHeader(CONTACT_HEADER);
        String fromURI = req.getFrom().getURI().toString();
        
        int expires = address.getExpires();
        if(expires < 0) {
                expires = req.getExpires();
        }
        if(expires == 0) {
                users.remove(fromURI);
                logger.info("User " + fromURI + " unregistered");
        } else {
                resp.setAddressHeader(CONTACT_HEADER, address);
                users.put(fromURI, address.getURI().toString());
                logger.info("User " + fromURI + 
                                " registered with an Expire time of " + expires);
        }                               
                                        
        resp.send();
}


	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void doResponse(SipServletResponse resp) throws
    javax.servlet.
ServletException,java.io.IOException{
    int status = resp.getStatus();
    
	logger.info("Simple Servlet: Got response:\n");
        if (status == SipServletResponse.SC_OK)
        {
        	logger.info("Simple Servlet: Got response SC_OK:\n");
         }
}
	protected void doInvite(SipServletRequest request) throws ServletException,	IOException 
	{ 
 		Integer audioPortInt=0;
		Integer videoPortInt=0;
		RTSPStack rtsp=null;
	  	if(logger.isInfoEnabled()) {logger.info("Simple Servlet: Got request:\n" + request.getMethod());}
	  	rtsp = new RTSPStack();
    	String rtspParameter = request.getTo().getURI().getParameter("rtsp");
    	rtsp.uri="rtsp://10.0.0.2/sample_h264_amr_100kbit.3g2";
 	 	request.getSession().setAttribute("rtsp", rtsp);
	 	String callerSipPhoneDSP = new String((byte[])request.getContent());
  	 	String videoSdp = callerSipPhoneDSP.substring(callerSipPhoneDSP.indexOf("video ") + "video ".length());
		String videoPort = videoSdp.split(" ")[0];	
		videoPortInt = Integer.parseInt(videoPort);
		videoPort = videoPortInt.toString() + "-" + (videoPortInt+1);
 		String audioSdp = callerSipPhoneDSP.substring(callerSipPhoneDSP.indexOf("audio ") + "audio ".length());
		String audioPort = audioSdp.split(" ")[0];
		audioPortInt = Integer.parseInt(audioPort);
		audioPort = audioPortInt.toString() + "-" + (audioPortInt+1);
	 
		rtsp.audioPort = audioPortInt + "-" + (audioPortInt+1);
		rtsp.videoPort = videoPortInt + "-" + (videoPortInt+1);
		
		if(logger.isInfoEnabled()) 
		{
			logger.info("Extracted audio and video ports: " + audioPort + "/" + videoPort);
		}

		logger.info("Now forwarding");
     	rtsp.addRTPMapper(new RTPPacketForwarder("10.0.0.2", request.getRemoteHost(), audioPortInt, audioPortInt, (byte)9));
    	rtsp.addRTPMapper(new RTPPacketForwarder("10.0.0.2", request.getRemoteHost(), videoPortInt, videoPortInt, (byte)109));
 
 		SipServletResponse sipServletResponse = request.createResponse(	SipServletResponse.SC_RINGING);
		sipServletResponse.send();
       	rtsp.init();
    		
    	 	try
    	 	{
    			for(int q=0;q<5000;) {	Thread.sleep(q+=200);if(rtsp.sdp != null) break;}
    		} 
    	 	catch (Exception e) 
    	 	{
    			throw new RuntimeException("Problem retrieving SDP from RTSP server", e);
    		}
    		sipServletResponse = request.createResponse(SipServletResponse.SC_OK);
    	 	if (rtsp.sdp!=null)
    	 	{
    	 		rtsp.sdp =rtsp.sdp.replace("127.0.0.1", "10.0.0.2");
    	  		rtsp.sdp = rtsp.sdp.replaceAll("rtpmap:97 AMR/8000/1","rtpmap:9 G722/8000/1");
    			rtsp.sdp = rtsp.sdp.replaceAll("a=rtpmap:96 H264/90000","rtpmap:109 h264/90000");
    			rtsp.sdp = rtsp.sdp.replaceAll("97","9");
    			rtsp.sdp = rtsp.sdp.replaceAll("96","109");

    			rtsp.sdp = rtsp.sdp.replaceAll("profile-level-id=42C033" ,"profile-level-id=42C01E");
    			rtsp.sdp = rtsp.sdp.replaceAll("packetization-mode=1;" ,"packetization-mode=1");
    			rtsp.sdp = rtsp.sdp.replaceAll("sprop-parameter-sets=Z0LAM6tBYnQgAAADACAAAAMD0eMGVA==,aM48gA==","");
    			
    			rtsp.sdp = rtsp.sdp.replaceAll("a=fmtp:9 octet-align","a=fmtp:101 0-16,32,36");
    			rtsp.sdp = rtsp.sdp.replaceAll("RTP/AVP 9","RTP/AVP 9 101");
    	 	 	
    			rtsp.sdp= rtsp.sdp.replaceAll("video 0", "video "+videoPortInt);
    			rtsp.sdp =rtsp.sdp.replaceAll("audio 0", "audio "+audioPortInt);
    	 	}
     		sipServletResponse.setContent(rtsp.sdp, "application/sdp");
     		logger.info("Now sending SDP :"+rtsp.sdp);
    		sipServletResponse.send();

     		
 	}

	   @Override
	    protected void doSuccessResponse(SipServletResponse resp)
	                        throws ServletException, IOException 
	                        {
		   int status = resp.getStatus();
		    
			logger.info("Simple Servlet: Got sresponse:\n");
		        if (status == SipServletResponse.SC_OK)
		        {
		        	logger.info("Simple Servlet: Got sresponse SC_OK:\n");
		         }
	   }
	/**
	 * {@inheritDoc}
	 */
	protected void doBye(SipServletRequest request) throws ServletException,
			IOException {
		if(logger.isInfoEnabled()) {
			logger.info("Got BYE request:\n" + request);
		}
		SipServletResponse sipServletResponse = request.createResponse(200);
		sipServletResponse.send();
		RTSPStack rtsp = (RTSPStack) request.getSession().getAttribute("rtsp");
		try {
			rtsp.sendTeardown();
			Thread.sleep(1000);
			rtsp.destroy();
		} catch (Exception e) {
			logger.error("Problem cleaning up RTSP stack", e);
		}
		
	}
}