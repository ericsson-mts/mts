m=0 
n=1
firstImpu=33960300000
firstPort=20000
lastPort=60000
indexImpu=0
port=0
file=new.csv

echo "inviter;NumberPhone;privateIp;publicIp;portNumber" >$file
while [ "$indexImpu" -le 69999 ]
do
	p=`expr $indexImpu + $firstImpu`
	privIP=172.16.$m.$n
	publicIP=172.21.$m.$n
	currentport=`expr $port + $firstPort`
	n=`expr $n + 1`
	if [ "$n" = "254" ]; then
 		n=1
		m=`expr $m + 1`
	fi
	if [ "$currentport" = "60000" ]; then
 		port=0
	fi
        port=`expr $port + 1`
	echo "+$p;$p;$privIP;$publicIP;$currentport">>$file
	indexImpu=`expr $indexImpu + 1`
done
