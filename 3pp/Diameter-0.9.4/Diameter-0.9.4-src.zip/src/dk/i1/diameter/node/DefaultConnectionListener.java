package dk.i1.diameter.node;

class DefaultConnectionListener implements ConnectionListener {
	public void handle(ConnectionKey connkey, Peer peer, boolean up) {
	}
}
