package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public class BERNull extends BERElement
{
    /**  */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new BERNull object.
     */
    public BERNull()
    {
        //TODO Rien
    }

    /**
     * Creates a new BERNull object.
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERNull(InputStream stream, int[] bytes_read)
    throws IOException
    {
        BERElement.readLengthOctets(stream, bytes_read);
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public void write(OutputStream stream) throws IOException
    {
        byte[] buffer = new byte[2];
        buffer[0] = 5;
        buffer[1] = 0;
        stream.write(buffer);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return 5;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        return "Null {}";
    }
}
