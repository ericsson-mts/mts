package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : Ajout flag pour d�tection de SEQUENCE de SEQUENCE</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 * 
 * La fonction BERFlagNewObjet.getInstance().isNewobject() retourne true
 * si un nouvel objet est en construction (1er objet d'une sequence)
 * 
 */


public class BERFlagNewObjet {
	
	private boolean newobject;

	private static BERFlagNewObjet instance = null;	
	
	public static synchronized BERFlagNewObjet getInstance() {
		if (instance == null) {
			instance = new BERFlagNewObjet();
		}			
		return instance;
	}

	public BERFlagNewObjet() {
		this.newobject = false;
	}
	
	public boolean isNewobject() {
		return newobject;
	}

	public void setNewobject(boolean newobject) {
		this.newobject = newobject;
	}

}
