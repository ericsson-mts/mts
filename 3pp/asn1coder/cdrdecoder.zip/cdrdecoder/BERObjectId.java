package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

import java.io.*;
import java.util.*;

// Referenced classes of package cdrdecoder:
//            BERElement

public class BERObjectId
    extends BERElement {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private int m_value[];

  public BERObjectId(int value[]) {
    this.m_value = null;
    this.m_value = new int[value.length];
    System.arraycopy(value, 0, this.m_value, 0, value.length);
  }

  public BERObjectId(String value) {
    this.m_value = null;
    StringTokenizer tokenizer = new StringTokenizer(value, ".");
    this.m_value = new int[tokenizer.countTokens()];
    for (int i = 0; i < this.m_value.length; i++) {
      this.m_value[i] = Integer.parseInt(tokenizer.nextToken());
    }

  }

  public BERObjectId(InputStream stream, int bytes_read[]) throws IOException {
    this.m_value = null;
    int contents_length = BERElement.readLengthOctets(stream, bytes_read);
    bytes_read[0] += contents_length;
    int contents_read[] = new int[1];
    Vector oid = new Vector(10);
    contents_read[0] = 0;
    int sub_id = readSubIdentifier(stream, contents_read);
    contents_length -= contents_read[0];
    if (sub_id < 40) {
      oid.addElement(new Integer(0));
    }
    else
    if (sub_id < 80) {
      oid.addElement(new Integer(1));
    }
    else {
      oid.addElement(new Integer(2));
    }
    oid.addElement(new Integer(sub_id -
                               ((Integer) oid.elementAt(oid.size() - 1)).
                               intValue() * 40));
    while (contents_length > 0) {
      contents_read[0] = 0;
      sub_id = readSubIdentifier(stream, contents_read);
      contents_length -= contents_read[0];
      oid.addElement(new Integer(sub_id));
    }
    this.m_value = new int[oid.size()];
    for (int i = 0; i < oid.size(); i++) {
      this.m_value[i] = ((Integer) oid.elementAt(i)).intValue();
    }

  }

  public void write(OutputStream stream) throws IOException {
    stream.write(6);
    ByteArrayOutputStream contents_stream = new ByteArrayOutputStream();
    writeSubIdentifier(contents_stream, this.m_value[0] * 40 + this.m_value[1]);
    for (int i = 2; i < this.m_value.length; i++) {
      writeSubIdentifier(contents_stream, this.m_value[i]);
    }

    byte contents_buffer[] = contents_stream.toByteArray();
    BERElement.sendDefiniteLength(stream, contents_buffer.length);
    stream.write(contents_buffer);
  }

  private int readSubIdentifier(InputStream stream, int bytes_read[]) throws
      IOException {
    int sub_id = 0;
    int octet;
    do {
      octet = stream.read();
      bytes_read[0]++;
      sub_id = sub_id << 7 | octet & 0x7f;
    }
    while ( (octet & 0x80) > 0);
    return sub_id;
  }

  private void writeSubIdentifier(OutputStream stream, int value) throws
      IOException {
    ByteArrayOutputStream sub_id_stream = new ByteArrayOutputStream();
    for (; value > 0; value >>= 7) {
      sub_id_stream.write(value & 0x7f);
    }

    byte sub_id_buffer[] = sub_id_stream.toByteArray();
    for (int i = sub_id_buffer.length - 1; i > 0; i--) {
      stream.write(sub_id_buffer[i] | 0x80);
    }

    stream.write(sub_id_buffer[0]);
  }

  public int[] getValue() {
    return this.m_value;
  }

  public int getType() {
    return 6;
  }

  public String toString() {
    if (this.m_value == null) {
      return "ObjectIdentifier (null)";
    }
    String oid = "";
    for (int i = 0; i < this.m_value.length; i++) {
      if (i != 0) {
        oid = String.valueOf(String.valueOf(oid)).concat(" ");
      }
      oid = String.valueOf(oid) + String.valueOf(this.m_value[i]);
    }

    return String.valueOf(String.valueOf( (new StringBuffer(
        "ObjectIdentifier {")).append(oid).append("}")));
  }
}
