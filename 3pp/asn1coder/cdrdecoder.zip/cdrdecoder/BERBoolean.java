package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

import java.io.*;

// Referenced classes of package cdrdecoder:
//            BERElement

public class BERBoolean
    extends BERElement {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private boolean m_value;

  public BERBoolean(boolean value) {
    this.m_value = true;
    this.m_value = value;
  }

  public BERBoolean(InputStream stream, int bytes_read[]) throws IOException {
    this.m_value = true;
    int octet = stream.read();
    bytes_read[0]++;
    octet = stream.read();
    bytes_read[0]++;
    if (octet > 0) {
      this.m_value = true;
    }
    else {
      this.m_value = false;
    }
  }

  public void write(OutputStream stream) throws IOException {
    stream.write(1);
    stream.write(1);
    if (this.m_value) {
      stream.write(255);
    }
    else {
      stream.write(0);
    }
  }

  public boolean getValue() {
    return this.m_value;
  }

  public int getType() {
    return 1;
  }

  public String toString() {
    return String.valueOf(String.valueOf( (new StringBuffer("Boolean {")).
                                         append(this.m_value).append("}")));
  }
}
