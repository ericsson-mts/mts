package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public class BERNumericString extends BERCharacterString
{
    /**  */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new BERNumericString object.
     *
     * @param string DOCUMENT ME!
     */
    public BERNumericString(String string)
    {
        super.m_value = string;
    }

    /**
     * Creates a new BERNumericString object.
     *
     * @param buffer DOCUMENT ME!
     */
    public BERNumericString(byte[] buffer)
    {
        super(buffer);
    }

    /**
     * Creates a new BERNumericString object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERNumericString(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        super(decoder, stream, bytes_read);
    }

    /**
     * Creates a new BERNumericString object.
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERNumericString(InputStream stream, int[] bytes_read)
    throws IOException
    {
        super(stream, bytes_read);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return 18;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        if (super.m_value == null)
        {
            return "NumericString (null)";
        }

        return String.valueOf(String.valueOf((new StringBuffer("NumericString {")).append(super.m_value).append("}")));
    }
}
