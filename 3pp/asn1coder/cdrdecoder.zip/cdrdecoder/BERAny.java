package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

import java.io.*;

// Referenced classes of package cdrdecoder:
//            BERElement, BERTagDecoder

public class BERAny
    extends BERElement {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private BERElement m_value;

  public BERAny(BERElement value) {
    this.m_value = null;
    this.m_value = value;
  }

  public BERAny(BERTagDecoder decoder, InputStream stream, int bytes_read[]) throws
      IOException {
    this.m_value = null;
    this.m_value = BERElement.getElement(decoder, stream, bytes_read);
  }

  public void write(OutputStream stream) throws IOException {
    this.m_value.write(stream);
  }

  public int getType() {
    return -3;
  }

  public String toString() {
    return String.valueOf(String.valueOf( (new StringBuffer("ANY {")).append(
        this.m_value).append("}")));
  }
}
