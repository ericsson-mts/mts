package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public class BERTag extends BERElement
{
    /**  */
    private static final long serialVersionUID = 1L;
    private int m_tag;
    private BERElement m_element;
    private boolean m_implicit;

    /**
     * Creates a new BERTag object.
     *
     * @param tag DOCUMENT ME!
     * @param element DOCUMENT ME!
     * @param implicit DOCUMENT ME!
     */
    public BERTag(int tag, BERElement element, boolean implicit)
    {
        this.m_tag = 0;
        this.m_element = null;
        this.m_implicit = false;
        this.m_tag = tag;
        this.m_element = element;
        this.m_implicit = implicit;
    }

    /**
     * Creates a new BERTag object.
     *
     * @param decoder DOCUMENT ME!
     * @param tag DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERTag(BERTagDecoder decoder, int tag, InputStream stream, int[] bytes_read)
    throws IOException
    {
        this.m_tag = 0;
        this.m_element = null;
        this.m_implicit = false;
        this.m_tag = tag;

        boolean[] implicit = new boolean[1];        this.m_element = decoder.getElement(decoder, tag, stream, bytes_read, implicit);

        this.m_implicit = implicit[0];
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public BERElement getValue()
    {
        return this.m_element;
    }

    /**
     * DOCUMENT ME!
     *
     * @param value DOCUMENT ME!
     */
    public void setImplicit(boolean value)
    {
        this.m_implicit = value;
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public void write(OutputStream stream) throws IOException
    {
        stream.write(this.m_tag);

        ByteArrayOutputStream contents_stream = new ByteArrayOutputStream();
        this.m_element.write(contents_stream);

        byte[] contents_buffer = contents_stream.toByteArray();

        if (this.m_implicit)
        {
            stream.write(contents_buffer, 1, contents_buffer.length - 1);
        }
        else
        {
            BERElement.sendDefiniteLength(stream, contents_buffer.length);
            stream.write(contents_buffer);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return -1;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getTag()
    {
        return this.m_tag;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        String s = "";

        if ((this.m_tag & 0xc0) == 0)
        {
            s = String.valueOf(String.valueOf(s)).concat("UNIVERSAL-");
        }
        else if ((this.m_tag & 0x80 & (this.m_tag & 0x40)) > 0)
        {
            s = String.valueOf(String.valueOf(s)).concat("PRIVATE-");
        }
        else if ((this.m_tag & 0x40) > 0)
        {
            s = String.valueOf(String.valueOf(s)).concat("APPLICATION-");
        }
        else if ((this.m_tag & 0x80) > 0)
        {
            s = String.valueOf(String.valueOf(s)).concat("CONTEXT-");
        }

        return String.valueOf(String.valueOf((new StringBuffer("[")).append(s).append(this.m_tag & 0x1f).append("] ")
                                              .append(this.m_element.toString())));
    }
}
