package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public class BERReal extends BERElement
{
    /**  */
    private static final long serialVersionUID = 1L;
    public static final float PLUS_INFINITY = (1.0F / 0.0F);
    public static final float MINUS_INFINITY = (-1.0F / 0.0F);
    private float m_value;

    /**
     * Creates a new BERReal object.
     *
     * @param value DOCUMENT ME!
     */
    public BERReal(float value)
    {
        this.m_value = 0.0F;
        this.m_value = value;
    }

    /**
     * Creates a new BERReal object.
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERReal(InputStream stream, int[] bytes_read)
    throws IOException
    {
        this.m_value = 0.0F;

        int length = BERElement.readLengthOctets(stream, bytes_read);

        if (length == 0)
        {
            this.m_value = 0.0F;
        }
        else
        {
            int octet = stream.read();
            bytes_read[0]++;
            
            System.err.println("BERReal octet = "+octet);

            if (octet == 64)
            {
                this.m_value = (1.0F / 0.0F);
            }
            else if (octet == 65)
            {
                this.m_value = (-1.0F / 0.0F);
            }
            else if ((octet & 0x80) > 0)
            {
                int sign;

                if ((octet & 0x40) > 0)
                {
                    sign = -1;
                }
                else
                {
                    sign = 1;
                }

                int base;

                if ((octet & 0x20) > 0)
                {
                    if ((octet & 0x10) > 0)
                    {
                        base = 0;
                    }
                    else
                    {
                        base = 16;
                    }
                }
                else if ((octet & 0x10) > 0)
                {
                    base = 8;
                }
                else
                {
                    base = 2;
                }

                int f;

                if ((octet & 8) > 0)
                {
                    if ((octet & 4) > 0)
                    {
                        f = 3;
                    }
                    else
                    {
                        f = 2;
                    }
                }
                else if ((octet & 4) > 0)
                {
                    f = 1;
                }
                else
                {
                    f = 0;
                }

                int exponent;
                int num_exponent_octets;

                if ((octet & 2) > 0)
                {
                    if ((octet & 1) > 0)
                    {
                        num_exponent_octets = stream.read();
                        bytes_read[0]++;
                        exponent = readTwosComplement(stream, bytes_read, num_exponent_octets);
                    }
                    else
                    {
                        num_exponent_octets = 3;
                        exponent = readTwosComplement(stream, bytes_read, num_exponent_octets);
                    }
                }
                else if ((octet & 1) > 0)
                {
                    num_exponent_octets = 2;
                    exponent = readTwosComplement(stream, bytes_read, num_exponent_octets);
                }
                else
                {
                    num_exponent_octets = 1;
                    exponent = readTwosComplement(stream, bytes_read, num_exponent_octets);
                }

                int contents_length_left = length - 1 - num_exponent_octets;
                int number = readUnsignedBinary(stream, bytes_read, contents_length_left);
                int mantissa = (int) (sign * number * Math.pow(2D, f));
                this.m_value = mantissa * (float) Math.pow(base, exponent);
            }
            else
            {
                throw new IOException("real ISO6093 not supported. ");
            }
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public void write(OutputStream stream) throws IOException
    {
        if (this.m_value == 0)
        {
            stream.write(9);
            stream.write(0);
        }
        else if (this.m_value == (1.0F / 0.0F))
        {
            stream.write(9);
            stream.write(1);
            stream.write(64);
        }
        else if (this.m_value == (-1.0F / 0.0F))
        {
            stream.write(9);
            stream.write(1);
            stream.write(65);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return 9;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        return String.valueOf(String.valueOf((new StringBuffer("Real {")).append(this.m_value).append("}")));
    }

    /*static {
       PLUS_INFINITY = (1.0F / 0.0F);
       MINUS_INFINITY = ( -1.0F / 0.0F);
        }*/
}
