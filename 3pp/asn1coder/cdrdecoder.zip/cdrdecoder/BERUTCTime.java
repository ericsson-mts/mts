package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

import java.io.*;

// Referenced classes of package cdrdecoder:
//            BERElement, BERTagDecoder

public class BERUTCTime
    extends BERElement {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
private String m_value;
  private byte byte_buf[];

  public BERUTCTime(String utc_string) {
    this.m_value = null;
    this.m_value = utc_string;
  }

  public BERUTCTime(BERTagDecoder decoder, InputStream stream, int bytes_read[]) throws
      IOException {
    this.m_value = null;
    int contents_length = BERElement.readLengthOctets(stream, bytes_read);
    int component_length[] = new int[1];
    BERElement element = null;
    this.m_value = "";
    if (contents_length == -1) {
      component_length[0] = 0;
      element = BERElement.getElement(decoder, stream, component_length);
      if (element != null) {
        BERUTCTime utc_element = (BERUTCTime) element;
        this.m_value = String.valueOf(this.m_value) + String.valueOf(utc_element.getValue());
      }
      while (element != null) {
        //TODO rien
      }
    }
    else {
      bytes_read[0] += contents_length;
      for (; contents_length > 0; contents_length -= component_length[0]) {
        component_length[0] = 0;
        element = BERElement.getElement(decoder, stream, component_length);
        if (element != null) {
          BERUTCTime utc_element = (BERUTCTime) element;
          this.m_value = String.valueOf(this.m_value) +
              String.valueOf(utc_element.getValue());
        }
      }

    }
  }

  public BERUTCTime(InputStream stream, int bytes_read[]) throws IOException {
    this.m_value = null;
    int contents_length = BERElement.readLengthOctets(stream, bytes_read);
    if (contents_length > 0) {
      byte byte_buf1[] = new byte[contents_length];
      for (int i = 0; i < contents_length; i++) {
        byte_buf1[i] = (byte) stream.read();
      }

      bytes_read[0] += contents_length;
      try {
        this.m_value = new String(byte_buf1, "UTF8");
      }
      catch (Throwable throwable) {
		  //TODO rien
      }
    }
  }

  public void write(OutputStream stream) throws IOException {
    stream.write( (byte) getType());
    if (this.m_value == null) {
      BERElement.sendDefiniteLength(stream, 0);
    }
    else {
      try {
        this.byte_buf = this.m_value.getBytes("UTF8");
        BERElement.sendDefiniteLength(stream, this.byte_buf.length);
      }
      catch (Throwable throwable) {
		  //TODO rien
      }
      stream.write(this.byte_buf, 0, this.byte_buf.length);
    }
  }

  public String getValue() {
    return this.m_value;
  }

  public int getType() {
    return 23;
  }

  public String toString() {
    if (this.m_value == null) {
      return "UTCTime (null)";
    }
	return String.valueOf(String.valueOf( (new StringBuffer("UTCTime {")).
                                           append(this.m_value).append("}")));
  }
}
