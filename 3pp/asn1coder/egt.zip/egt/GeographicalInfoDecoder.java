package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * 
 * ASN1 MPS9 (=MPS7)
 * GeographicalInfo ::= SEQUENCE
 * {
 *  coordinateSystem       [1] IMPLICIT CoordinateSystem,
 *  datum                  [2] IMPLICIT GeodeticDatum
 * }
 * 
 * @author esforcs
 * @version R3-CP00
 */

public class GeographicalInfoDecoder
    extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;

  public static final int COORDINATESYSTEM = 1;
  public static final int DATUM = 2;
  
  private CDR cdr = null;
  private GeographicalInfo geoInfo = null;
  
  public GeographicalInfoDecoder(CDR Cdr) {
    this.cdr = Cdr;
  }
  
  public GeographicalInfoDecoder(GeographicalInfo geoInfo) {
	    this.geoInfo = geoInfo;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    		System.err.println("GeographicalInfo ========================== " + tag);
    }

    if (tag == (COORDINATESYSTEM | 0x80)) {
      BEREnumerated b = new BEREnumerated(io, ia);
      if (cdr != null)
    	  this.cdr.coordinateSystem = b.getValue();
      else
    	  geoInfo.coordinateSystem = b.getValue();
      
      if (DEBUG) {
    	  System.err.println("GeographicalInfo coordinateSystem ========================== " +
    			  (cdr !=null?this.cdr.coordinateSystem:geoInfo.coordinateSystem));
      }
      return b;
    }
    if (tag == (DATUM | 0x80)) {
      BEREnumerated b = new BEREnumerated(io, ia);
      if (cdr != null)
    	  this.cdr.datum = b.getValue();
      else
    	  geoInfo.datum = b.getValue();
	  
      if (DEBUG) {
    	  System.err.println(
            "GeographicalInfo datum ========================== " + (cdr !=null?this.cdr.datum:geoInfo.datum));
      }

      return b;
    }
    
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.cdr.setUnknownTag(b, tag);
      if (DEBUG) {
    	  System.err.println(
            "GeographicalInfo setUnknownTag ========================== " +
            (cdr !=null?this.cdr.getUnknownTags():geoInfo.getUnknownTags()));
      }

      return b;
  }

}