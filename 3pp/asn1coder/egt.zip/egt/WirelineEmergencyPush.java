package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 *WirelineEmergencyPush::= SEQUENCE
 * {
 * clientId 			[1] IMPLICIT IA5String OPTIONAL,
 * clientNo 			[2] IMPLICIT IA5String,
 * pushResultCode 		[3] EXPLICIT EmergencyPushResultCode,
 * targetTELURI 		[4] IMPLICIT IA5String OPTIONAL,
 * location 			[5] IMPLICIT IA5String OPTIONAL
 * }
 */

/**
* <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class WirelineEmergencyPush {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";
	private static final int NOT_SET_INT = 0x80000000;

	public String clientId;
	public String clientNo;
	public int pushResultCode;
	public String targetTELURI;
	public String location;
	

	public WirelineEmergencyPush() {
		
		this.clientId = NOT_SET;
		this.clientNo = NOT_SET;
		this.pushResultCode = NOT_SET_INT;
		this.targetTELURI = NOT_SET;
		this.location = NOT_SET;
		
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n"  
				+ "\t\t\tclientId " + this.clientId + "\r\n"					
				+ "\t\t\tclientNo " + this.clientNo + "\r\n"
				+ "\t\t\tpushResultCode " + this.pushResultCode + "\r\n"
				+ "\t\t\ttargetTELURI " + this.targetTELURI + "\r\n"
				+ "\t\t\tlocation " + this.location + "\r\n"
				+ "\t\t}\r\n";

		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

}
