package com.ericsson.mps.egt;
	
	import java.io.IOException;
	import java.io.InputStream;

	import com.ericsson.mps.egt.cdrdecoder.BERElement;
	import com.ericsson.mps.egt.cdrdecoder.BEREnumerated;
	import com.ericsson.mps.egt.cdrdecoder.BERInteger;
	import com.ericsson.mps.egt.cdrdecoder.BEROctetString;
	import com.ericsson.mps.egt.cdrdecoder.BERSequence;
	import com.ericsson.mps.egt.cdrdecoder.BERTagDecoder;

	/**
	* ASN1 MPS10 (<> MPS9)
	* AllPhonesWithinArea ::= SEQUENCE
	* {
	* requestId 					[1] IMPLICIT IA5String,
	* clientId 						[2] IMPLICIT IA5String,
	* clientNo 						[3] IMPLICIT IA5String,
	* amountOfSubscribersReported 	[4] IMPLICIT INTEGER,
	* reportTime 					[5] IMPLICIT IA5String,
	* errorCode 					[6] IMPLICIT INTEGER,
	* pushURL 						[7] IMPLICIT IA5String,
	* pushId 						[8] IMPLICIT IA5String,
	* locationEstimateIncluded 		[9] IMPLICIT INTEGER
	* }
	*/

	public class AllPhonesWithinAreaDecoder extends BERTagDecoder {
		public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;

		public static final int REQUESTID = 1;
		public static final int CLIENTID = 2;
		public static final int CLIENTNO = 3;
		public static final int AMOUNTOFSUBSCRIBERSREPORTED = 4;
		public static final int REPORTTIME = 5;
		public static final int ERRORCODE = 6;
		public static final int PUSHURL = 7;
		public static final int PUSHID = 8;
		public static final int LOCATIONESTIMATEINCLUDED = 9;
	  
		  private CDR cdr;
		  public AllPhonesWithinAreaDecoder(CDR Cdr) {
		    this.cdr = Cdr;
		  }

		  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
		                               int ia[], boolean implicit[]) throws IOException {
			  if (DEBUG) {
					System.err.println("Termination getElement ========================== " + tag);
				}
				if (tag == (REQUESTID | 0x80)) {
					BEROctetString b = new BEROctetString(dec, io, ia);
					this.cdr.allPhonesWithinAreaRequestId = new String(b.getValue(), 0,
							b.getValue().length);
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea requestId ========================== "
										+ this.cdr.allPhonesWithinAreaRequestId);
					}
					return b;
				}
				if (tag == (CLIENTID | 0x80)) {
					BEROctetString b = new BEROctetString(dec, io, ia);
					this.cdr.allPhonesWithinAreaClientId = new String(b.getValue(), 0,
							b.getValue().length);
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea clientId ========================== "
										+ this.cdr.allPhonesWithinAreaClientId);
					}
					return b;
				}
				if (tag == (CLIENTNO | 0x80)) {
					BEROctetString b = new BEROctetString(dec, io, ia);
					this.cdr.allPhonesWithinAreaClientNo = new String(b.getValue(), 0,
							b.getValue().length);
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea clientNo ========================== "
										+ this.cdr.allPhonesWithinAreaClientNo);
					}
					return b;
				}

				if (tag == (AMOUNTOFSUBSCRIBERSREPORTED | 0x80 | 0x20)) {
					BERInteger b = new BERInteger(io, ia);
					this.cdr.amountOfSubscribersReported = b.getValue();
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea amountOfSubscribersReported ========================== "
										+ this.cdr.amountOfSubscribersReported);
					}
				      return b;
				    }

				if (tag == (REPORTTIME | 0x80)) {
					BEROctetString b = new BEROctetString(dec, io, ia);
					this.cdr.allPhonesWithinAreaReportTime = new String(b.getValue(), 0,
							b.getValue().length);
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea reportTime ========================== "
										+ this.cdr.allPhonesWithinAreaReportTime);
					}
					return b;
				}
	
				if (tag == (ERRORCODE | 0x80)) {
					BERInteger b = new BERInteger(io, ia);
					this.cdr.allPhonesWithinAreaErrorCode = b.getValue();
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea errorCode ========================== "
										+ this.cdr.allPhonesWithinAreaErrorCode);
					}
					return b;
				}
				if (tag == (PUSHURL | 0x80)) {
					BEROctetString b = new BEROctetString(dec, io, ia);
					this.cdr.pushUrl = new String(b.getValue(), 0,
							b.getValue().length);
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea pushUrl ========================== "
										+ this.cdr.pushUrl);
					}
					return b;
				}
				if (tag == (PUSHID | 0x80)) {
					BEROctetString b = new BEROctetString(dec, io, ia);
					this.cdr.allPhonesWithinAreaPushId = new String(b.getValue(), 0,
							b.getValue().length);
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea pushId ========================== "
										+ this.cdr.allPhonesWithinAreaPushId);
					}
					return b;
				}
				if (tag == (LOCATIONESTIMATEINCLUDED | 0x80)) {
					BERInteger b = new BERInteger(io, ia);
					this.cdr.locationEstimateIncluded = b.getValue();
					if (DEBUG) {
						System.err
								.println("allPhonesWithinArea locationEstimateIncluded ========================== "
										+ this.cdr.locationEstimateIncluded);
					}
					return b;
				}
			BEROctetString b = new BEROctetString(dec, io, ia);
		      this.cdr.setUnknownTag(b, tag);
		      return b;
		  }

}
