package com.ericsson.mps.egt;

import java.io.*;
import java.util.*;
import org.apache.log4j.*;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

public class CDR2Log {
  private static Logger logger = Logger.getLogger(CDR2Log.class);

  public static void main(String[] args) throws IOException {

    FileInputStream cdr_file = null;
    try {
    	cdr_file = new FileInputStream(args[0]);
    }
    catch (Exception exception) {
    	System.out.println("File not found");
    	System.out.println("Usage: cdrviewer <CDR file");
    }
    DailyRollingFileAppender rotate = new DailyRollingFileAppender(new
    		PatternLayout("%d{yyyy-MM-dd HH:mm:ss,SSS} %p %c{2} %m \r\n"),
    		args[0]+"_decoded.log", "'.'yyyy-MM-dd_HH-mm");
    logger.addAppender(rotate);

    PositionDataRecordDecoder mydr = new PositionDataRecordDecoder();
    java.util.LinkedList cdrs = mydr.decode(cdr_file);
    for (ListIterator lst = cdrs.listIterator(); lst.hasNext();) {
        try {
        	printCDR( (CDR) lst.next());
        }
        catch (Exception ex) { 
        	logger.error("\r\n\r\nCDR format error "+ex.toString());
        }
    }
  }

  private static void printCDR(CDR cDR) throws EgtException {
	  logger.info("\r\n\r\n"+cDR.toString2());
  }
}