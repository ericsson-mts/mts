package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * EllipsoidArc ::= SEQUENCE
 * {
 * time 				[1] IMPLICIT IA5String,
 * coordinate 			[2] IMPLICIT Coordinate,
 * innerradius 			[3] IMPLICIT IA5String,
 * uncertaintyradius 	[4] IMPLICIT IA5String,
 * offsetangle 			[5] IMPLICIT IA5String,
 * includedangle 		[6] IMPLICIT IA5String
 * }
 */

/**
* <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class EllipsoidArc {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";

	// SinglePosision begin
	public String time;
	public Coordinate coordinate;
	public String innerradius;
	public String uncertaintyradius;
	public String offsetangle;
	public String includedangle;
	

	public EllipsoidArc() {
		
		this.time = NOT_SET;
		this.coordinate = new Coordinate();
		this.innerradius = NOT_SET;
		this.uncertaintyradius = NOT_SET;
		this.offsetangle = NOT_SET;
		this.includedangle = NOT_SET;
		
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n"  
				+ "\t\t\ttime " + this.time + "\r\n"
				+ "\t\t\tcoordinate\r\n" + this.coordinate.toString2()							
				+ "\t\t\tinnerRadius " + this.innerradius + "\r\n"
				+ "\t\t\tuncertaintyRadius " + this.uncertaintyradius + "\r\n"
				+ "\t\t\toffsetAngle " + this.offsetangle + "\r\n"
				+ "\t\t\tincludedAngle " + this.includedangle + "\r\n"
				+ "\t\t}\r\n";

		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

}
