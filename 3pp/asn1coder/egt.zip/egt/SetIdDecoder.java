package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

import java.io.*;


/**
 * ASN1 MPS9 (not in MPS7) SETId ::= CHOICE  { msisdn                 [1] IMPLICIT IA5String, mdn
 * [2] IMPLICIT IA5String, min                    [3] IMPLICIT IA5String, imsi                   [4] IMPLICIT
 * IA5String, nai                    [5] IMPLICIT IA5String, iPAddress              [6] IMPLICIT IA5String }
 */
/**
 * <p>Titre : EGT</p>
 *  <p>Description : enrichisement des log GMPC</p>
 *  <p>Copyright : Copyright (c) 2008</p>
 *  <p>Soci�t� : Ericsson</p>
 *
 * @author esforcs
 * @version R3-CP00
 */
public class SetIdDecoder extends BERTagDecoder
{
    public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
    public static final int MSISDN = 1;
    public static final int MDN = 2;
    public static final int MIN = 3;
    public static final int IMSI = 4;
    public static final int NAI = 5;
    public static final int IPADDRESS = 6;
    private CDR cdr;
    private SinglePosition singleposition;

    /**
     * Creates a new SetIdDecoder object.
     *
     * @param Cdr DOCUMENT ME!
     */
    public SetIdDecoder(CDR Cdr)
    {
        this.cdr = Cdr;
    }

    /**
     * DOCUMENT ME!
     *
     * @param dec DOCUMENT ME!
     * @param tag DOCUMENT ME!
     * @param io DOCUMENT ME!
     * @param ia DOCUMENT ME!
     * @param implicit DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERElement getElement(BERTagDecoder dec, int tag, InputStream io, int[] ia, boolean[] implicit)
    throws IOException
    {
        if (DEBUG)
        {
            System.err.println("SetIdDecoder ========================== " + tag);
        }

        if (tag == (MSISDN | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            singleposition = (SinglePosition) this.cdr.singlePositionsList.get(this.cdr.singlePositionsList.size() - 1);
            singleposition.setID = tag;
            singleposition.setIDValue = new String(b.getValue(), 0, b.getValue().length);
            this.cdr.singlePositionsList.remove(this.cdr.singlePositionsList.size() - 1);
            this.cdr.singlePositionsList.add(this.singleposition);

            if (DEBUG)
            {
                System.err.println("setID MSISDN ========================== " + singleposition.setIDValue);
            }

            return b;
        }

        if (tag == (MDN | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            singleposition = (SinglePosition) this.cdr.singlePositionsList.get(this.cdr.singlePositionsList.size() - 1);
            singleposition.setID = tag;
            singleposition.setIDValue = new String(b.getValue(), 0, b.getValue().length);
            this.cdr.singlePositionsList.remove(this.cdr.singlePositionsList.size() - 1);
            this.cdr.singlePositionsList.add(this.singleposition);

            if (DEBUG)
            {
                System.err.println("setID MDN ========================== " + singleposition.setIDValue);
            }

            return b;
        }

        if (tag == (MIN | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            singleposition = (SinglePosition) this.cdr.singlePositionsList.get(this.cdr.singlePositionsList.size() - 1);
            singleposition.setID = tag;
            singleposition.setIDValue = new String(b.getValue(), 0, b.getValue().length);
            this.cdr.singlePositionsList.remove(this.cdr.singlePositionsList.size() - 1);
            this.cdr.singlePositionsList.add(this.singleposition);

            if (DEBUG)
            {
                System.err.println("setID MIN ========================== " + singleposition.setIDValue);
            }

            return b;
        }

        if (tag == (IMSI | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            singleposition = (SinglePosition) this.cdr.singlePositionsList.get(this.cdr.singlePositionsList.size() - 1);
            singleposition.setID = tag;
            singleposition.setIDValue = new String(b.getValue(), 0, b.getValue().length);
            this.cdr.singlePositionsList.remove(this.cdr.singlePositionsList.size() - 1);
            this.cdr.singlePositionsList.add(this.singleposition);

            if (DEBUG)
            {
                System.err.println("setID IMSI ========================== " + singleposition.setIDValue);
            }

            return b;
        }

        if (tag == (NAI | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            singleposition = (SinglePosition) this.cdr.singlePositionsList.get(this.cdr.singlePositionsList.size() - 1);
            singleposition.setID = tag;
            singleposition.setIDValue = new String(b.getValue(), 0, b.getValue().length);
            this.cdr.singlePositionsList.remove(this.cdr.singlePositionsList.size() - 1);
            this.cdr.singlePositionsList.add(this.singleposition);

            if (DEBUG)
            {
                System.err.println("setID NAI ========================== " + singleposition.setIDValue);
            }

            return b;
        }

        if (tag == (IPADDRESS | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            singleposition = (SinglePosition) this.cdr.singlePositionsList.get(this.cdr.singlePositionsList.size() - 1);
            singleposition.setID = tag;
            singleposition.setIDValue = new String(b.getValue(), 0, b.getValue().length);
            this.cdr.singlePositionsList.remove(this.cdr.singlePositionsList.size() - 1);
            this.cdr.singlePositionsList.add(this.singleposition);

            if (DEBUG)
            {
                System.err.println("setID IPADDRESS ========================== " + singleposition.setIDValue);
            }

            return b;
        }

        // else UnknownTag
        BEROctetString b = new BEROctetString(dec, io, ia);
        this.cdr.setUnknownTag(b, tag);

        if (DEBUG)
        {
            System.err.println("SetIdDecoder setUnknownTag ========================== " + this.cdr.getUnknownTags());
        }

        return b;
    }
}
