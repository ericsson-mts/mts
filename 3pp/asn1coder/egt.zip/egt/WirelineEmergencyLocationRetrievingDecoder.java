	package com.ericsson.mps.egt;

	import java.io.*;
	import com.ericsson.mps.egt.cdrdecoder.*;

	/**
	 * ASN1 MPS10
	 * WirelineEmergencyLocationRetrieving::= SEQUENCE
	 * {
	 * locationType 								[1] IMPLICIT LocationType OPTIONAL,
	 * clientId 									[2] IMPLICIT IA5String OPTIONAL,
	 * clientNo 									[3] IMPLICIT IA5String OPTIONAL,
	 * errorCode 									[4] IMPLICIT INTEGER,
	 * clientType 									[5] IMPLICIT ClientType OPTIONAL,
	 * privacyOverride 								[6] IMPLICIT INTEGER OPTIONAL,
	 * geographicalInfo 							[7] IMPLICIT GeographicalInfo OPTIONAL,
	 * qos 											[8] IMPLICIT QoS OPTIONAL,
	 * requestedPositionTime 						[9] IMPLICIT IA5String,
	 * singleWirelineEmergencyLocationRetrieving 	[10]IMPLICIT SEQUENCE OF SingleWirelineEmergencyLocationRetrieving,
	 * subclientNo 									[11] IMPLICIT IA5String OPTIONAL,
	 * clientRequestor 								[12] IMPLICIT IA5String OPTIONAL,
	 * clientServiceType 							[13] IMPLICIT INTEGER OPTIONAL
	 *}
	 */

	/**
	 * <p>Titre : EGT</p>
	 * <p>Description : enrichisement des log GMPC</p>
	 * <p>Copyright : Copyright (c) 2008</p>
	 * <p>Soci�t� : Ericsson</p>
	 * 
	 * @author esforcs
	 * @version R3-CP00
	 */

	public class WirelineEmergencyLocationRetrievingDecoder
	extends BERTagDecoder {
		public static final  boolean DEBUG = PositionDataRecordDecoder.DEBUG;

		public static int LOCATIONTYPE = 1;
		public static int CLIENTID = 2;
		public static int CLIENTNO = 3;
		public static int ERRORCODE = 4;
		public static int CLIENTTYPE = 5;
		public static int PRIVACYOVERRIDE = 6;
		public static int GEOGRAPHICALINFO = 7;
		public static int QOS = 8;
		public static int REQUESTEDPOSITIONTIME = 9;
		public static int SINGLEWIRELINEEMERGENCYLOCATIONRETRIEVING = 10; 
		public static int SUBCLIENTNO = 11;	
		public static int CLIENTREQUESTOR = 12;			 
		public static int CLIENTSERVICETYPE = 13;

		private WirelineEmergencyLocationRetrieving wirelineEmergencyLocationRetrieving;
		public static boolean debug = false;

		public WirelineEmergencyLocationRetrievingDecoder(WirelineEmergencyLocationRetrieving wirelineEmergencyLocationRetrieving) {
			this.wirelineEmergencyLocationRetrieving = wirelineEmergencyLocationRetrieving;
		}

		public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
				int ia[], boolean implicit[]) throws IOException {
			if (DEBUG) {
				System.err.println(
						"WirelineEmergencyLocationRetrieving ========================== " + tag);
			}
			
			if (tag == (LOCATIONTYPE | 0x80)) {
				BEREnumerated b = new BEREnumerated(io, ia);
				this.wirelineEmergencyLocationRetrieving.locationType = b.getValue();
				if (DEBUG) {
					System.err.println("wirelineEmergencyLocationRetrieving LocationType ==========================" + this.wirelineEmergencyLocationRetrieving.locationType);
				}
				return b;
			}

			if (tag == (CLIENTID | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.wirelineEmergencyLocationRetrieving.clientId = new String(b.getValue(), 0, b.getValue().length);
				if (DEBUG) {
					System.err.println("wirelineEmergencyLocationRetrieving ClientId ==========================" + this.wirelineEmergencyLocationRetrieving.clientId);
				}
				return b;
			}

			if (tag == (CLIENTNO | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.wirelineEmergencyLocationRetrieving.clientNo = new String(b.getValue(), 0, b.getValue().length);
				if (DEBUG) {
					System.err.println("wirelineEmergencyLocationRetrieving clientNo ==========================" +	this.wirelineEmergencyLocationRetrieving.clientNo);
				}
				return b;
			}

			if (tag == (ERRORCODE | 0x80)) {
				BERInteger b = new BERInteger(io, ia);
				this.wirelineEmergencyLocationRetrieving.errorCode = b.getValue();
				if (DEBUG) {
					System.err.println( "wirelineEmergencyLocationRetrieving errorCode ==========================" + this.wirelineEmergencyLocationRetrieving.errorCode);
				}
				return b;
			}

			if (tag == (CLIENTTYPE | 0x80)) {
				BEREnumerated b = new BEREnumerated(io, ia);
				this.wirelineEmergencyLocationRetrieving.clientType = b.getValue();
				if (DEBUG) {
					System.err.println( "wirelineEmergencyLocationRetrieving ClientType ==========================" + this.wirelineEmergencyLocationRetrieving.clientType);
				}
				return b;
			}

			if (tag == (PRIVACYOVERRIDE | 0x80)) {
				BERInteger b = new BERInteger(io, ia);
				this.wirelineEmergencyLocationRetrieving.privacyOverride = b.getValue();
				if (DEBUG) {
					System.err.println("wirelineEmergencyLocationRetrieving privacyOverride ==========================" + this.wirelineEmergencyLocationRetrieving.privacyOverride);
				}
				return b;
			}

			if (tag == (GEOGRAPHICALINFO | 0x80 | 0x20)) {
				GeographicalInfoDecoder GeographicalInfo_att_decoder = new GeographicalInfoDecoder( this.wirelineEmergencyLocationRetrieving.geographicalInfo);
				BERSequence brs = new BERSequence(GeographicalInfo_att_decoder, io, ia);
				if (DEBUG) {
					System.err.println("PositionResult GeographicalInfo ==end");
				}
				return brs;
			}

			if (tag == (QOS | 0x80 | 0x20)) {
				QoSDecoder QoS_att_decoder = new QoSDecoder( this.wirelineEmergencyLocationRetrieving.qos);
				BERSequence brs = new BERSequence(QoS_att_decoder, io, ia);
				if (DEBUG) {
					System.err.println("PositionResult QoS ==end");
				}
				return brs;
			}

			if (tag == (REQUESTEDPOSITIONTIME | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.wirelineEmergencyLocationRetrieving.requestedPositionTime = new String(b.getValue(), 0, b.getValue().length);
				if (DEBUG) {
					System.err.println(
							"wirelineEmergencyLocationRetrieving requestedPositionTime ==========================" +
							this.wirelineEmergencyLocationRetrieving.requestedPositionTime);
				}
				return b;
			}

			if (tag == (SINGLEWIRELINEEMERGENCYLOCATIONRETRIEVING | 0x80 | 0x20)) {
				SingleWirelineEmergencyLocationRetrievingDecoder SingleWireLine_att_decoder = new SingleWirelineEmergencyLocationRetrievingDecoder( this.wirelineEmergencyLocationRetrieving.singleWirelineEmergencyLocationRetrieving);
				BERSequence brs = new BERSequence(SingleWireLine_att_decoder, io, ia);
				if (DEBUG) {
					System.err.println("wirelineEmergencyLocationRetrieving singleWirelineEmergencyLocationRetrievingDecoder  ==========================" + this.wirelineEmergencyLocationRetrieving.singleWirelineEmergencyLocationRetrieving);
				}
				return brs;
			}

			if (tag == (SUBCLIENTNO | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.wirelineEmergencyLocationRetrieving.subclientNo = new String(b.getValue(), 0, b.getValue().length);
				if (DEBUG) {
					System.err.println(
							"wirelineEmergencyLocationRetrieving subClientNO ==========================" +this.wirelineEmergencyLocationRetrieving.subclientNo);
				}
				return b;
			}
			if (tag == (CLIENTREQUESTOR | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.wirelineEmergencyLocationRetrieving.clientRequestor = new String(b.getValue(), 0,
						b.getValue().length);
				if (DEBUG) {
					System.err.println(
							"wirelineEmergencyLocationRetrieving clientRequestor ==========================" +
							this.wirelineEmergencyLocationRetrieving.clientRequestor);

				}
				return b;
			}
			if (tag == (CLIENTSERVICETYPE | 0x80)) {
				BERInteger b = new BERInteger(io, ia);
				this.wirelineEmergencyLocationRetrieving.clientServiceType = b.getValue();
				if (DEBUG) {
					System.err.println(
							"wirelineEmergencyLocationRetrieving clientServiceType ==========================" +
							this.wirelineEmergencyLocationRetrieving.clientServiceType);
				}
				return b;
			}

			BEROctetString b = new BEROctetString(dec, io, ia);
			this.wirelineEmergencyLocationRetrieving.setUnknownTag(b, tag);
			if (DEBUG) {
				System.err.println(
						"wirelineEmergencyLocationRetrieving setUnknownTag ========================== " +
						this.wirelineEmergencyLocationRetrieving.getUnknownTags());
			}

			return b;
		}

	}
