package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * WirelineLocation ::= CHOICE
 * {
 * routingDeterminationResponse 		[1] IMPLICIT RoutingDeterminationResponse,
 * wirelineEmergencyLocationRetrieving 	[2] IMPLICIT WirelineEmergencyLocationRetrieving,
 * wirelineEmergencyPush 				[3] IMPLICIT WirelineEmergencyPush
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class WireLineLocation {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";

	public RoutingDeterminationResponse routingDeterminationResponse;
	public WirelineEmergencyLocationRetrieving wirelineEmergencyLocationRetrieving;
	public WirelineEmergencyPush wirelineEmergencyPush;

	public WireLineLocation() {

		this.routingDeterminationResponse = new RoutingDeterminationResponse();
		this.wirelineEmergencyLocationRetrieving = new WirelineEmergencyLocationRetrieving();
		this.wirelineEmergencyPush = new WirelineEmergencyPush();
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n"  
			+ "\t\t\troutingDeterminationResponse\r\n " + this.routingDeterminationResponse.toString2()
			+ "\t\t\twirelineEmergencyLocationRetrieving\r\n" + this.wirelineEmergencyLocationRetrieving.toString2()							
			+ "\t\t\twirelineEmergencyPush\r\n " + this.wirelineEmergencyPush.toString2()
			+ "\t\t}\r\n";

		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

}
