package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

import java.io.*;

import java.util.List;


/**
 * ASN1 MPS9 (not in MPS7) Coordinate ::= SEQUENCE  {  latitude               [1] IMPLICIT IA5String,  longitude
 * [2] IMPLICIT IA5String  }
 */
/**
 * <p>Titre : EGT</p>
 *  <p>Description : enrichisement des log GMPC</p>
 *  <p>Copyright : Copyright (c) 2008</p>
 *  <p>Soci�t� : Ericsson</p>
 *
 * @author esforcs
 * @version R3-CP00
 */
public class CoordinateDecoder extends BERTagDecoder
{
    public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
    public static final int LATITUDE = 1;
    public static final int LONGITUDE = 2;
    private Coordinate coordinate = null;
    private List<Coordinate> coordinates = null;

    /**
     * Creates a new CoordinateDecoder object.
     *
     * @param coord DOCUMENT ME!
     */
    public CoordinateDecoder(Coordinate coord)
    {
        this.coordinate = coord;
    }

    /**
     * Creates a new CoordinateDecoder object.
     *
     * @param coords DOCUMENT ME!
     */
    public CoordinateDecoder(List<Coordinate> coords)
    {
        this.coordinates = coords;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public Coordinate getCoordinate()
    {
        return coordinate;
    }

    /**
     * DOCUMENT ME!
     *
     * @param dec DOCUMENT ME!
     * @param tag DOCUMENT ME!
     * @param io DOCUMENT ME!
     * @param ia DOCUMENT ME!
     * @param implicit DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERElement getElement(BERTagDecoder dec, int tag, InputStream io, int[] ia, boolean[] implicit)
    throws IOException
    {
        if (DEBUG)
        {
            System.err.println("Coordinate ========================== " + tag);
        }

        // LATITUDE
        if (tag == (LATITUDE | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            this.coordinate.latitude = new String(b.getValue(), 0, b.getValue().length);

            if (DEBUG)
            {
                System.err.println("Coordinate latitude ========================== " + this.coordinate.latitude);
            }

            return b;
        }

        // LONGITUDE
        if (tag == (LONGITUDE | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            this.coordinate.longitude = new String(b.getValue(), 0, b.getValue().length);

            if (DEBUG)
            {
                System.err.println("Coordinate longitude ========================== " + this.coordinate.longitude);
            }

            return b;
        }

        // else UnknownTag
        BEROctetString b = new BEROctetString(dec, io, ia);
        this.coordinate.setUnknownTag(b, tag);

        if (DEBUG)
        {
            System.err.println("Coordinate setUnknownTag ========================== "
                               + this.coordinate.getUnknownTags());
        }

        return b;
    }
}
