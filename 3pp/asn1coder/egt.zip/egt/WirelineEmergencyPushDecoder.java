package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10
 * *WirelineEmergencyPush::= SEQUENCE
 * {
 * clientId 			[1] IMPLICIT IA5String OPTIONAL,
 * clientNo 			[2] IMPLICIT IA5String,
 * pushResultCode 		[3] EXPLICIT EmergencyPushResultCode,
 * targetTELURI 		[4] IMPLICIT IA5String OPTIONAL,
 * location 			[5] IMPLICIT IA5String OPTIONAL
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class WirelineEmergencyPushDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int CLIENTID = 1;
  public static final int CLIENTNO = 2;
  public static final int PUSHRESULTCODE = 3;
  public static final int TARGETTELURI = 4;
  public static final int LOCATION = 5;
  
  private WirelineEmergencyPush wirelineEmergencyPush;

  public WirelineEmergencyPushDecoder(WirelineEmergencyPush wirelineEmergencyPush) {
	  this.wirelineEmergencyPush = wirelineEmergencyPush;
  }
  
  public WirelineEmergencyPush getWirelineEmergencyPush() {
  	return this.wirelineEmergencyPush;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("WirelineEmergencyPush ======= " + tag);
    }

    // CLIENTID
    if (tag == (CLIENTID | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.wirelineEmergencyPush.clientId = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "WirelineEmergencyPush clientId ======= " + this.wirelineEmergencyPush.clientId);
        }
        return b;
    }
    
    // CLIENTNO
    if (tag == (CLIENTNO | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.wirelineEmergencyPush.clientNo = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "WirelineEmergencyPush clientNo ======= " + this.wirelineEmergencyPush.clientNo);
        }
        return b;
    }
    
    
    // PUSHRESULTCODE
    if (tag == (PUSHRESULTCODE | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
        this.wirelineEmergencyPush.pushResultCode =b.getValue();
    	if (DEBUG) {
    		System.err.println( "wirelineEmergencyPush pushResultCode ========================== " + this.wirelineEmergencyPush.pushResultCode);
        }
        return b;
    }

    // TARGETTELURI
    if (tag == (TARGETTELURI | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.wirelineEmergencyPush.targetTELURI = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "WirelineEmergencyPush targetTELURI ======= " + this.wirelineEmergencyPush.targetTELURI);
        }
        return b;
    }
    
    // LOCATION
    if (tag == (LOCATION | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.wirelineEmergencyPush.location = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "WirelineEmergencyPush location ======= " + this.wirelineEmergencyPush.location);
        }
        return b;
    }
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.wirelineEmergencyPush.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("wirelineEmergencyPush setUnknownTag ======= " + this.wirelineEmergencyPush.getUnknownTags());
    }
    return b;
  }





}
