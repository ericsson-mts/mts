package com.ericsson.mps.egt;

import java.io.IOException;
import java.io.InputStream;

import com.ericsson.mps.egt.cdrdecoder.BERElement;
import com.ericsson.mps.egt.cdrdecoder.BEREnumerated;
import com.ericsson.mps.egt.cdrdecoder.BERInteger;
import com.ericsson.mps.egt.cdrdecoder.BEROctetString;
import com.ericsson.mps.egt.cdrdecoder.BERSequence;
import com.ericsson.mps.egt.cdrdecoder.BERTagDecoder;

/**
* ASN1 MPS10 (<> MPS9)
*Initiation ::= SEQUENCE
* {
* requestId               [1]  IMPLICIT IA5String OPTIONAL,
* triggerCriterionType    [2]  IMPLICIT TriggerCriterionType,
* clientId                [3]  IMPLICIT IA5String,
* clientNo                [4]  IMPLICIT IA5String,
* subscriberDataList      [5]  IMPLICIT SEQUENCE OF 
*                              SubscriberData,
* speed                   [6]  IMPLICIT INTEGER,
* initiationTime          [7]  IMPLICIT IA5String,
* errorCode               [8]  IMPLICIT INTEGER,
* startTime               [9]  IMPLICIT IA5String,
* stopTime                [10] IMPLICIT IA5String,
* recurrenceInterval      [11] IMPLICIT INTEGER OPTIONAL,
* requestedAccuracyMeters [12] IMPLICIT INTEGER OPTIONAL
* locationEstimateIncluded 	[13] IMPLICIT INTEGER OPTIONAL
*}
*/

public class InitiationDecoder extends BERTagDecoder {
	public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;

	public static final int requestId = 1;
	public static final int triggerCriterionType = 2;
	public static final int clientId = 3;
	public static final int clientNo = 4;
	public static final int subscriberDataList = 5;
	public static final int speed = 6;
	public static final int initiationTime = 7;
	public static final int errorCode = 8;
	public static final int startTime = 9;
	public static final int stopTime = 10;
	public static final int recurrenceInterval = 11;
	public static final int requestedAccuracyMeters =12;
	public static final int locationEstimateIncluded =13;

	private CDR cdr;

	public InitiationDecoder(CDR Cdr) {
		this.cdr = Cdr;
	}

	public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
			int ia[], boolean implicit[]) throws IOException {
		if (DEBUG) {
			System.err
					.println("Initiation getElement ========================== "
							+ tag);
		}
		if (tag == (requestId | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.initiationRequestId = new String(b.getValue(), 0,
					b.getValue().length);
			if (DEBUG) {
				System.err
						.println("Initiation requestId ========================== "
								+ this.cdr.initiationRequestId);
			}
			return b;
		}
		if (tag == (triggerCriterionType | 0x80)) {
			BEREnumerated b = new BEREnumerated(io, ia);
			this.cdr.initiationTriggerCriterionType = b.getValue();
			if (DEBUG) {
				System.err
						.println("Initiation triggerCriterionType ========================== "
								+ this.cdr.initiationTriggerCriterionType);
			}
			return b;
		}
		if (tag == (clientId | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.initiationClientId = new String(b.getValue(), 0,
					b.getValue().length);
			if (DEBUG) {
				System.err
						.println("Initiation clientId ========================== "
								+ this.cdr.initiationClientId);
			}
			return b;
		}
		if (tag == (clientNo | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.initiationClientNo = new String(b.getValue(), 0,
					b.getValue().length);
			if (DEBUG) {
				System.err
						.println("Initiation clientNo ========================== "
								+ this.cdr.initiationClientNo);
			}
			return b;
		}

		 if (tag == (subscriberDataList | 0x80 | 0x20)) {
			 SubscriberDataDecoder subscriberDataDecoder = new
			 SubscriberDataDecoder(this.cdr);
		     BERSequence brs = new BERSequence(subscriberDataDecoder, io, ia);
		     if (DEBUG) {
		        System.err.println("Initiation subscriberDataList ==========================");
		      }
		      return brs;
		    }
		
		if (tag == (speed | 0x80)) {
			BEREnumerated b = new BEREnumerated(io, ia);
			this.cdr.initiationspeed = b.getValue();
			if (DEBUG) {
				System.err
						.println("Initiation speed ========================== "
								+ this.cdr.initiationspeed);
			}
			return b;
		}
		if (tag == (initiationTime | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.initiationTime = new String(b.getValue(), 0,
					b.getValue().length);
			if (DEBUG) {
				System.err
						.println("Initiation initiationTime ========================== "
								+ this.cdr.initiationTime);
			}
			return b;
		}
		if (tag == (errorCode | 0x80)) {
			BERInteger b = new BERInteger(io, ia);
			this.cdr.initiationErrorCode = b.getValue();
			if (DEBUG) {
				System.err
						.println("Initiation errorCode ========================== "
						+ this.cdr.initiationErrorCode);
			}
			return b;
		}
		if (tag == (startTime | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.initiationStartTime = new String(b.getValue(), 0,
					b.getValue().length);
			if (DEBUG) {
				System.err
						.println("Initiation startTime ========================== "
						+ this.cdr.initiationStartTime);
			}
			return b;
		}
		if (tag == (stopTime | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.initiationStopTime = new String(b.getValue(), 0,
					b.getValue().length);
			if (DEBUG) {
				System.err
						.println("Initiation StopTime ========================== "
						+ this.cdr.initiationStopTime);
			}
			return b;
		}
		if (tag == (recurrenceInterval | 0x80)) {
			BERInteger b = new BERInteger(io, ia);
			this.cdr.initiationRecurrenceInterval = b.getValue();
			if (DEBUG) {
				System.err
						.println("Initiation recurrenceInterval ========================== "
						+ this.cdr.initiationRecurrenceInterval);
			}
			return b;
		}
		
		if (tag == (requestedAccuracyMeters | 0x80)) {
			BERInteger b = new BERInteger(io, ia);
			this.cdr.initiationrequestedAccuracyMeters = b.getValue();
			if (DEBUG) {
				System.err
						.println("Initiation requestedAccuracyMeters ========================== "
						+ this.cdr.initiationrequestedAccuracyMeters);
			}
			return b;
		}
		
		if (tag == (locationEstimateIncluded | 0x80)) {
			BERInteger b = new BERInteger(io, ia);
			this.cdr.initiationlocationEstimateIncluded = b.getValue();
			if (DEBUG) {
				System.err
						.println("Initiation locationEstimateIncluded ========================== "
						+ this.cdr.initiationlocationEstimateIncluded);
			}
			return b;
		}
		
		BEROctetString b = new BEROctetString(dec, io, ia);
		this.cdr.setUnknownTag(b, tag);
		return b;
	}

}