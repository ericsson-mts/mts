package com.ericsson.mps.egt;

import java.io.IOException;
import java.io.InputStream;

import com.ericsson.mps.egt.cdrdecoder.BERElement;
import com.ericsson.mps.egt.cdrdecoder.BEREnumerated;
import com.ericsson.mps.egt.cdrdecoder.BERInteger;
import com.ericsson.mps.egt.cdrdecoder.BEROctetString;
import com.ericsson.mps.egt.cdrdecoder.BERSequence;
import com.ericsson.mps.egt.cdrdecoder.BERTagDecoder;

/**
 * ASN1 MPS9 (<> MPS7) Report ::= SEQUENCE { requestId [1] IMPLICIT IA5String,
 * triggerCriterionType [2] IMPLICIT TriggerCriterionType, clientId [3] IMPLICIT
 * IA5String, clientNo [4] IMPLICIT IA5String, subscriberDataList [5] IMPLICIT
 * SEQUENCE OF SubscriberData, speed [6] IMPLICIT INTEGER, reportTime [7]
 * IMPLICIT IA5String, errorCode [8] IMPLICIT INTEGER, startTime [9] IMPLICIT
 * IA5String, stopTime [10] IMPLICIT IA5String, pushURL [11] IMPLICIT IA5String,
 * pushId [12] IMPLICIT IA5String, recurrentReport [13] IMPLICIT NULL OPTIONAL,
 * requestedAccuracyMeters [14] IMPLICIT INTEGER OPTIONAL, obtainedAccuracy [15]
 * IMPLICIT INTEGER, locationEstimateIncluded[16] IMPLICIT INTEGER }
 */

public class ReportDecoder extends BERTagDecoder
{
	public static final boolean	DEBUG	                 = PositionDataRecordDecoder.DEBUG;
	public static final int	    REQUESTID	             = 1;
	public static final int	    TRIGGERCRITERIONTYPE	 = 2;
	public static final int	    CLIENTID	             = 3;
	public static final int	    CLIENTNO	             = 4;
	public static final int	    SUBSCRIBERDATALIST	     = 5;
	public static final int	    SPEED	                 = 6;
	public static final int	    REPORTTIME	             = 7;
	public static final int	    ERRORCODE	             = 8;
	public static final int	    STARTTIME	             = 9;
	public static final int	    STOPTIME	             = 10;
	public static final int	    PUSHURL	                 = 11;
	public static final int	    PUSHID	                 = 12;
	public static final int	    RECURRENTREPORT	         = 13;
	public static final int	    REQUESTEDACCURACYMETERS	 = 14;
	public static final int	    OBTAINEDACCURACY	     = 15;
	public static final int	    LOCATIONESTIMATEINCLUDED	= 16;

	private CDR	                cdr;

	public ReportDecoder(CDR Cdr)
	{
		this.cdr = Cdr;
	}

	public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
	        int ia[], boolean implicit[]) throws IOException
	{
		if (DEBUG)
		{
			System.err.println("Report getElement ========================== "
			        + tag);
		}
		if (tag == (REQUESTID | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportRequestId = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("Report requestId ========================== "
				                + this.cdr.reportRequestId);
			}
			return b;
		}
		if (tag == (TRIGGERCRITERIONTYPE | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.cdr.reportTriggerCriterionType = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("Report triggerCriterionType ========================== "
				                + this.cdr.reportTriggerCriterionType);
			}
			return b;
		}
		if (tag == (CLIENTID | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportClientId = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("Report clientId ========================== "
				                + this.cdr.reportClientId);
			}
			return b;
		}
		if (tag == (CLIENTNO | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportClientNo = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("Report clientNo ========================== "
				                + this.cdr.reportClientNo);
			}
			return b;
		}
		// ********************ne pas oublier les
		// subdatalist*********************
		if (tag == (SUBSCRIBERDATALIST | 0x80 | 0x20))
		{
			SubscriberDataDecoder subscriberDataDecoder = new SubscriberDataDecoder(
			        this.cdr);
			BERSequence brs = new BERSequence(subscriberDataDecoder, io, ia);
			if (DEBUG)
			{
				System.err
				        .println("Report subscriberDataList ==========================");

			}
			return brs;
		}

		if (tag == (SPEED | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.cdr.reportspeed = b.getValue();
			if (DEBUG)
			{
				System.err.println("Report speed ========================== "
				        + this.cdr.reportspeed);
			}
			return b;
		}
		if (tag == (REPORTTIME | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportTime = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("Report reportTime ========================== "
				                + this.cdr.reportTime);
			}
			return b;
		}
		if (tag == (ERRORCODE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.reportErrorCode = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("Report errorCode ========================== "
				                + this.cdr.reportErrorCode);
			}
			return b;
		}
		if (tag == (STARTTIME | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportStartTime = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("Report startTime ========================== "
				                + this.cdr.reportStartTime);
			}
			return b;
		}
		if (tag == (STOPTIME | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportStopTime = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("Report StopTime ========================== "
				                + this.cdr.reportStopTime);
			}
			return b;
		}
		if (tag == (PUSHURL | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportPushURL = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err.println("Report PushURL ========================== "
				        + this.cdr.reportPushURL);
			}
			return b;
		}
		if (tag == (PUSHID | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.reportPushID = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err.println("Report PushID ========================== "
				        + this.cdr.reportPushID);
			}
			return b;
		}
		if (tag == (RECURRENTREPORT | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.reportRecurrentReport = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("Report recurrentReport ========================== "
				                + this.cdr.reportRecurrentReport);
			}
			return b;
		}

		if (tag == (REQUESTEDACCURACYMETERS | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.reportrequestedAccuracyMeters = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("Report requestedAccuracyMeters ========================== "
				                + this.cdr.reportrequestedAccuracyMeters);
			}
			return b;
		}
		if (tag == (OBTAINEDACCURACY | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.reportobtainedAccuracy = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("Report obtainedAccuracy ========================== "
				                + this.cdr.reportobtainedAccuracy);
			}
			return b;
		}

		if (tag == (LOCATIONESTIMATEINCLUDED | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.reportlocationEstimateIncluded = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("Report locationEstimateIncluded ========================== "
				                + this.cdr.reportlocationEstimateIncluded);
			}
			return b;
		}

		BEROctetString b = new BEROctetString(dec, io, ia);
		this.cdr.setUnknownTag(b, tag);
		return b;
	}
}