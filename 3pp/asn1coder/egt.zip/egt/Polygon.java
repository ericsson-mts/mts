package com.ericsson.mps.egt;

import java.util.ArrayList;
import java.util.List;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * EllipsoidArc ::= SEQUENCE
 * {
 * time 				[1] IMPLICIT IA5String,
 * coordinate 			[2] IMPLICIT Coordinate,
 * innerradius 			[3] IMPLICIT IA5String,
 * uncertaintyradius 	[4] IMPLICIT IA5String,
 * offsetangle 			[5] IMPLICIT IA5String,
 * includedangle 		[6] IMPLICIT IA5String
 * }
 */

/**
* <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class Polygon {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";

	private static final int NOT_SET_INT = 0x80000000;

	// SinglePosision begin
	public String time;
	public List<Coordinate> coordinates;
	

	public Polygon() {
		
		this.time = NOT_SET;
		this.coordinates = new ArrayList<Coordinate>();
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n"  
				+ "\t\t\ttime " + this.time + "\r\n";
		for (int i=0;i<this.coordinates.size();i++){
			txt = txt + "\t\t\tcoordinate\r\n" + this.coordinates.get(i).toString2() + "\r\n";
		}
				
		txt = txt + "\t\t}\r\n";

		return txt;
	}
	
	private String printVal(int val) {
		if (val == 0x80000000) {
			return NOT_SET;
		}
		return Integer.toString(val);
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

}
