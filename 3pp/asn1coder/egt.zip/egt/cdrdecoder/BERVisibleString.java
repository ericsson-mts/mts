package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public class BERVisibleString extends BERCharacterString
{
    /**  */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new BERVisibleString object.
     *
     * @param string DOCUMENT ME!
     */
    public BERVisibleString(String string)
    {
        super.m_value = string;
    }

    /**
     * Creates a new BERVisibleString object.
     *
     * @param buffer DOCUMENT ME!
     */
    public BERVisibleString(byte[] buffer)
    {
        super(buffer);
    }

    /**
     * Creates a new BERVisibleString object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERVisibleString(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        super(decoder, stream, bytes_read);
    }

    /**
     * Creates a new BERVisibleString object.
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERVisibleString(InputStream stream, int[] bytes_read)
    throws IOException
    {
        super(stream, bytes_read);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return 26;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        if (super.m_value == null)
        {
            return "VisibleString (null)";
        }

        return String.valueOf(String.valueOf((new StringBuffer("VisibleString {")).append(super.m_value).append("}")));
    }
}
