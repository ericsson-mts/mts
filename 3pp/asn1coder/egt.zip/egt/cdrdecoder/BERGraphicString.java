package com.ericsson.mps.egt.cdrdecoder;

import java.io.IOException;
import java.io.InputStream;


/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
 */
public class BERGraphicString extends BERCharacterString
{
/**
     * Creates a new BERGraphicString object.
     */
    public BERGraphicString()
    {
        // TODO Auto-generated constructor stub
    }

/**
     * Creates a new BERGraphicString object.
     *
     * @param string DOCUMENT ME!
     */
    public BERGraphicString(String string)
    {
        super(string);
    }

/**
     * Creates a new BERGraphicString object.
     *
     * @param buffer DOCUMENT ME!
     */
    public BERGraphicString(byte[] buffer)
    {
        super(buffer);
    }

/**
     * Creates a new BERGraphicString object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERGraphicString(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        super(decoder, stream, bytes_read);
    }

/**
     * Creates a new BERGraphicString object.
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERGraphicString(InputStream stream, int[] bytes_read)
    throws IOException
    {
        super(stream, bytes_read);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return 25;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        if (super.m_value == null)
        {
            return "GraphicString (null)";
        }

        return String.valueOf(String.valueOf((new StringBuffer("GraphicString {")).append(super.m_value).append("}")));
    }
}
