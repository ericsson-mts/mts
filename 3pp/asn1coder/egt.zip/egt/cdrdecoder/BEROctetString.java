package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public class BEROctetString extends BERElement
{
    /**  */
    private static final long serialVersionUID = 1L;
    private byte[] m_value;

    /**
     * Creates a new BEROctetString object.
     *
     * @param buffer DOCUMENT ME!
     */
    public BEROctetString(String buffer)
    {
        this.m_value = null;

        if (buffer == null)
        {
            return;
        }

        try
        {
            this.m_value = buffer.getBytes("UTF8");
        }
        catch (Throwable throwable)
        {
            //TODO rien
        }
    }

    /**
     * Creates a new BEROctetString object.
     *
     * @param buffer DOCUMENT ME!
     */
    public BEROctetString(byte[] buffer)
    {
        this.m_value = null;
        this.m_value = buffer;
    }

    /**
     * Creates a new BEROctetString object.
     *
     * @param buffer DOCUMENT ME!
     * @param start DOCUMENT ME!
     * @param end DOCUMENT ME!
     */
    public BEROctetString(byte[] buffer, int start, int end)
    {
        this.m_value = null;
        this.m_value = new byte[end - start];

        for (int i = 0; i < (end - start); i++)
        {
            this.m_value[i] = buffer[start + i];
        }
    }

    /**
     * Creates a new BEROctetString object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BEROctetString(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        this.m_value = null;

        int contents_length = BERElement.readLengthOctets(stream, bytes_read);
        int[] component_length = new int[1];
        BERElement element = null;

        if (contents_length == -1)
        {
            do
            {
                component_length[0] = 0;
                element = BERElement.getElement(decoder, stream, component_length);

                if (element != null)
                {
                    BEROctetString octet_element = (BEROctetString) element;
                    byte[] octet_buffer = octet_element.getValue();

                    if (this.m_value == null)
                    {
                        this.m_value = new byte[octet_buffer.length];
                        System.arraycopy(octet_buffer, 0, this.m_value, 0, octet_buffer.length);
                    }
                    else
                    {
                        byte[] new_buffer = new byte[this.m_value.length + octet_buffer.length];
                        System.arraycopy(this.m_value, 0, new_buffer, 0, this.m_value.length);
                        System.arraycopy(octet_buffer, 0, new_buffer, this.m_value.length, octet_buffer.length);
                        this.m_value = new_buffer;
                    }
                }
            }
            while (element != null);
        }
        else
        {
            bytes_read[0] += contents_length;
            this.m_value = new byte[contents_length];
            stream.read(this.m_value, 0, contents_length);
        }
    }

    /**
     * Creates a new BEROctetString object.
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BEROctetString(InputStream stream, int[] bytes_read)
    throws IOException
    {
        this.m_value = null;

        int contents_length = BERElement.readLengthOctets(stream, bytes_read);

        if (contents_length > 0)
        {
            this.m_value = new byte[contents_length];

            for (int i = 0; i < contents_length; i++)
            {
                this.m_value[i] = (byte) stream.read();
            }

            bytes_read[0] += contents_length;
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public void write(OutputStream stream) throws IOException
    {
        stream.write(4);

        if (this.m_value == null)
        {
            BERElement.sendDefiniteLength(stream, 0);
        }
        else
        {
            BERElement.sendDefiniteLength(stream, this.m_value.length);
            stream.write(this.m_value, 0, this.m_value.length);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public byte[] getValue()
    {
        return this.m_value;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return 4;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        if (this.m_value == null)
        {
            return "OctetString (null)";
        }

        String octets = "";

        for (int i = 0; i < this.m_value.length; i++)
        {
            if (i != 0)
            {
                octets = String.valueOf(String.valueOf(octets)).concat(" ");
            }

            octets = String.valueOf(octets) + String.valueOf(byteToHexString(this.m_value[i]));
        }

        return String.valueOf(String.valueOf((new StringBuffer("OctetString {")).append(octets).append("}")));
    }
}
