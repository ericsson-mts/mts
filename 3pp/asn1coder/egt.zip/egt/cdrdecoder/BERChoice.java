package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
 */
public class BERChoice extends BERElement
{
    /**  */
    private static final long serialVersionUID = 1L;
    public static final boolean DEBUG1 = true;
    private BERElement m_value;

/**
     * Creates a new BERChoice object.
     *
     * @param value DOCUMENT ME!
     */
    public BERChoice(BERElement value)
    {
        this.m_value = null;
        this.m_value = value;
    }

/**
     * Creates a new BERChoice object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERChoice(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        this.m_value = null;

        int iContentLength = BERElement.readLengthOctets(stream, bytes_read);

        if (DEBUG1)
        {
            System.err.println("        BERChoice======== content-length=" + iContentLength);
        }

        int[] component_length = new int[] { 0 };

        this.m_value = BERElement.getElement(decoder, stream, component_length);

        bytes_read[0] += component_length[0];
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public void write(OutputStream stream) throws IOException
    {
        this.m_value.write(stream);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public BERElement getValue()
    {
        return this.m_value;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return -2;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        return String.valueOf(String.valueOf((new StringBuffer("CHOICE {")).append(this.m_value).append("}")));
    }
}
