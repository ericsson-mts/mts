package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;

import java.util.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
 */
public abstract class BERConstruct extends BERElement
{
    public static final boolean DEBUG1 = true;
    private Vector m_elements;

/**
     * Creates a new BERConstruct object.
     */
    public BERConstruct()
    {
        this.m_elements = new Vector();
    }

/**
     * Creates a new BERConstruct object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERConstruct(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        if (DEBUG1)
        {
            System.err.println("        BERConstruct========debut");
        }

        this.m_elements = new Vector();

        int contents_length = BERElement.readLengthOctets(stream, bytes_read);
        int[] component_length = new int[1];

        if (DEBUG1)
        {
            System.err.println("        BERConstruct========contents_length " + contents_length);
        }

        // Set the FlagNewObjet to true for the first element
        BERFlagNewObjet.getInstance().setNewobject(true);

        if (contents_length == -1)
        {
            do
            {
                BERElement element = null;
                component_length[0] = 0;
                element = BERElement.getElement(decoder, stream, component_length);

                if (DEBUG1)
                {
                    System.err.println("        BERConstruct========juste apres BERElement.getElement");
                }

                if (element != null)
                {
                    addElement(element);
                }
                else
                {
                    break;
                }
            }
            while (true);
        }
        else
        {
            bytes_read[0] += contents_length;

            for (; contents_length > 0; contents_length -= component_length[0])
            {
                if (DEBUG1)
                {
                    System.err.println("        BERConstruct========boucle for (remaining content-length="+contents_length+")");
                }

                component_length[0] = 0;
                addElement(BERElement.getElement(decoder, stream, component_length));
                
                if (DEBUG1)
                {
                    System.err.println("        BERConstruct========component-length="+component_length[0]);
                }

                // reset the FlagNewObjet to false after the first element
                BERFlagNewObjet.getInstance().setNewobject(false);
            }
        }

        if (DEBUG1)
        {
            System.err.println("        BERConstruct========fin");
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param element DOCUMENT ME!
     */
    public void addElement(BERElement element)
    {
        this.m_elements.addElement(element);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int size()
    {
        return this.m_elements.size();
    }

    /**
     * DOCUMENT ME!
     *
     * @param index DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public BERElement elementAt(int index)
    {
        return (BERElement) this.m_elements.elementAt(index);
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public void write(OutputStream stream) throws IOException
    {
        stream.write(getType());

        ByteArrayOutputStream contents_stream = new ByteArrayOutputStream();

        for (int i = 0; i < this.m_elements.size(); i++)
        {
            BERElement e = elementAt(i);
            e.write(contents_stream);
        }

        byte[] contents_buffer = contents_stream.toByteArray();
        BERElement.sendDefiniteLength(stream, contents_buffer.length);
        stream.write(contents_buffer);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract int getType();

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract String toString();
}
