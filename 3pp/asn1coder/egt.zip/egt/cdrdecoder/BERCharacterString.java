package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public abstract class BERCharacterString extends BERElement
{
    protected String m_value;
    private byte[] byte_buf;

    /**
     * Creates a new BERCharacterString object.
     */
    public BERCharacterString()
    {
        this.m_value = null;
    }

    /**
     * Creates a new BERCharacterString object.
     *
     * @param string DOCUMENT ME!
     */
    public BERCharacterString(String string)
    {
        this.m_value = null;
        this.m_value = string;
    }

    /**
     * Creates a new BERCharacterString object.
     *
     * @param buffer DOCUMENT ME!
     */
    public BERCharacterString(byte[] buffer)
    {
        this.m_value = null;

        try
        {
            this.m_value = new String(buffer, "UTF8");
        }
        catch (Throwable throwable)
        {
            //TODO rien
        }
    }

    /**
     * Creates a new BERCharacterString object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERCharacterString(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        this.m_value = null;

        int contents_length = BERElement.readLengthOctets(stream, bytes_read);
        int[] component_length = new int[1];
        BERElement element = null;

        if (contents_length == -1)
        {
            do
            {
                component_length[0] = 0;
                element = BERElement.getElement(decoder, stream, component_length);

                if (element != null)
                {
                    BERCharacterString octet_element = (BERCharacterString) element;
                    String string_buffer = octet_element.getValue();

                    if (this.m_value == null)
                    {
                        this.m_value = string_buffer;
                    }
                    else
                    {
                        this.m_value = String.valueOf(this.m_value) + String.valueOf(string_buffer);
                    }
                }
            }
            while (element != null);
        }
        else
        {
            bytes_read[0] += contents_length;

            for (; contents_length > 0; contents_length -= component_length[0])
            {
                component_length[0] = 0;
                element = BERElement.getElement(decoder, stream, component_length);

                if (element == null)
                {
                    continue;
                }

                BERCharacterString octet_element = (BERCharacterString) element;
                String string_buffer = octet_element.getValue();

                if (this.m_value == null)
                {
                    this.m_value = string_buffer;
                }
                else
                {
                    this.m_value = String.valueOf(this.m_value) + String.valueOf(string_buffer);
                }
            }
        }
    }

    /**
     * Creates a new BERCharacterString object.
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERCharacterString(InputStream stream, int[] bytes_read)
    throws IOException
    {
        this.m_value = null;

        int contents_length = BERElement.readLengthOctets(stream, bytes_read);

        if (contents_length > 0)
        {
            byte[] buffer = new byte[contents_length];

            for (int i = 0; i < contents_length; i++)
            {
                buffer[i] = (byte) stream.read();
            }

            bytes_read[0] += contents_length;

            try
            {
                this.m_value = new String(buffer, "UTF8");
            }
            catch (Throwable throwable)
            {
                //TODO rien
            }
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public void write(OutputStream stream) throws IOException
    {
        stream.write(getType());

        if (this.m_value == null)
        {
            BERElement.sendDefiniteLength(stream, 0);
        }
        else
        {
            try
            {
                this.byte_buf = this.m_value.getBytes("UTF8");
                BERElement.sendDefiniteLength(stream, this.byte_buf.length);
            }
            catch (Throwable throwable)
            {
                //TODO rien
            }

            stream.write(this.byte_buf, 0, this.byte_buf.length);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getValue()
    {
        return this.m_value;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract int getType();

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract String toString();
}
