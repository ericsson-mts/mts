package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
  */
public class BERSequence extends BERConstruct
{
    /**  */
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new BERSequence object.
     */
    public BERSequence()
    {
        //TODO rien
    }

    /**
     * Creates a new BERSequence object.
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERSequence(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        super(decoder, stream, bytes_read);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public int getType()
    {
        return 48;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String toString()
    {
        String elements = "";

        for (int i = 0; i < super.size(); i++)
        {
            if (i != 0)
            {
                elements = String.valueOf(String.valueOf(elements)).concat(", ");
            }

            elements = String.valueOf(elements) + String.valueOf(super.elementAt(i).toString());
        }

        return String.valueOf(String.valueOf((new StringBuffer("Sequence {")).append(elements).append("}")));
    }
}
