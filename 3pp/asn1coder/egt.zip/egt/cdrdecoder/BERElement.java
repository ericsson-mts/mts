package com.ericsson.mps.egt.cdrdecoder;

import com.ericsson.mps.egt.exceptions.EndOfStreamException;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;


// Referenced classes of package cdrdecoder:
/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
 */
public abstract class BERElement implements Serializable
{
    public static boolean DEBUG = true;

    //public static boolean DEBUG = true;
    public static final int TAG = -1;
    public static final int CHOICE = -2;
    public static final int ANY = -3;
    public static final int EOC = 0;
    public static final int UNIVERSAL = 0;
    public static final int APPLICATION = 64;
    public static final int CONTEXT = 128;
    public static final int SASLCONTEXT = 160;
    public static final int PRIVATE = 192;
    public static final int PRIMITIVE = 0;
    public static final int CONSTRUCTED = 32;
    public static final int MRA_OID = 1;
    public static final int MRA_TYPE = 2;
    public static final int MRA_VALUE = 3;
    public static final int MRA_DNATTRS = 4;
    public static final int EXOP_REQ_OID = 0;
    public static final int EXOP_REQ_VALUE = 1;
    public static final int EXOP_RES_OID = 10;
    public static final int EXOP_RES_VALUE = 11;
    public static final int SK_MATCHRULE = 0;
    public static final int SK_REVERSE = 1;
    public static final int SR_ATTRTYPE = 0;

/**
     * Creates a new BERElement object.
     */
    public BERElement()
    {
        //TODO rien
    }

    /**
     * DOCUMENT ME!
     *
     * @param decoder DOCUMENT ME!
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public static BERElement getElement(BERTagDecoder decoder, InputStream stream, int[] bytes_read)
    throws IOException
    {
        if (DEBUG)
        {
            System.err.println("    BERElement getElement==============debut");
        }

        BERElement element = null;

        int iTag = stream.read();
        int iTagGenericPart = iTag & 0xDF;
        boolean isGeneric = ((iTag & 0x20) == 0);

        if (DEBUG)
        {
            System.err.println("    BERElement getElement==============" + iTag + " " + iTagGenericPart);
        }

        bytes_read[0] = 1;

        if (iTag == 0)
        {
            stream.read();
            bytes_read[0] = 1;
            element = null;
        }
        else if (iTagGenericPart == ASN1_TYPES.BOOLEAN) // 1
        {
            element = new BERBoolean(stream, bytes_read);
        }
        else if (iTagGenericPart == ASN1_TYPES.INTEGER) // 2
        {
            element = new BERInteger(stream, bytes_read);
        }
        else if (iTagGenericPart == ASN1_TYPES.BITSTRING) // 3
        {
            if (isGeneric)
            {
                element = new BERBitString(stream, bytes_read);
            }
            else
            {
                element = new BERBitString(decoder, stream, bytes_read); // Tag == 35
            }
        }
        else if (iTagGenericPart == ASN1_TYPES.OCTETSTRING) // 4
        {
            if (isGeneric)
            {
                element = new BEROctetString(stream, bytes_read);
            }
            else
            {
                element = new BEROctetString(decoder, stream, bytes_read); // Tag == 36
            }
        }
        else if (iTagGenericPart == ASN1_TYPES.NULL) // 5
        {
            element = new BERNull(stream, bytes_read);
        }
        else if (iTagGenericPart == ASN1_TYPES.OBJECTID) // 6
        {
            element = new BERObjectId(stream, bytes_read);
        }
        else if (iTagGenericPart == ASN1_TYPES.REAL) // 9
        {
            element = new BERReal(stream, bytes_read);
        }
        else if (iTagGenericPart == ASN1_TYPES.ENUMERATED) // 10
        {
            element = new BEREnumerated(stream, bytes_read);
        }
        else if (iTagGenericPart == ASN1_TYPES.SEQUENCE_OF) // 16
        {
            if (isGeneric)
            {
                element = new BERSequence(decoder, stream, bytes_read);
            }
            else
            {
                element = new BERSequence(decoder, stream, bytes_read); // Tag == 48
            }
        }
        else if (iTagGenericPart == ASN1_TYPES.SET_OF) // 17
        {
            if (isGeneric)
            {
                element = new BERSet(decoder, stream, bytes_read);
            }
            else
            {
                element = new BERSet(decoder, stream, bytes_read); // Tag == 49
            }
        }
        else if (iTagGenericPart == ASN1_TYPES.NUMERICSTRING) // 18
        {
            if (isGeneric)
            {
                element = new BERNumericString(stream, bytes_read);
            }
            else
            {
                element = new BERNumericString(decoder, stream, bytes_read); // Tag == 50
            }
        }
        else if (iTagGenericPart == ASN1_TYPES.PRINTABLESTRING) // 19
        {
            if (isGeneric)
            {
                element = new BERPrintableString(stream, bytes_read);
            }
            else
            {
                element = new BERPrintableString(decoder, stream, bytes_read); // Tag == 51
            }
        }

        else if (iTagGenericPart == ASN1_TYPES.UTCTIME) // 23
        {
            if (isGeneric)
            {
                element = new BERUTCTime(stream, bytes_read);
            }
            else
            {
                element = new BERUTCTime(decoder, stream, bytes_read); // Tag == 55
            }
        }
        else if (iTagGenericPart == ASN1_TYPES.VISIBLESTRING) // 26
        {
            if (isGeneric)
            {
                element = new BERVisibleString(stream, bytes_read);
            }
            else
            {
                element = new BERVisibleString(decoder, stream, bytes_read); // Tag == 58
            }
        }
        else if (iTagGenericPart == ASN1_TYPES.GET_TAG) // 31 else if ((iTag & 0x1F) == ASN1_TYPES.GET_TAG)
        {
            iTag = stream.read();
            bytes_read[0]++;
            element = new BERTag(decoder, iTag, stream, bytes_read);
        }

        //        else if (iTagGenericPart == ASN1_TYPES.IA5STRING) // 22
        //        {
        //            // TODO NEW !!!
        //            if (isGeneric)
        //            {
        //                element = new BERPrintableString(stream, bytes_read);
        //            }
        //            else
        //            {
        //                element = new BERPrintableString(decoder, stream, bytes_read); // Tag == 54
        //            }
        //        }
        //        else if (iTagGenericPart == ASN1_TYPES.GRAPHICSTRING) // 25
        //        {
        //            // TODO NEW !!!
        //            if (isGeneric)
        //            {
        //                element = new BERGraphicString(stream, bytes_read);
        //            }
        //            else
        //            {
        //                element = new BERGraphicString(decoder, stream, bytes_read);
        //            }
        //        }
        else if ((iTag & 0xC0) > 0)
        {
            element = new BERTag(decoder, iTag, stream, bytes_read);
        }
        else
        {
            throw new IOException("invalid tag ".concat(String.valueOf(String.valueOf(iTag))));
        }

        if (DEBUG)
        {
            System.err.println("    BERElement getElement==============fin");
        }

        return element;
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     * @throws EndOfStreamException DOCUMENT ME!
     */
    public static int readLengthOctets(InputStream stream, int[] bytes_read)
    throws IOException
    {
        int contents_length = 0;
        int octet = stream.read();

        if (octet == -1)
        {
            throw new EndOfStreamException("end of stream reached");
        }
        else
        {
            bytes_read[0]++;

            if (octet == 128)
            {
                contents_length = -1;
            }
            else if ((octet & 0x80) > 0)
            {
                int iLengthOctetsCount = (octet & 0x7F);

                int num_length_octets = octet & 0x7f;

                for (int i = 0; i < num_length_octets; i++)
                {
                    octet = stream.read();
                    bytes_read[0]++;
                    contents_length = (contents_length << 8) + octet;
                }

                System.err.println("LONGUEUR : " + contents_length + " codage " + iLengthOctetsCount + " octet(s)");
            }
            else
            {
                contents_length = octet;
            }

            return contents_length;
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     * @param num_content_octets DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public static void sendDefiniteLength(OutputStream stream, int num_content_octets)
    throws IOException
    {
        if (num_content_octets <= 127)
        {
            stream.write(num_content_octets);
        }
        else
        {
            int num_length_octets = 0;
            int num = num_content_octets;

            do
            {
                if (num < 0)
                {
                    break;
                }

                num_length_octets++;
                num >>= 8;
            }
            while (num > 0);

            byte[] buffer = new byte[num_length_octets + 1];
            buffer[0] = (byte) (0x80 | num_length_octets);
            num = num_content_octets;

            for (int i = num_length_octets; i > 0; i--)
            {
                buffer[i] = (byte) (num & 0xff);
                num >>= 8;
            }

            stream.write(buffer);
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     * @param length DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    protected int readUnsignedBinary(InputStream stream, int[] bytes_read, int length)
    throws IOException
    {
        int value = 0;

        for (int i = 0; i < length; i++)
        {
            int octet = stream.read();
            bytes_read[0]++;
            value = (value << 8) + octet;
        }

        return value;
    }

    /**
     * DOCUMENT ME!
     *
     * @param stream DOCUMENT ME!
     * @param bytes_read DOCUMENT ME!
     * @param length DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    protected int readTwosComplement(InputStream stream, int[] bytes_read, int length)
    throws IOException
    {
        int value = 0;

        if (length > 0)
        {
            boolean negative = false;
            int octet = stream.read();
            bytes_read[0]++;

            if ((octet & 0x80) > 0)
            {
                negative = true;
            }

            for (int i = 0; i < length; i++)
            {
                if (i > 0)
                {
                    octet = stream.read();
                    bytes_read[0]++;
                }

                if (negative)
                {
                    value = ((value << 8) + (octet ^ 0xff)) & 0xff;
                }
                else
                {
                    value = (value << 8) + (octet & 0xff);
                }
            }

            if (negative)
            {
                value = (value + 1) * -1;
            }
        }

        return value;
    }

    /**
     * DOCUMENT ME!
     *
     * @param value DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String byteToHexString(byte value)
    {
        if (value < 0)
        {
            return Integer.toHexString((value & 0x7f) + 128);
        }

        return Integer.toHexString(value);
    }

    /**
     * DOCUMENT ME!
     *
     * @param outputstream DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public abstract void write(OutputStream outputstream)
    throws IOException;

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract int getType();

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public abstract String toString();

    /**
     * DOCUMENT ME!
     *
     * @author $author$
     * @version $Revision$
     */
    public final static class ASN1_TYPES
    {
        public static final int BOOLEAN = 1;
        public static final int INTEGER = 2;
        public static final int BITSTRING = 3;
        public static final int OCTETSTRING = 4;
        public static final int NULL = 5;
        public static final int OBJECTID = 6;
        public static final int REAL = 9;
        public static final int ENUMERATED = 10;
        public static final int SET = 49;
        public static final int SEQUENCE = 48;
        public static final int SEQUENCE_OF = 16; // Added by EJEALAM on 2011-01-06
        public static final int SET_OF = 17; // Added by EJEALAM on 2011-01-06
        public static final int NUMERICSTRING = 18;
        public static final int PRINTABLESTRING = 19;
        public static final int TELETEXSTRING = 20;
        public static final int VIDEOTEXSTRING = 21;
        public static final int IA5STRING = 22;
        public static final int UTCTIME = 23;
        public static final int GRAPHICSTRING = 25;
        public static final int VISIBLESTRING = 26;
        public static final int GENERALSTRING = 27;
        public static final int GET_TAG = 31;
    }

    /*static {
       BOOLEAN = 1;
       INTEGER = 2;
       BITSTRING = 3;
       OCTETSTRING = 4;
       NULL = 5;
       OBJECTID = 6;
       REAL = 9;
       ENUMERATED = 10;
       SET = 49;
       SEQUENCE = 48;
       NUMERICSTRING = 18;
       PRINTABLESTRING = 19;
       TELETEXSTRING = 20;
       VIDEOTEXSTRING = 21;
       IA5STRING = 22;
       UTCTIME = 23;
       GRAPHICSTRING = 25;
       VISIBLESTRING = 26;
       GENERALSTRING = 27;
       GET_TAG = 31;
       TAG = -1;
       CHOICE = -2;
       ANY = -3;
       EOC = 0;
       UNIVERSAL = 0;
       APPLICATION = 64;
       CONTEXT = 128;
       SASLCONTEXT = 160;
       PRIVATE = 192;
       PRIMITIVE = 0;
       CONSTRUCTED = 32;
       MRA_OID = 1;
       MRA_TYPE = 2;
       MRA_VALUE = 3;
       MRA_DNATTRS = 4;
       EXOP_REQ_OID = 0;
       EXOP_REQ_VALUE = 1;
       EXOP_RES_OID = 10;
       EXOP_RES_VALUE = 11;
       SK_MATCHRULE = 0;
       SK_REVERSE = 1;
       SR_ATTRTYPE = 0;
        }*/
}
