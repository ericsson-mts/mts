package com.ericsson.mps.egt.cdrdecoder;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

import java.io.*;

// Referenced classes of package cdrdecoder:
//            BERElement

public abstract class BERIntegral
    extends BERElement {

  private int m_value;

  public BERIntegral(int value) {
    this.m_value = value;
  }

  public BERIntegral(InputStream stream, int bytes_read[]) throws IOException {
    int contents_length = BERElement.readLengthOctets(stream, bytes_read);
    if (contents_length > 0) {
      boolean negative = false;
      int octet = stream.read();
      bytes_read[0]++;
      if ( (octet & 0x80) > 0) {
        negative = true;
      }
      for (int i = 0; i < contents_length; i++) {
        if (i > 0) {
          octet = stream.read();
          bytes_read[0]++;
        }
        if (negative) {
          this.m_value = (this.m_value << 8) + (octet ^ 0xff) & 0xff;
        }
        else {
          this.m_value = (this.m_value << 8) + (octet & 0xff);
        }
      }

      if (negative) {
        this.m_value = (this.m_value + 1) * -1;
      }
    }
  }

  public void write(OutputStream stream) throws IOException {
    int binary_value = this.m_value;
    int num_content_octets = 0;
    int offset = 1;
    byte content_octets[] = new byte[10];
    byte net_octets[] = new byte[10];
    if (this.m_value == 0) {
      num_content_octets = 1;
      content_octets[offset] = 0;
      net_octets[offset] = 0;
    }
    else {
      if (this.m_value < 0) {
        binary_value = this.m_value * -1 - 1;
      }
      do {
        if (this.m_value < 0) {
          content_octets[num_content_octets +
              offset] = (byte) ( (binary_value ^ 0xff) & 0xff);
        }
        else {
          content_octets[num_content_octets +
              offset] = (byte) (binary_value & 0xff);
        }
        binary_value >>= 8;
        num_content_octets++;
      }
      while (binary_value > 0);
      for (int i = 0; i < num_content_octets; i++) {
        net_octets[ (offset + num_content_octets) - 1 -
            i] = content_octets[offset + i];
      }

      int lead = net_octets[offset];
      if (this.m_value > 0 && (lead & 0x80) > 0) {
        offset = 0;
        net_octets[offset] = 0;
        num_content_octets++;
      }
    }
    stream.write(getType());
    BERElement.sendDefiniteLength(stream, num_content_octets);
    stream.write(net_octets, offset, num_content_octets);
  }

  public int getValue() {
    return this.m_value;
  }

  public abstract int getType();

  public abstract String toString();
}
