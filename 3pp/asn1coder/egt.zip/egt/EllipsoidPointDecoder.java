package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (not in MPS7)
 * EllipsoidPoint ::= SEQUENCE 
 * { 
 * latitude             [1] IMPLICIT IA5String, 
 * longitude            [2] IMPLICIT IA5String, 
 * time          		[3] IMPLICIT IA5String 
 * } 
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EllipsoidPointDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  public static final int LATITUDE = 1;
  public static final int LONGITUDE = 2;
  public static final int TIME = 3;

  private EllipsoidPoint ellipsoidPoint;

  public EllipsoidPointDecoder(EllipsoidPoint ellips) {
	  this.ellipsoidPoint = ellips;
  }
  
  public EllipsoidPoint getEllipsoidPoint() {
  	return this.ellipsoidPoint;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("EllipsoidPoint ========================== " + tag);
    }

    // LATITUDE
    if (tag == (LATITUDE | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPoint.latitude = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidPoint latitude ========================== " + this.ellipsoidPoint.latitude);
        }
        return b;
    }
    
    // LONGITUDE
    if (tag == (LONGITUDE | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPoint.longitude = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidPoint longitude ========================== " + this.ellipsoidPoint.longitude);
        }
        return b;
    }
    
    // TIME
    if (tag == (TIME | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPoint.time = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidPoint time ========================== " + this.ellipsoidPoint.time);
        }
        return b;
    }
    
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.ellipsoidPoint.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("EllipsoidPoint setUnknownTag ========================== " + this.ellipsoidPoint.getUnknownTags());
    }
    return b;
  }





}