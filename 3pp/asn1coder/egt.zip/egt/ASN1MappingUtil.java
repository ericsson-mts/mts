package com.ericsson.mps.egt;

public class ASN1MappingUtil {
	
	final static public int NETWORK_UNKNOWN_ASN1CODE = 0;
	final static public int NETWORK_2G_ASN1CODE = 1;
	final static public int NETWORK_3G_ASN1CODE = 2;
	
	final static public String NETWORK_UNKNOWN_MSG = "unknown";
	final static public String NETWORK_2G_MSG = "network2G";
	final static public String NETWORK_3G_MSG = "network3G";
	
	public static String mapIntToString(int value, String parameterName){
		
		String result = null;
		
		if (parameterName.equalsIgnoreCase("network")){
			switch(value){
				case ASN1MappingUtil.NETWORK_UNKNOWN_ASN1CODE:
					result = ASN1MappingUtil.NETWORK_UNKNOWN_MSG;
					break;
				case ASN1MappingUtil.NETWORK_2G_ASN1CODE:
					result = ASN1MappingUtil.NETWORK_2G_MSG;
					break;
				case ASN1MappingUtil.NETWORK_3G_ASN1CODE:
					result = ASN1MappingUtil.NETWORK_3G_MSG;
					break;
				default:
					result = ASN1MappingUtil.NETWORK_UNKNOWN_MSG;
					break;
			}
		}
		return result;
	}
}
