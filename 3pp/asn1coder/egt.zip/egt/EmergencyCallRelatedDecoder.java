package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (Not in MPS7)
 * EmergencyCallRelated ::= SEQUENCE 
 *{ 
 * clientNo           [1] IMPLICIT IA5String, 
 * mSISDN             [2] IMPLICIT IA5String OPTIONAL, 
 * iMEI               [3] IMPLICIT IA5String OPTIONAL, 
 * iMSI               [4] IMPLICIT IA5String OPTIONAL, 
 * positionResult     [5] EXPLICIT EmergencyPositionResult OPTIONAL, 
 * network            [6] IMPLICIT Network OPTIONAL,
 * usedlocationmethod [7] IMPLICIT UsedLocationMethod OPTIONAL
 *} 
*/

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyCallRelatedDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int CLIENTNO = 1;
  public static final int MSISDN = 2;
  public static final int IMEI = 3;
  public static final int IMSI = 4;
  public static final int POSITIONRESULT = 5;
  public static final int NETWORK = 6;
  public static final int USEDLOCATIONMETHOD = 7;

  private EmergencyCallRelated emergencyCallRelated;

  public EmergencyCallRelatedDecoder(EmergencyCallRelated emergencyCR) {
	  this.emergencyCallRelated = emergencyCR;
  }
  
  public EmergencyCallRelated getEmergencyCallRelated() {
  	return this.emergencyCallRelated;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("emergencyCallRelated ========================== " + tag);
    }

    // CLIENTNO
    if (tag == (CLIENTNO | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyCallRelated.clientNo = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyCallRelated clientNo ========================== " + this.emergencyCallRelated.clientNo);
        }
        return b;
    }
    
    // MSISDN
    if (tag == (MSISDN | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyCallRelated.mSISDN = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyCallRelated mSISDN ========================== " + this.emergencyCallRelated.mSISDN);
        }
        return b;
    }
    
    // IMEI
    if (tag == (IMEI | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyCallRelated.iMEI = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyCallRelated iMEI ========================== " + this.emergencyCallRelated.iMEI);
        }
        return b;
    }
    
    // IMSI
    if (tag == (IMSI | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyCallRelated.iMSI = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyCallRelated iMSI ========================== " + this.emergencyCallRelated.iMSI);
        }
        return b;
    }
    
	 //	POSITIONRESULT
	 if (tag == (POSITIONRESULT | 0x80 | 0x20 )) {
		  EmergencyPositionResultDecoder EmergencyPositionResult_decoder = new EmergencyPositionResultDecoder(this.emergencyCallRelated.positionResult);
	      BERChoice b = new BERChoice(EmergencyPositionResult_decoder, io, ia);
	      this.emergencyCallRelated.positionResult = EmergencyPositionResult_decoder.getEmergencyPositionResult();
	      if (DEBUG) {
	          System.err.println("emergencyCallRelated positionResult ==========================");
	      }
	      return b;
	 }
    
    // NETWORK
    if (tag == (NETWORK | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
        this.emergencyCallRelated.network =b.getValue();
    	if (DEBUG) {
    		System.err.println( "emergencyCallRelated network ========================== " + this.emergencyCallRelated.network);
        }
        return b;
    }
    
    // USEDLOCATIONMETHOD
    if (tag == (USEDLOCATIONMETHOD | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
        this.emergencyCallRelated.usedlocationmethod =b.getValue();
    	if (DEBUG) {
    		System.err.println( "emergencyCallRelated usedlocationmethod ========================== " + this.emergencyCallRelated.usedlocationmethod);
        }
        return b;
    }
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.emergencyCallRelated.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("emergencyCallRelated setUnknownTag ========================== " + this.emergencyCallRelated.getUnknownTags());
    }
    return b;
  }





}