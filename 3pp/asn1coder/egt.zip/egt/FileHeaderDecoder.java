package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

import java.io.*;


/**
 * ASN1 MPS9  (=MPS7) FileHeader ::= SEQUENCE { sourceName             [1] IMPLICIT IA5String, fileName
 * [2] IMPLICIT IA5String, date                   [3] IMPLICIT IA5String, noOfRecords            [4] IMPLICIT
 * INTEGER }
 */
/**
 * <p>Titre : EGT</p>
 *  <p>Description : enrichisement des log GMPC</p>
 *  <p>Copyright : Copyright (c) 2008</p>
 *  <p>Soci�t� : Ericsson</p>
 *
 * @author esforcs
 * @version R3-CP00
 */
public class FileHeaderDecoder extends BERTagDecoder
{
    public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
    public static final int SOURCENAME = 1;
    public static final int FILENAME = 2;
    public static final int DATE = 3;
    public static final int NOOFRECORDS = 4;
    private CDR cdr;

    /**
     * Creates a new FileHeaderDecoder object.
     *
     * @param Cdr DOCUMENT ME!
     */
    public FileHeaderDecoder(CDR Cdr)
    {
        this.cdr = Cdr;
    }

    /**
     * DOCUMENT ME!
     *
     * @param dec DOCUMENT ME!
     * @param tag DOCUMENT ME!
     * @param io DOCUMENT ME!
     * @param ia DOCUMENT ME!
     * @param implicit DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERElement getElement(BERTagDecoder dec, int tag, InputStream io, int[] ia, boolean[] implicit)
    throws IOException
    {
        if (DEBUG)
        {
            System.err.println("FileHeader getElement ========================== " + tag);
        }

        if (tag == (SOURCENAME | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            this.cdr.sourceName = new String(b.getValue(), 0, b.getValue().length);

            if (DEBUG)
            {
                System.err.println("FileHeader SOURCENAME ========================== " + this.cdr.sourceName);
            }

            return b;
        }

        if (tag == (FILENAME | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            this.cdr.fileName = new String(b.getValue(), 0, b.getValue().length);

            if (DEBUG)
            {
                System.err.println("FileHeader FILENAME ==========================" + this.cdr.fileName);
            }

            return b;
        }

        if (tag == (DATE | 0x80))
        {
            BEROctetString b = new BEROctetString(dec, io, ia);
            this.cdr.date = new String(b.getValue(), 0, b.getValue().length);

            if (DEBUG)
            {
                System.err.println("FileHeader DATE ==========================" + this.cdr.date);
            }

            return b;
        }

        if (tag == (NOOFRECORDS | 0x80))
        {
            BERInteger b = new BERInteger(io, ia);
            this.cdr.noOfRecords = b.getValue();

            if (DEBUG)
            {
                System.err.println("FileHeader NOOFRECORDS ==========================" + this.cdr.noOfRecords);
            }

            return b;
        }

        BEROctetString b = new BEROctetString(dec, io, ia);
        this.cdr.setUnknownTag(b, tag);

        return b;
    }
}
