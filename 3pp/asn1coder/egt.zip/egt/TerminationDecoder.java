package com.ericsson.mps.egt;

import java.io.IOException;
import java.io.InputStream;

import com.ericsson.mps.egt.cdrdecoder.BERElement;
import com.ericsson.mps.egt.cdrdecoder.BEREnumerated;
import com.ericsson.mps.egt.cdrdecoder.BERInteger;
import com.ericsson.mps.egt.cdrdecoder.BEROctetString;
import com.ericsson.mps.egt.cdrdecoder.BERSequence;
import com.ericsson.mps.egt.cdrdecoder.BERTagDecoder;

/**
* ASN1 MPS9 (<> MPS7)
* Termination ::= SEQUENCE
* {
* requestId               [1]  IMPLICIT IA5String,
* triggerCriterionType    [2]  IMPLICIT TriggerCriterionType OPTIONAL,
* clientId                [3]  IMPLICIT IA5String,
* clientNo                [4]  IMPLICIT IA5String,
* subscriberDataList      [5]  IMPLICIT SEQUENCE OF SubscriberData OPTIONAL,
* speed                   [6]  IMPLICIT INTEGER,
* terminationTime         [7]  IMPLICIT IA5String,
* errorCode               [8]  IMPLICIT INTEGER,
* startTime               [9]  IMPLICIT IA5String OPTIONAL,
* stopTime                [10] IMPLICIT IA5String OPTIONAL
*}
*/

public class TerminationDecoder  extends BERTagDecoder {
	public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;

	public static final int REQUESTID = 1;
	public static final int TRIGGERCRITERIONTYPE = 2;
	public static final int CLIENTID = 3;
	public static final int CLIENTNO = 4;
	public static final int SUBSCRIBERDATALIST = 5;
	public static final int SPEED = 6;
	public static final int TERMINATIONTIME = 7;
	public static final int ERRORCODE = 8;
	public static final int STARTTIME = 9;
	public static final int STOPTIME = 10;
  
	  private CDR cdr;
	  public TerminationDecoder(CDR Cdr) {
	    this.cdr = Cdr;
	  }

	  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
	                               int ia[], boolean implicit[]) throws IOException {
		  if (DEBUG) {
				System.err.println("Termination getElement ========================== " + tag);
			}
			if (tag == (REQUESTID | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.cdr.terminationRequestId = new String(b.getValue(), 0,
						b.getValue().length);
				if (DEBUG) {
					System.err
							.println("Termination requestId ========================== "
									+ this.cdr.terminationRequestId);
				}
				return b;
			}
			if (tag == (TRIGGERCRITERIONTYPE | 0x80)) {
				BEREnumerated b = new BEREnumerated(io, ia);
				this.cdr.terminationTriggerCriterionType = b.getValue();
				if (DEBUG) {
					System.err
							.println("Termination triggerCriterionType ========================== "
									+ this.cdr.terminationTriggerCriterionType);
				}
				return b;
			}
			if (tag == (CLIENTID | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.cdr.terminationClientId = new String(b.getValue(), 0,
						b.getValue().length);
				if (DEBUG) {
					System.err
							.println("Termination clientId ========================== "
									+ this.cdr.terminationClientId);
				}
				return b;
			}
			if (tag == (CLIENTNO | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.cdr.terminationClientNo = new String(b.getValue(), 0,
						b.getValue().length);
				if (DEBUG) {
					System.err
							.println("Termination clientNo ========================== "
									+ this.cdr.terminationClientNo);
				}
				return b;
			}

			if (tag == (SUBSCRIBERDATALIST | 0x80 | 0x20)) {
				 SubscriberDataDecoder subscriberDataDecoder = new
				 SubscriberDataDecoder(this.cdr);
			      BERSequence brs = new BERSequence(subscriberDataDecoder, io, ia);
			      if (DEBUG) {
			        System.err.println(
			            "Termination subscriberDataList ==========================");

			      }
			      return brs;
			    }

			if (tag == (SPEED | 0x80)) {
				BEREnumerated b = new BEREnumerated(io, ia);
				this.cdr.terminationspeed = b.getValue();
				if (DEBUG) {
					System.err
							.println("Termination speed ========================== "
									+ this.cdr.terminationspeed);
				}
				return b;
			}
			
			if (tag == (TERMINATIONTIME | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.cdr.terminationTime = new String(b.getValue(), 0,
						b.getValue().length);
				if (DEBUG) {
					System.err
							.println("Termination terminationTime ========================== "
									+ this.cdr.terminationTime);
				}
				return b;
			}
			if (tag == (ERRORCODE | 0x80)) {
				BERInteger b = new BERInteger(io, ia);
				this.cdr.terminationErrorCode = b.getValue();
				if (DEBUG) {
					System.err
							.println("Termination errorCode ========================== "
									+ this.cdr.terminationErrorCode);
				}
				return b;
			}
			if (tag == (STARTTIME | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.cdr.terminationStartTime = new String(b.getValue(), 0,
						b.getValue().length);
				if (DEBUG) {
					System.err
							.println("Termination startTime ========================== "
									+ this.cdr.terminationStartTime);
				}
				return b;
			}
			if (tag == (STOPTIME | 0x80)) {
				BEROctetString b = new BEROctetString(dec, io, ia);
				this.cdr.terminationStopTime = new String(b.getValue(), 0,
						b.getValue().length);
				if (DEBUG) {
					System.err
							.println("Termination StopTime ========================== "
									+ this.cdr.terminationStopTime);
				}
				return b;
			}
		BEROctetString b = new BEROctetString(dec, io, ia);
	      this.cdr.setUnknownTag(b, tag);
	      return b;
	  }

	}