package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * QoS ::= SEQUENCE
 * {
 * requestedAccuracy 		[1] IMPLICIT HorizontalAccuracy,
 * requestedAccuracyMeters [2] IMPLICIT INTEGER,
 * responseTime 			[3] IMPLICIT ResponseTime,
 * maxLocationAge 			[4] IMPLICIT INTEGER OPTIONAL
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class QoS {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";
	private static final int NOT_SET_INT = 0x80000000;

	public int requestedAccuracy;
	public int requestedAccuracyMeters;
	public int responseTime;
	public int maxLocationAge;


	public QoS() {

		this.requestedAccuracy = NOT_SET_INT;
		this.requestedAccuracyMeters = NOT_SET_INT;
		this.responseTime = NOT_SET_INT;
		this.maxLocationAge = NOT_SET_INT;
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n"  
			+ "\t\t\trequestedAccuracy " + this.requestedAccuracy + "\r\n"
			+ "\t\t\trequestedAccuracyMeters " + this.requestedAccuracyMeters + "\r\n"
			+ "\t\t\tresponseTime " + this.responseTime + "\r\n"
			+ "\t\t\tmaxLocationAge " + this.maxLocationAge + "\r\n";

		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

}
