package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.BEROctetString;

/**
 * ASN1 MPS9 (Not in MPS7)
 * EmergencyPositionResult ::= CHOICE 	
 *			{ 	
 *			 ellipsoidPoint   [1]  IMPLICIT  EllipsoidPoint, 	
 *
 *				EllipsoidPoint ::= SEQUENCE 
 *				{ 
 *				 latitude      [1]  IMPLICIT IA5String, 
 *				 longitude     [2]  IMPLICIT IA5String, 
 *				 time          [3]  IMPLICIT IA5String 
 *				} 
 * 
 *			 ellipsoidPointWithUncertaintyEllipse     [2]  IMPLICIT   EllipsoidPointWithUncertaintyEllipse, 	
 *
 * 				EllipsoidPointWithUncertaintyEllipse ::= SEQUENCE 
 *				{ 
 *				    time              [1]  IMPLICIT IA5String, 
 *				    coordinate        [2]  IMPLICIT Coordinate, 
 *				    angle             [3]  IMPLICIT IA5String, 
 *				    semiMajor         [4]  IMPLICIT IA5String, 
 *				    semiMinor         [5]  IMPLICIT IA5String 
 *				} 
 *
 *			 ellipsoidPointWithUncertaintyCircle      [3]  IMPLICIT EllipsoidPointWithUncertaintyCircle, 	
 *
 *				EllipsoidPointWithUncertaintyCircle ::= SEQUENCE 
 *				{ 
 *				    time                         [1] IMPLICIT IA5String, 
 *				    coordinate                   [2] IMPLICIT Coordinate, 
 *				    radius                       [3] IMPLICIT IA5String 
 *				} 
 *			 errorId                             [4]  IMPLICIT INTEGER 	
 *			} 	
*/

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyPositionResult {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";
	private static final int NOT_SET_INT = 0x80000000;

	// begin EmergencyPositionResult
	public int EmergencyPositionResult_tag; // To store the value of choice 
	public EllipsoidPoint ellipsoidPoint;
	public EllipsoidPointWithUncertaintyEllipse ellipsoidPointWithUncertaintyEllipse;
	public EllipsoidPointWithUncertaintyCircle ellipsoidPointWithUncertaintyCircle;
	public EllipsoidArc ellipsoidArc; 							
	public Polygon polygon; 							
	public int errorId;
	// end EmergencyPositionResult

	public EmergencyPositionResult() {
		// begin EmergencyPositionResult
		this.EmergencyPositionResult_tag = NOT_SET_INT;
		this.ellipsoidPoint = new EllipsoidPoint();
		this.ellipsoidPointWithUncertaintyEllipse = new EllipsoidPointWithUncertaintyEllipse();
		this.ellipsoidPointWithUncertaintyCircle = new EllipsoidPointWithUncertaintyCircle();
		this.ellipsoidArc = new EllipsoidArc();
		this.polygon = new Polygon();
		this.errorId = NOT_SET_INT;
		// end EmergencyPositionResult		
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag
				+ " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : "
					+ this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n" 
				+ "\t\t\tellipsoidPoint " + this.ellipsoidPoint.toString2() + "\r\n"
				+ "\t\t\tellipsoidPointWithUncertaintyEllipse " 
				+ this.ellipsoidPointWithUncertaintyEllipse.toString2() + "\r\n" 
				+ "\t\t\tellipsoidPointWithUncertaintyCircle " 
				+ this.ellipsoidPointWithUncertaintyCircle.toString2() + "\r\n" 
				+ "\t\t\tellipsoidArc " 
				+ this.ellipsoidArc.toString2() + "\r\n" 
				+ "\t\t\tpolygon " 
				+ this.polygon.toString2() + "\r\n" 
				+ "\t\t\terrorId " + printVal(this.errorId) + "\r\n"			
				+ "\t\t}\r\n";
		return txt;
	}

	public String toLog() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}
	
	private String printVal(int val) {
		if (val == 0x80000000) {
			return NOT_SET;
		}
		return Integer.toString(val);
	}

}
