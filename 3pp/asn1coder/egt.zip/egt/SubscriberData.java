package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.BEROctetString;

/**
 * ASN1 MPS9 (<>MPS7)
 * SubscriberData ::= SEQUENCE
 * {
 * targetMS                [1] IMPLICIT IA5String,
 * numberMSC               [2] IMPLICIT IA5String OPTIONAL,
 * positionTime            [3] IMPLICIT IA5String OPTIONAL,
 * network                 [4] IMPLICIT Network OPTIONAL,
 * usedlocationmethod      [5] IMPLICIT UsedLocationMethod OPTIONAL
 *}
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R3-CP00
 */

public class SubscriberData {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";

	private static final int NOT_SET_INT = 0x80000000;

	// begin SubscriberData
	public String targetMS;
	public String numberMSC;
	public String positionTime;
	public int network;
	public int usedlocationmethod;
	// end SubscriberData

	public SubscriberData() {
		
		// SubscriberData begin
		this.targetMS = NOT_SET;
		this.numberMSC = NOT_SET;
		this.positionTime = NOT_SET;
		this.network = NOT_SET_INT;
		this.usedlocationmethod = NOT_SET_INT;		
		// SubscriberData end
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag
				+ " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : "
					+ this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n" 
				+ "\t\t\ttargetMS " + this.targetMS + "\r\n"
				+ "\t\t\tnumberMSC " + this.numberMSC + "\r\n"
				+ "\t\t\tpositionTime " + this.positionTime + "\r\n"
				+ "\t\t\tnetwork " + printVal(this.network) + "\r\n"
				+ "\t\t\tusedlocationmethod " + printVal(this.usedlocationmethod) + "\r\n"			
				+ "\t\t}\r\n";
		return txt;
	}

	public String toLog() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = this.targetMS + " " + this.numberMSC + " ";
		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}
	
	private String printVal(int val) {
		if (val == 0x80000000) {
			return NOT_SET;
		}
		return Integer.toString(val);
	}

}
