package com.ericsson.mps.egt;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import org.apache.log4j.Logger;

import java.io.File;


/**
 * <p>Titre : EGT</p>
 *  <p>Description : enrichisement des log GMPC</p>
 *  <p>Copyright : Copyright (c) 2008</p>
 *  <p>Soci�t� : Ericsson</p>
 *
 * @author esforcs
 * @version R1-CP00
 */
public class EgtConfig extends PropertiesConfiguration implements Runnable
{
    public static boolean DEBUG = false;
    private static String configFile;
    private static boolean goOn = false;

    static
    {
        configFile = "./config/egt.properties";
    }

    private static Logger logger_;

    static
    {
        logger_ = Logger.getLogger(com.ericsson.mps.egt.EgtConfig.class);
    }

    /** Holds singleton instance */
    private static EgtConfig instance;
    String archivedir;
    long sleeptime; //Between 5 and 240
    String sourcedir;
    int retention; //	Between 1 and 35

/**
   * prevents instantiation
   */
    private EgtConfig()
    {
        // prevent creation
    }

    /**
     * Creates a new EgtConfig object.
     *
     * @param file DOCUMENT ME!
     *
     * @throws ConfigurationException DOCUMENT ME!
     */
    private EgtConfig(String file) throws ConfigurationException
    {
        super(file);
    }

    /**
     * Returns the "singleton" instance.
     *
     * @param configFile1 the configuration file full path
     *
     * @return EgtConfig the singleton instance
     *
     * @throws EgtException
     */
    static public EgtConfig getInstance(String configFile1)
    throws EgtException
    {
        if (instance == null)
        {
            try
            {
                if (DEBUG)
                {
                    logger_.info("Loaded : ");
                }

                instance = new EgtConfig(configFile1);

                if (DEBUG)
                {
                    logger_.info("Loaded : " + ((PropertiesConfiguration) instance).toString());
                }
            }
            catch (ConfigurationException e)
            {
                if (DEBUG)
                {
                    System.err.println("Error reading configuration file: " + configFile1);
                }

                throw new EgtException("Error reading configuration file: " + configFile1);
            }
        }

        return instance;
    }

    /**
     * DOCUMENT ME!
     *
     * @param args DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public static void main(String[] args) throws EgtException
    {
        //Thread t = new Thread(Configuration.getInstance());
        //t.start();
        try
        {
            instance = EgtConfig.getInstance(configFile);
        }
        catch (Exception ex)
        {
            if (DEBUG)
            {
                System.err.println("error " + ex.toString());
            }
        }

        try
        {
            instance.setConfiguration();
        }
        catch (EgtException ex)
        {
            throw new EgtException(ex.toString());
        }

        if (DEBUG)
        {
            System.out.println("instance.archivedir " + instance.archivedir);
        }

        if (DEBUG)
        {
            System.out.println("instance.retention " + instance.retention);
        }

        if (DEBUG)
        {
            System.out.println("instance.sourcedir " + instance.sourcedir);
        }

        if (DEBUG)
        {
            System.out.println("instance.sleeptime " + instance.sleeptime);
        }
    }

    /* setConfiguration
     *
     */
    /**
     * DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public void setConfiguration() throws EgtException
    {
        try
        {
            this.archivedir = this.getString("archivedir");
            validDirectory(this.archivedir);
        }
        catch (Exception ex)
        {
            throw new EgtException("archivedir parameter error :" + ex.toString());
        }

        try
        {
            this.sleeptime = this.getLong("sleeptime");
            validLong(this.sleeptime, 5, 240);
        }
        catch (Exception ex)
        {
            throw new EgtException("sleeptime parameter error :" + ex.toString());
        }

        try
        {
            this.sourcedir = this.getString("sourcedir");
            validDirectory(this.sourcedir);
        }
        catch (Exception ex)
        {
            throw new EgtException("sourcedir parameter error :" + ex.toString());
        }

        try
        {
            this.retention = this.getInt("retention");
            validInteger(this.retention, 1, 35);
        }
        catch (EgtException ex3)
        {
            throw new EgtException("retention parameter error");
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param i DOCUMENT ME!
     * @param min DOCUMENT ME!
     * @param max DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public void validInteger(int i, int min, int max) throws EgtException
    {
        if ((i < min) || (max < i))
        {
            throw new EgtException("invalid int");
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param i DOCUMENT ME!
     * @param min DOCUMENT ME!
     * @param max DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public void validLong(long i, long min, long max) throws EgtException
    {
        if ((i < min) || (max < i))
        {
            throw new EgtException("invalid long");
        }
    }

    /**
     * DOCUMENT ME!
     *
     * @param directoryname DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public void validDirectory(String directoryname) throws EgtException
    {
        File filedir = new File(directoryname);

        if (!filedir.isDirectory())
        {
            throw new EgtException("not a directory");
        }
    }

    /* Runner
     * @see java.lang.Runnable#run()
     */
    /**
     * DOCUMENT ME!
     */
    public void run()
    {
        while (goOn)
        {
            try
            {
                instance = new EgtConfig(configFile);

                if (DEBUG)
                {
                    System.out.println("Loaded : " + ((PropertiesConfiguration) instance).toString());
                }
            }
            catch (ConfigurationException e)
            {
                if (DEBUG)
                {
                    System.err.println("Error reading configuration file: " + configFile);
                }
            }
            catch (Exception e)
            {
                if (DEBUG)
                {
                    System.err.println("Error reading configuration file: " + configFile);
                }
            }

            try
            {
                Thread.sleep(instance.getLong("reload.config.after"));
            }
            catch (InterruptedException e)
            {
                if (DEBUG)
                {
                    System.err.println("Error reading configuration file: " + configFile);
                }

                if (DEBUG)
                {
                    System.err.println(": " + e.getLocalizedMessage());
                }
            }
        }
    }
}
