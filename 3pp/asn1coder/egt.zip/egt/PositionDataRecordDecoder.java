package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;
import com.ericsson.mps.egt.exceptions.EndOfStreamException;

import java.io.*;

import java.util.*;



/**
 * ASN1 MPS9 (<>MPS7) 
 * PositionDataRecord ::= CHOICE
 * {
 * fileHeader             			[1] IMPLICIT FileHeader,
 * positionResult         			[2] IMPLICIT PositionResult,
 * triggeredLocationReporting 		[3] IMPLICIT TriggeredLocationReporting,
 * emergencyPushLocationReporting 	[4] IMPLICIT EmergencyPushLocationReporting
 * }
 */

/**
 * <p>
 * Titre : EGT
 * </p>
 * <p>
 * Description : enrichisement des log GMPC
 * </p>
 * <p>
 * Copyright : Copyright (c) 2008
 * </p>
 * <p>
 * Soci�t� : Ericsson
 * </p>
 * 
 * @author esforcs
 * @version R3-CP00
 */
public class PositionDataRecordDecoder extends BERTagDecoder
{
    public static final boolean DEBUG = true;
    public static final int FILEHEADER = 1;
    public static final int POSITIONRESULT = 2;
    public static final int TRIGGEREDLOCATIONREPORTING = 3;
    public static final int EMERGENCYPUSHLOCATIONREPORTING = 4;
    public static final int WIRELINELOCATION = 5;
    private CDR cdr;
    private LinkedList cdr_list;

/**
         * 
         */
    public PositionDataRecordDecoder()
    {
        this.cdr = null;
        this.cdr_list = new LinkedList();
    }

    /**
     * 
    DOCUMENT ME!
     *
     * @param dec DOCUMENT ME!
     * @param tag DOCUMENT ME!
     * @param io DOCUMENT ME!
     * @param ia DOCUMENT ME!
     * @param implicit DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws IOException DOCUMENT ME!
     */
    public BERElement getElement(BERTagDecoder dec, int tag, InputStream io, int[] ia, boolean[] implicit)
    throws IOException
    {
        if (DEBUG)
        {
            System.err.println("PositionDataRecord = " + tag);
        }

        // FILEHEADER
        if (tag == (FILEHEADER | 0x80 | 0x20))
        {
            if (DEBUG)
            {
                System.err.println("PositionDataRecord FILEHEADER ==begin");
            }

            FileHeaderDecoder FileHeader = new FileHeaderDecoder(this.cdr);
            BERSequence brs = new BERSequence(FileHeader, io, ia);

            if (DEBUG)
            {
                System.err.println("PositionDataRecord FILEHEADER ==end");
            }

            return brs;
        }

        // POSITIONRESULT
        if (tag == (POSITIONRESULT | 0x80 | 0x20))
        {
            if (DEBUG)
            {
                System.err.println("PositionDataRecord POSITIONRESULT ==begin");
            }

            PositionResultDecoder PositionResult = new PositionResultDecoder(this.cdr);
            BERSequence brs = new BERSequence(PositionResult, io, ia);

            if (DEBUG)
            {
                System.err.println("PositionDataRecord POSITIONRESULT ==end");
            }

            return brs;
        }

        // TRIGGEREDLOCATIONREPORTING
        if (tag == (TRIGGEREDLOCATIONREPORTING | 0x80 | 0x20))
        {
            if (DEBUG)
            {
                System.err.println("PositionDataRecord TRIGGEREDLOCATIONREPORTING ==begin");
            }

            TriggeredLocationReportingDecoder triggeredLocationReporting_dec = new TriggeredLocationReportingDecoder(this.cdr);
            BERSequence brs = new BERSequence(triggeredLocationReporting_dec, io, ia);

            if (DEBUG)
            {
                System.err.println("PositionDataRecord TRIGGEREDLOCATIONREPORTING ==end");
            }

            return brs;
        }

        // EMERGENCYPUSHLOCATIONREPORTING
        if (tag == (EMERGENCYPUSHLOCATIONREPORTING | 0x80 | 0x20))
        {
            if (DEBUG)
            {
                System.err.println("PositionDataRecord EMERGENCYPUSHLOCATIONREPORTING ==begin");
            }

            EmergencyPushLocationReporting em = new EmergencyPushLocationReporting();
            EmergencyPushLocationReportingDecoder emergencyPushLocationReporting_Decoder = new EmergencyPushLocationReportingDecoder(em);
            BERChoice brs = new BERChoice(emergencyPushLocationReporting_Decoder, io, ia);
            em = null;

            // this.cdr.emergencyPushLocationReporting =
            // emergencyPushLocationReporting_Decoder.getEmergencyPushLocationReporting();
            if (DEBUG)
            {
                System.err.println("PositionDataRecord EMERGENCYPUSHLOCATIONREPORTING ==end");
            }

            return brs;
        }

        // WIRELINELOCATION
        if (tag == (WIRELINELOCATION | 0x80 | 0x20))
        {
            if (DEBUG)
            {
                System.err.println("PositionDataRecord WIRELINELOCATION ==begin");
            }

            WireLineLocation wireLineLoc = new WireLineLocation();
            WireLineLocationDecoder decoder = new WireLineLocationDecoder(wireLineLoc);
            BERChoice brs = new BERChoice(decoder, io, ia);

            // this.cdr.emergencyPushLocationReporting =
            // emergencyPushLocationReporting_Decoder.getEmergencyPushLocationReporting();
            if (DEBUG)
            {
                System.err.println("PositionDataRecord WIRELINELOCATION ==end");
            }

            return brs;
        }

        // else
        BEROctetString bst = new BEROctetString(dec, io, ia);
        this.cdr.setUnknownTag(bst, tag);

        return bst;
    }

    /**
     * DOCUMENT ME!
     *
     * @param cdr_bytes
     *
     * @return
     */
    public LinkedList OLDdecode(ByteArrayInputStream cdr_bytes)
    {
        do
        {
            int[] len = new int[1];

            try
            {
                this.cdr = new CDR();
                BERElement.getElement(this, cdr_bytes, len);
                this.cdr_list.addLast(this.cdr);
            }
            catch (Exception exception)
            {
                return this.cdr_list;
            }
        }
        while (true);
    }

    /**
     * DOCUMENT ME!
     *
     * @param cdr_file
     *
     * @return
     */
    public LinkedList decode(FileInputStream cdr_file)
    {
        if (DEBUG)
        {
            System.err.println("Positiondata decode=debut ");
        }

        do
        {
            if (DEBUG)
            {
                System.err.println("Positiondata decode= " + this.cdr_list.size());
            }

            int[] len = new int[1];

            try
            {
                this.cdr = new CDR();
                BERElement.getElement(this, cdr_file, len);
                this.cdr_list.addLast(this.cdr);
            }
            catch (Exception exception)
            {
                if (!(exception instanceof EndOfStreamException))
                {
                    if (DEBUG)
                    {
                        exception.printStackTrace();
                        System.err.println("Positiondata decode=fin");
                    }

                    CDRDir2log.getLoggerLog()
                              .fatal(exception.getClass().getCanonicalName() + ", " + exception.getMessage());
                }

                return this.cdr_list;
            }
        }
        while (true);
    }
}
