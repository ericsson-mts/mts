package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (Not in MPS7)
 * EmergencyPushResult ::= SEQUENCE 
 *{ 
 * clientNo          [1]  IMPLICIT IA5String, 
 * mSISDN            [2]  IMPLICIT IA5String OPTIONAL, 
 * iMEI              [3]  IMPLICIT IA5String OPTIONAL, 
 * iMSI              [4]  IMPLICIT IA5String OPTIONAL, 
 * positionResult    [5]  EXPLICIT EmergencyPositionResult OPTIONAL, 
 * pushResultCode    [6]  EXPLICIT EmergencyPushResultCode,
 * network           [7] IMPLICIT Network OPTIONAL,
 * usedlocationmethod[8] IMPLICIT UsedLocationMethod OPTIONAL
 *} 
*/

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyPushResultDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int CLIENTNO = 1;
  public static final int MSISDN = 2;
  public static final int IMEI = 3;
  public static final int IMSI = 4;
  public static final int POSITIONRESULT = 5;
  public static final int PUSHRESULTCODE = 6;
  public static final int NETWORK = 7;
  public static final int USEDLOCATIONMETHOD = 8;

  private EmergencyPushResult emergencyPushResult;

  public EmergencyPushResultDecoder(EmergencyPushResult emergencyPR) {
	  this.emergencyPushResult = emergencyPR;
  }
  
  public EmergencyPushResult getEmergencyPushResult() {
  	return this.emergencyPushResult;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("emergencyPushResult ========================== " + tag);
    }

    // CLIENTNO
    if (tag == (CLIENTNO | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyPushResult.clientNo = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyPushResult clientNo ========================== " + this.emergencyPushResult.clientNo);
        }
        return b;
    }
    
    // MSISDN
    if (tag == (MSISDN | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyPushResult.mSISDN = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyPushResult mSISDN ========================== " + this.emergencyPushResult.mSISDN);
        }
        return b;
    }
    
    // IMEI
    if (tag == (IMEI | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyPushResult.iMEI = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyPushResult iMEI ========================== " + this.emergencyPushResult.iMEI);
        }
        return b;
    }
    
    // IMSI
    if (tag == (IMSI | 0x80)) {
       	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.emergencyPushResult.iMSI = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "emergencyPushResult iMSI ========================== " + this.emergencyPushResult.iMSI);
        }
        return b;
    }
    
	 //	POSITIONRESULT
	 if (tag == (POSITIONRESULT | 0x80 | 0x20 )) {
		 EmergencyPositionResultDecoder EmergencyPositionResult_decoder = new EmergencyPositionResultDecoder(this.emergencyPushResult.positionResult);
	      BERChoice b = new BERChoice(EmergencyPositionResult_decoder, io, ia);
	      this.emergencyPushResult.positionResult = EmergencyPositionResult_decoder.getEmergencyPositionResult();
	      if (DEBUG) {
	          System.err.println("emergencyPushResult positionResult ==========================");
	      }
	      return b;
	 }
    
	 //	PUSHRESULTCODE
	 if (tag == (PUSHRESULTCODE | 0x80 | 0x20 )) {
		 EmergencyPushResultCodeDecoder EmergencyPushResultCode_Decoder = new EmergencyPushResultCodeDecoder(this.emergencyPushResult.pushResultCode);
	      BERChoice b = new BERChoice(EmergencyPushResultCode_Decoder, io, ia);
	      this.emergencyPushResult.pushResultCode = EmergencyPushResultCode_Decoder.getEmergencyPushResultCode();
	      if (DEBUG) {
	          System.err.println("emergencyPushResult pushResultCode ==========================");
	      }
	      return b;
	 }   
    
    // NETWORK
    if (tag == (NETWORK | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
        this.emergencyPushResult.network =b.getValue();
    	if (DEBUG) {
    		System.err.println( "emergencyPushResult network ========================== " + this.emergencyPushResult.network);
        }
        return b;
    }
    
    // USEDLOCATIONMETHOD
    if (tag == (USEDLOCATIONMETHOD | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
        this.emergencyPushResult.usedlocationmethod =b.getValue();
    	if (DEBUG) {
    		System.err.println( "emergencyPushResult usedlocationmethod ========================== " + this.emergencyPushResult.usedlocationmethod);
        }
        return b;
    }
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.emergencyPushResult.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("emergencyPushResult setUnknownTag ========================== " + this.emergencyPushResult.getUnknownTags());
    }
    return b;
  }





}