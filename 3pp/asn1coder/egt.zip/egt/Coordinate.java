package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.BEROctetString;


/**
 * ASN1 MPS9 (not in MPS7) Coordinate ::= SEQUENCE  {  latitude               [1] IMPLICIT IA5String,  longitude
 * [2] IMPLICIT IA5String  }
 */
/**
 * <p>Titre : EGT</p>
 *  <p>Description : enrichisement des log GMPC</p>
 *  <p>Copyright : Copyright (c) 2008</p>
 *  <p>Soci�t� : Ericsson</p>
 *
 * @author metchbl
 * @version R3-CP00
 */
public class Coordinate
{
    public static final String NOT_SET = "<Not_Set>";
    private String unknown_tags;
    public String latitude;
    public String longitude;

    /**
     * Creates a new Coordinate object.
     */
    public Coordinate()
    {
        this.latitude = NOT_SET;
        this.longitude = NOT_SET;
    }

    /**
     * DOCUMENT ME!
     *
     * @param b DOCUMENT ME!
     * @param tag DOCUMENT ME!
     */
    public void setUnknownTag(BEROctetString b, int tag)
    {
        this.unknown_tags = this.unknown_tags + " Unknown tag: " + tag + " Value: " + b.toString() + "\n";
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getUnknownTags()
    {
        return this.unknown_tags;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public String toString2() throws EgtException
    {
        if (this.getUnknownTags() != null)
        {
            throw new EgtException(" CDR format error : " + this.getUnknownTags());
        }

        String txt = "";
        txt = "\t\t\t\t{\r\n" + "\t\t\t\tlatitude " + this.latitude + "\r\n" + "\t\t\t\tlongitude " + this.longitude
              + "\r\n" + "\t\t\t\t}\r\n";

        return txt;
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public String toLog() throws EgtException
    {
        if (this.getUnknownTags() != null)
        {
            throw new EgtException(" CDR format error : " + this.getUnknownTags());
        }

        String txt = "";
        txt = this.latitude + " " + this.longitude + " ";

        return txt;
    }

    /**
     * DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public void check() throws EgtException
    {
        if (this.getUnknownTags() != null)
        {
            throw new EgtException(" CDR format error : " + this.getUnknownTags());
        }
    }
}
