package com.ericsson.mps.egt;

import java.io.IOException;
import java.io.InputStream;

import com.ericsson.mps.egt.cdrdecoder.BERElement;
import com.ericsson.mps.egt.cdrdecoder.BEROctetString;
import com.ericsson.mps.egt.cdrdecoder.BERSequence;
import com.ericsson.mps.egt.cdrdecoder.BERTagDecoder;

/**
 * ASN1 MPS9 (= MPS7)
 * TriggeredLocationReporting ::= SEQUENCE
 * {
 * initiation              [1] IMPLICIT Initiation OPTIONAL,
 * report                  [2] IMPLICIT Report OPTIONAL,
 * termination             [3] IMPLICIT Termination OPTIONAL
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R3-CP00
 */

public class TriggeredLocationReportingDecoder extends BERTagDecoder {
	
	private static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
	private static final int INITIATION = 1;
	private static final int REPORT = 2;
	private static final int TERMINATION = 3;
	private static final int REPORTALLPHONESWITHINAREA = 4;

	private CDR cdr;

	public TriggeredLocationReportingDecoder(CDR Cdr) {
		this.cdr = Cdr;
	}

	public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
			int ia[], boolean implicit[]) throws IOException {
		if (DEBUG) {
			System.err.println("TriggeredLocationReporting getElement ===================== " + tag);
		}

		// INITIATION
		if (tag == (INITIATION | 0x80 | 0x20)) {
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting Initiation ==begin");
			}
			InitiationDecoder initiation_dec = new InitiationDecoder(this.cdr);
			BERSequence brs = new BERSequence(initiation_dec, io, ia);
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting Initiation ==end");
			}
			return brs;
		}
		
		// REPORT
		if (tag == (REPORT | 0x80 | 0x20)) {
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting Report ==begin");
			}
			ReportDecoder report_dec = new ReportDecoder(this.cdr);
			BERSequence brs = new BERSequence(report_dec, io, ia);
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting Report ==end");
			}
			return brs;
		}
		
		// TERMINATION
		if (tag == (TERMINATION | 0x80 | 0x20)) {
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting Termination ==begin");
			}
			TerminationDecoder termination_dec = new TerminationDecoder(this.cdr);
			BERSequence brs = new BERSequence(termination_dec, io, ia);
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting Termination ==end");
			}
			return brs;
		}
		// REPORTALLPHONESWITHINAREA
		if (tag == (REPORTALLPHONESWITHINAREA | 0x80 | 0x20)) {
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting ReportAllPhonesWithinArea ==begin");
			}
			AllPhonesWithinAreaDecoder allPhones_dec = new AllPhonesWithinAreaDecoder(this.cdr);
			BERSequence brs = new BERSequence(allPhones_dec, io, ia);
			if (DEBUG) {
				System.err.println("TriggeredLocationReporting ReportAllPhonesWithinArea ==end");
			}
			return brs;
		}
		
		BEROctetString b = new BEROctetString(dec, io, ia);
		this.cdr.setUnknownTag(b, tag);
		return b;
	}

}
