package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (<> MPS7)
 * SinglePosition ::= SEQUENCE
 * {
 * targetMS               [1]  IMPLICIT IA5String OPTIONAL,
 * numberMSC              [2]  IMPLICIT IA5String OPTIONAL,
 * numberSGSN             [3]  IMPLICIT IA5String OPTIONAL,
 * positionTime           [4]  IMPLICIT IA5String OPTIONAL,
 * levelOfConfidence      [5]  IMPLICIT INTEGER OPTIONAL,
 * obtainedAccuracy       [6]  IMPLICIT INTEGER OPTIONAL,
 * errorCode              [7]  IMPLICIT INTEGER,
 * dialledByMS            [8]  IMPLICIT IA5String OPTIONAL,
 * numberVLR              [9]  IMPLICIT IA5String OPTIONAL,
 * requestBearer          [10] IMPLICIT RequestBearer OPTIONAL,
 * setID                  [11] EXPLICIT SETId OPTIONAL,
 * coordinate             [12] IMPLICIT Coordinate OPTIONAL
 * network                [13] IMPLICIT Network OPTIONAL,
 * usedlocationmethod     [14] IMPLICIT UsedLocationMethod OPTIONAL
 *}
 */

/**
 * <p>
 * Titre : EGT
 * </p>
 * <p>
 * Description : enrichisement des log GMPC
 * </p>
 * <p>
 * Copyright : Copyright (c) 2008
 * </p>
 * <p>
 * Soci�t� : Ericsson
 * </p>
 * 
 * @author esforcs
 * @version R3-CP00
 */

public class SinglePositionDecoder extends BERTagDecoder
{
	public static final boolean	DEBUG	           = PositionDataRecordDecoder.DEBUG;

	// MPS7 Compatible
	// public static final int TARGETMS = 1;
	// public static final int NUMBERMSC = 2;
	// public static final int NUMBERSGSN = 30; // Not in MPS7
	// public static final int POSITIONTIME = 3; // 3 in MPS7, 4 in MPS9
	// public static final int LEVELOFCONFIDENCE = 5;
	// public static final int OBTAINEDACCURACY = 60; // Not in MPS7
	// public static final int ERRORCODE = 6; // 6 in MPS7, 7 in MPS9
	// public static final int DIALLEDBYMS = 8; // 7 in MPS7, 8 in MPS9
	// public static final int NUMBERVLR = 9; // 8 in MPS7, 9 in MPS9
	// public static final int REQUESTBEARER = 10;
	// public static final int SETID = 11;
	// public static final int COORDINATE = 12;
	// public static final int NETWORK = 13;
	// public static final int USEDLOCATIONMETHOD = 14;

	// MPS9 compatible
	public static final int	    TARGETMS	       = 1;
	public static final int	    NUMBERMSC	       = 2;
	public static final int	    NUMBERSGSN	       = 3;	                          // Not
	// in
	// MPS7
	public static final int	    POSITIONTIME	   = 4;	                          // 3 in
	// MPS7,
	// 4 in
	// MPS9
	public static final int	    LEVELOFCONFIDENCE	= 5;
	public static final int	    OBTAINEDACCURACY	= 6;	                          // Not
	// in
	// MPS7
	public static final int	    ERRORCODE	       = 7;	                          // 6 in
	// MPS7,
	// 7 in
	// MPS9
	public static final int	    DIALLEDBYMS	       = 8;	                          // 7 in
	// MPS7,
	// 8 in
	// MPS9
	public static final int	    NUMBERVLR	       = 9;	                          // 8 in
	// MPS7,
	// 9 in
	// MPS9
	public static final int	    REQUESTBEARER	   = 10;
	public static final int	    SETID	           = 11;
	public static final int	    COORDINATE	       = 12;
	public static final int	    NETWORK	           = 13;
	public static final int	    USEDLOCATIONMETHOD	= 14;
	public static final int	    TRANSID	           = 15;
	public static final int	    ROAMINGGMLCURL	   = 16;
	public static final int	    ROAMINGREQUESTID	= 17;
	public static final int	    ROAMINGERRORCODE	= 18;

	private CDR	                cdr;
	private SinglePosition	    singleposition;

	public SinglePositionDecoder(CDR Cdr)
	{
		this.cdr = Cdr;
	}

	public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
	        int ia[], boolean implicit[]) throws IOException
	{

		// Create new SinglePosition() if is new SinglePosition sequence
		if (BERFlagNewObjet.getInstance().isNewobject() == true)
		{
			this.singleposition = new SinglePosition();
			this.cdr.singlePositionsList.add(this.singleposition);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder  ========================== ["
				                + this.cdr.singlePositionsList.size() + "]");
			}
		} else
		{ // in case of the flag isNewobject is not correctly set
			if (this.cdr.singlePositionsList.isEmpty())
			{
				this.singleposition = new SinglePosition();
				this.cdr.singlePositionsList.add(this.singleposition);
			}
		}

		if (DEBUG)
		{
			System.err
			        .println("SinglePositionDecoder tag ========================== "
			                + tag);
		}

		// TARGETMS
		if (tag == (TARGETMS | 0x80))
		{

			BEROctetString b = new BEROctetString(dec, io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.targetMS = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder targetMS =========================="
				                + this.singleposition.targetMS);
			}
			return b;
		}

		// NUMBERMSC
		if (tag == (NUMBERMSC | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.numberMSC = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder numberMSC =========================="
				                + this.singleposition.numberMSC);
			}
			return b;
		}

		// NUMBERSGSN
		if (tag == (NUMBERSGSN | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.numberSGSN = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder numberSGSN =========================="
				                + this.singleposition.numberSGSN);
			}
			return b;
		}

		// POSITIONTIME
		if (tag == (POSITIONTIME | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.positionTime = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder positionTime =========================="
				                + this.singleposition.positionTime);
			}
			return b;
		}

		// LEVELOFCONFIDENCE
		if (tag == (LEVELOFCONFIDENCE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.levelOfConfidence = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder levelOfConfidence =========================="
				                + this.singleposition.levelOfConfidence);
			}
			return b;
		}

		// OBTAINEDACCURACY
		if (tag == (OBTAINEDACCURACY | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.obtainedAccuracy = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder obtainedAccuracy =========================="
				                + this.singleposition.obtainedAccuracy);
			}
			return b;
		}

		// ERRORCODE
		if (tag == (ERRORCODE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.errorCode = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder errorCode =========================="
				                + this.singleposition.errorCode);
			}
			return b;
		}

		// DIALLEDBYMS
		if (tag == (DIALLEDBYMS | 0x80))
		{
			BEROctetString b = new BEROctetString(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.dialledByMs = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder dialledByMs =========================="
				                + this.singleposition.dialledByMs);
			}
			return b;
		}

		// NUMBERVLR
		if (tag == (NUMBERVLR | 0x80))
		{
			BEROctetString b = new BEROctetString(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.numberVLR = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder numberVLR =========================="
				                + this.singleposition.numberVLR);
			}
			return b;
		}

		// REQUESTBEARER
		if (tag == (REQUESTBEARER | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.requestBearer = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder requestBearer =========================="
				                + this.singleposition.requestBearer);
			}
			return b;
		}

		// COORDINATE
		if (tag == (COORDINATE | 0x80 | 0x20))
		{
			CoordinateDecoder Coordinate_decoder = new CoordinateDecoder(
			        this.singleposition.coordinate);
			BERSequence b = new BERSequence(Coordinate_decoder, io, ia);
			this.singleposition.coordinate = Coordinate_decoder.getCoordinate();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder COORDINATE ==========================");
			}
			return b;
		}

		// SETID
		if (tag == (SETID | 0x80 | 0x20))
		{
			SetIdDecoder SetId_decoder = new SetIdDecoder(this.cdr);
			BERChoice b = new BERChoice(SetId_decoder, io, ia);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder SETID ==========================");
			}
			return b;
		}

		// NETWORK
		if (tag == (NETWORK | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.network = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder network =========================="
				                + this.singleposition.network);
			}
			return b;
		}

		// USEDLOCATIONMETHOD
		if (tag == (USEDLOCATIONMETHOD | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.usedlocationmethod = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder usedlocationmethod =========================="
				                + this.singleposition.usedlocationmethod);
			}
			return b;
		}
		// TRANSID
		if (tag == (TRANSID | 0x80))
		{
			BEROctetString b = new BEROctetString(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.transid = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder transid =========================="
				                + this.singleposition.transid);
			}
			return b;
		}
		// ROAMINGGMLCURL
		if (tag == (ROAMINGGMLCURL | 0x80))
		{
			BEROctetString b = new BEROctetString(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.roamingGMLCURL = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder roamingGMLCURL =========================="
				                + this.singleposition.roamingGMLCURL);
			}
			return b;
		}
		// ROAMINGREQUESTID
		if (tag == (ROAMINGREQUESTID | 0x80))
		{
			BEROctetString b = new BEROctetString(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.roamingRequestId = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder roamingRequestId =========================="
				                + this.singleposition.roamingRequestId);
			}
			return b;
		}
		// ROAMINGERRORCODE
		if (tag == (ROAMINGERRORCODE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.singleposition = (SinglePosition) this.cdr.singlePositionsList
			        .get(this.cdr.singlePositionsList.size() - 1);
			this.singleposition.roamingErrorCode = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("SinglePositionDecoder roamingErrorCode =========================="
				                + this.singleposition.roamingErrorCode);
			}
			return b;
		}

		// else UnknownTags

		BEROctetString b = new BEROctetString(dec, io, ia);
		this.singleposition = (SinglePosition) this.cdr.singlePositionsList
		        .get(this.cdr.singlePositionsList.size() - 1);
		this.singleposition.setUnknownTag(b, tag);
		if (DEBUG)
		{
			System.err
			        .println("SinglePositionDecoder setUnknownTag =========================="
			                + this.singleposition.getUnknownTags());
		}
		return b;
	}

}