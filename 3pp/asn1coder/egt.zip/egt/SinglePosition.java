package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (<> MPS7)
 * SinglePosition ::= SEQUENCE
 * {
 * targetMS               [1]  IMPLICIT IA5String OPTIONAL,
 * numberMSC              [2]  IMPLICIT IA5String OPTIONAL,
 * numberSGSN             [3]  IMPLICIT IA5String OPTIONAL,
 * positionTime           [4]  IMPLICIT IA5String OPTIONAL,
 * levelOfConfidence      [5]  IMPLICIT INTEGER OPTIONAL,
 * obtainedAccuracy       [6]  IMPLICIT INTEGER OPTIONAL,
 * errorCode              [7]  IMPLICIT INTEGER,
 * dialledByMS            [8]  IMPLICIT IA5String OPTIONAL,
 * numberVLR              [9]  IMPLICIT IA5String OPTIONAL,
 * requestBearer          [10] IMPLICIT RequestBearer OPTIONAL,
 * setID                  [11] EXPLICIT SETId OPTIONAL,
 * coordinate             [12] IMPLICIT Coordinate OPTIONAL
 * network                [13] IMPLICIT Network OPTIONAL,
 * usedlocationmethod     [14] IMPLICIT UsedLocationMethod OPTIONAL
 *}
 */

/**
 * <p>
 * Titre : EGT
 * </p>
 * <p>
 * Description : enrichisement des log GMPC
 * </p>
 * <p>
 * Copyright : Copyright (c) 2008
 * </p>
 * <p>
 * Soci�t� : Ericsson
 * </p>
 * 
 * @author esforcs
 * @version R3-CP00
 */

public class SinglePosition
{
	private String	           unknown_tags;

	public static final String	NOT_SET	    = "<Not_Set>";

	private static final int	NOT_SET_INT	= 0x80000000;

	// SinglePosision begin
	public String	           targetMS;
	public String	           numberMSC;
	public String	           numberSGSN;
	public String	           positionTime;
	public int	               levelOfConfidence;
	public int	               obtainedAccuracy;
	public int	               errorCode;
	public String	           dialledByMs;
	public String	           numberVLR;
	public int	               requestBearer;
	public int	               setID;	                   // CHOISE (use to
															// store tag)
	public String	           setIDValue;	               // CHOISE (use to
															// store value
															// relative to tag)
	public Coordinate	       coordinate;
	public int	               network;
	public int	               usedlocationmethod;
	public String	           transid;
	public String	           roamingGMLCURL;
	public String	           roamingRequestId;
	public int	               roamingErrorCode;

	// SinglePosision end

	public SinglePosition()
	{
		// SinglePosision begin
		this.targetMS = NOT_SET;
		this.numberMSC = NOT_SET;
		this.numberSGSN = NOT_SET;
		this.positionTime = NOT_SET;
		this.levelOfConfidence = NOT_SET_INT;
		this.obtainedAccuracy = NOT_SET_INT;
		this.errorCode = NOT_SET_INT;
		this.dialledByMs = NOT_SET;
		this.numberVLR = NOT_SET;
		this.requestBearer = NOT_SET_INT;
		this.setID = NOT_SET_INT;
		this.setIDValue = NOT_SET;
		this.coordinate = new Coordinate();
		this.network = NOT_SET_INT;
		this.usedlocationmethod = NOT_SET_INT;
		this.transid = NOT_SET;
		this.roamingGMLCURL = NOT_SET;
		this.roamingRequestId = NOT_SET;
		this.roamingErrorCode = NOT_SET_INT;
		// SinglePosision end
	}

	public void setUnknownTag(BEROctetString b, int tag)
	{
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag
		        + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags()
	{
		return this.unknown_tags;
	}

	public String toString2() throws EgtException
	{
		if (this.getUnknownTags() != null)
		{
			throw new EgtException(" CDR format error : "
			        + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n" + "\t\t\ttargetMS " + this.targetMS + "\r\n"
		        + "\t\t\tnumberMSC " + this.numberMSC + "\r\n"
		        + "\t\t\tnumberSGSN " + this.numberSGSN + "\r\n"
		        + "\t\t\tpositionTime " + this.positionTime + "\r\n"
		        + "\t\t\tlevelOfConfidence " + printVal(this.levelOfConfidence)
		        + "\r\n" + "\t\t\tobtainedAccuracy "
		        + printVal(this.obtainedAccuracy) + "\r\n" + "\t\t\terrorCode "
		        + printVal(this.errorCode) + "\r\n" + "\t\t\tdialledByMs "
		        + this.dialledByMs + "\r\n" + "\t\t\tnumberVLR "
		        + this.numberVLR + "\r\n" + "\t\t\trequestBearer "
		        + printVal(this.requestBearer) + "\r\n" + "\t\t\tsetID tag "
		        + printVal(this.setID) + "\r\n" + "\t\t\tsetID Value "
		        + this.setIDValue + "\r\n" + "\t\t\tcoordinate\r\n"
		        + this.coordinate.toString2() + "\t\t\tnetwork "
		        + printVal(this.network) + "\r\n" + "\t\t\tusedlocationmethod "
		        + printVal(this.usedlocationmethod) + "\r\n" + "\t\t\ttransid "
		        + this.transid + "\r\n" + "\t\t\troamingGMLCURL "
		        + this.roamingGMLCURL + "\r\n" + "\t\t\troamingRequestId "
		        + this.roamingRequestId + "\r\n" + "\t\t\troamingErrorCode "
		        + this.roamingErrorCode + "\r\n" + "\t\t}\r\n";

		return txt;
	}

	private String printVal(int val)
	{
		if (val == 0x80000000)
		{
			return NOT_SET;
		}
		return Integer.toString(val);
	}

	public String toLog() throws EgtException
	{
		if (this.getUnknownTags() != null)
		{
			throw new EgtException(" CDR format error : "
			        + this.getUnknownTags());
		}
		String txt = "";
		txt = this.targetMS + " " + this.numberMSC + " "
		        + printVal(this.errorCode) + " "
		        + ASN1MappingUtil.mapIntToString(this.network, "network");
		return txt;
	}

	public void check() throws EgtException
	{
		if (this.getUnknownTags() != null)
		{
			throw new EgtException(" CDR format error : "
			        + this.getUnknownTags());
		}
	}

}