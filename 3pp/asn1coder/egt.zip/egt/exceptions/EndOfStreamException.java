package com.ericsson.mps.egt.exceptions;

import java.io.IOException;


/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
 */
public class EndOfStreamException extends IOException
{
/**
     * Creates a new EndOfStreamException object.
     */
    public EndOfStreamException()
    {
        // TODO Auto-generated constructor stub
    }

/**
     * Creates a new EndOfStreamException object.
     *
     * @param message DOCUMENT ME!
     */
    public EndOfStreamException(String message)
    {
        super(message);

        // TODO Auto-generated constructor stub
    }
}
