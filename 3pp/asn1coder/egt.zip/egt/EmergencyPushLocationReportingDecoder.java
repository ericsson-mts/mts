package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (Not in MPS7)
 *
 * EmergencyPushLocationReporting ::= CHOICE 
 * { 
 * callOrigination  [1] IMPLICIT EmergencyCallRelated,
 * callRelease      [2] IMPLICIT EmergencyCallRelated,
 * pushResult       [3] IMPLICIT EmergencyPushResult 
 *} 
*/

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyPushLocationReportingDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int CALLORIGINATION = 1;
  public static final int CALLRELEASE = 2;
  public static final int PUSHRESULT = 3;

  private EmergencyPushLocationReporting emergencyPushLocationReporting;

  public EmergencyPushLocationReportingDecoder(EmergencyPushLocationReporting emergencyPLR) {
	  this.emergencyPushLocationReporting = emergencyPLR;
  }
  
  public EmergencyPushLocationReporting getEmergencyPushLocationReporting() {
  	return this.emergencyPushLocationReporting;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
     if (DEBUG) {
    	 System.err.println("emergencyPushLocationReporting ========================== " + tag);
     }

	 //	CALLORIGINATION
	 if (tag == (CALLORIGINATION | 0x80 | 0x20 )) {
		  EmergencyCallRelatedDecoder EmergencyCallRelated_Decoder = new EmergencyCallRelatedDecoder(this.emergencyPushLocationReporting.callOrigination);
	      BERSequence b = new BERSequence(EmergencyCallRelated_Decoder, io, ia);
	      this.emergencyPushLocationReporting.callOrigination = EmergencyCallRelated_Decoder.getEmergencyCallRelated();
	      if (DEBUG) {
	          System.err.println("emergencyPushLocationReporting callOrigination ==========================");
	      }
	      return b;
	 }
	 
	 //	CALLRELEASE
	 if (tag == (CALLRELEASE | 0x80 | 0x20 )) {
		  EmergencyCallRelatedDecoder EmergencyCallRelated_Decoder = new EmergencyCallRelatedDecoder(this.emergencyPushLocationReporting.callRelease);
	      BERSequence b = new BERSequence(EmergencyCallRelated_Decoder, io, ia);
	      this.emergencyPushLocationReporting.callRelease = EmergencyCallRelated_Decoder.getEmergencyCallRelated();
	      if (DEBUG) {
	          System.err.println("emergencyPushLocationReporting callRelease ==========================");
	      }
	      return b;
	 }
	 
	 //	PUSHRESULT
	 if (tag == (PUSHRESULT | 0x80 | 0x20 )) {
		  EmergencyPushResultDecoder EmergencyPushResult_Decoder = new EmergencyPushResultDecoder(this.emergencyPushLocationReporting.pushResult);
	      BERSequence b = new BERSequence(EmergencyPushResult_Decoder, io, ia);
	      this.emergencyPushLocationReporting.pushResult = EmergencyPushResult_Decoder.getEmergencyPushResult();
	      if (DEBUG) {
	          System.err.println("emergencyPushLocationReporting pushResult ==========================");
	      }
	      return b;
	 } 
    
     // else UnknownTag
	 BEROctetString b = new BEROctetString(dec, io, ia);
	 this.emergencyPushLocationReporting.setUnknownTag(b, tag);
     if (DEBUG) {
        System.err.println("emergencyPushLocationReporting setUnknownTag ========================== " + this.emergencyPushLocationReporting.getUnknownTags());
     }
     return b;
  }





}