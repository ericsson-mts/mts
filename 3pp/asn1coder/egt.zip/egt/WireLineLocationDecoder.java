package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

	/**
	 * ASN1 MPS10 
	 * WirelineLocation ::= CHOICE
	 * {
	 * routingDeterminationResponse 		[1] IMPLICIT RoutingDeterminationResponse,
	 * wirelineEmergencyLocationRetrieving 	[2] IMPLICIT WirelineEmergencyLocationRetrieving,
	 * wirelineEmergencyPush 				[3] IMPLICIT WirelineEmergencyPush
	 * }
	 */

	/**
	 * <p>Titre : EGT</p>
	 * <p>Description : enrichisement des log GMPC</p>
	 * <p>Copyright : Copyright (c) 2008</p>
	 * <p>Soci�t� : Ericsson</p>
	 * @author esforcs
	 * @version R3-CP00
	 */

	public class WireLineLocationDecoder extends BERTagDecoder {
	  public static final boolean DEBUG = true;
	  public static final int ROUTINGDETERMINATIONRESPONSE = 1;
	  public static final int WIRELINEEMERGENCYLOCATIONRETRIEVING = 2;
	  public static final int WIRELINEEMERGENCYPUSH = 3;
	  
	  private WireLineLocation wireLineLocation;

	  public WireLineLocationDecoder( WireLineLocation wireLineLocation) {
	    this.wireLineLocation = wireLineLocation;
	  }

	  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
	                               int ia[], boolean implicit[]) throws IOException {
	    if (DEBUG) {
	      System.err.println("WireLineLocation = " + tag);
	    }
	    // ROUTINGDETERMINATIONRESPONSE
	    if (tag == (ROUTINGDETERMINATIONRESPONSE | 0x80 | 0x20)) {
	    	if (DEBUG) {
	    		System.err.println("WireLineLocation ROUTINGDETERMINATIONRESPONSE ==begin");
	    	}
	    	RoutingDeterminationResponse routingDeterminationResponse = new RoutingDeterminationResponse();
	    	RoutingDeterminationResponseDecoder decoder = new RoutingDeterminationResponseDecoder( routingDeterminationResponse);
	    	BERSequence brs = new BERSequence(decoder, io, ia);
	    	if (DEBUG) {
	    		System.err.println("WireLineLocation ROUTINGDETERMINATIONRESPONSE ==end");
	    	}
	    	return brs;
	    }
	    
	    // WIRELINEEMERGENCYLOCATIONRETRIEVING
	    if (tag == (WIRELINEEMERGENCYLOCATIONRETRIEVING | 0x80 | 0x20)) {
	    	if (DEBUG) {
	    		System.err.println("WireLineLocation WIRELINEEMERGENCYLOCATIONRETRIEVING ==begin");
	    	}
	    	WirelineEmergencyLocationRetrieving wirelineEmergencyLocationRetrieving = new WirelineEmergencyLocationRetrieving();
	    	WirelineEmergencyLocationRetrievingDecoder decoder = new WirelineEmergencyLocationRetrievingDecoder( wirelineEmergencyLocationRetrieving);
	    	BERSequence brs = new BERSequence(decoder, io, ia);
	    	if (DEBUG) {
	    		System.err.println("WireLineLocation WIRELINEEMERGENCYLOCATIONRETRIEVING ==end");
	    	}
	    	return brs;
	    }
	    
	    // WIRELINEEMERGENCYPUSH
		if (tag == (WIRELINEEMERGENCYPUSH | 0x80 | 0x20)) {
		      if (DEBUG) {
		        System.err.println("WireLineLocation WIRELINEEMERGENCYPUSH ==begin");
		      }
		      WirelineEmergencyPush wirelineEmergencyPush = new WirelineEmergencyPush();
		      WirelineEmergencyPushDecoder decoder = new WirelineEmergencyPushDecoder( wirelineEmergencyPush);
		      BERSequence brs = new BERSequence(decoder, io, ia);
		      if (DEBUG) {
		        System.err.println("WireLineLocation WIRELINEEMERGENCYPUSH ==end");
		      }
		      return brs;
		}
		
		// else
		BEROctetString bst = new BEROctetString(dec, io, ia);
		this.wireLineLocation.setUnknownTag(bst, tag);
		return bst;
	  }
	}
