
package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * RoutingDeterminationResponse ::= SEQUENCE
 * {
 * userInfo 							[1] IMPLICIT IA5String,
 * location 							[2] IMPLICIT IA5String,
 * calling 								[3] IMPLICIT IA5String,
 * emergencyNumber 						[4] IMPLICIT IA5String,
 * routableEmergencyNumber 				[5] IMPLICIT IA5String OPTIONAL,
 * time 								[6] IMPLICIT IA5String,
 * errorCode 							[7] IMPLICIT INTEGER
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class RoutingDeterminationResponse {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";
	private static final int NOT_SET_INT = 0x80000000;

	public String userInfo;
	public String location;
	public String calling;
	public String emergencyNumber;
	public String routableEmergencyNumber;
	public String time;
	public int errorCode;
	


	public RoutingDeterminationResponse() {

		this.userInfo = NOT_SET;
		this.location = NOT_SET;
		this.calling = NOT_SET;
		this.emergencyNumber = NOT_SET;
		this.routableEmergencyNumber = NOT_SET;
		this.time = NOT_SET;
		this.errorCode = NOT_SET_INT;
		

	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n"  
			+ "\t\t\tuserInfo " + this.userInfo + "\r\n"					
			+ "\t\t\tlocation " + this.location + "\r\n"
			+ "\t\t\tcalling " + this.calling + "\r\n"
			+ "\t\t\temergencyNumber " + this.emergencyNumber + "\r\n"					
			+ "\t\t\troutableEmergencyNumber " + this.routableEmergencyNumber + "\r\n"
			+ "\t\t\ttime " + this.time + "\r\n"
			+ "\t\t\terrorCode " + this.errorCode + "\r\n"
			+ "\t\t}\r\n";

		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

}
