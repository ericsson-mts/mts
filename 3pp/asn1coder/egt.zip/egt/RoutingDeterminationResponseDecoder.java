	
package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10
 * * RoutingDeterminationResponse ::= SEQUENCE
 * {
 * userInfo 							[1] IMPLICIT IA5String,
 * location 							[2] IMPLICIT IA5String,
 * calling 								[3] IMPLICIT IA5String,
 * emergencyNumber 						[4] IMPLICIT IA5String,
 * routableEmergencyNumber 				[5] IMPLICIT IA5String OPTIONAL,
 * time 								[6] IMPLICIT IA5String,
 * errorCode 							[7] IMPLICIT INTEGER
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class RoutingDeterminationResponseDecoder extends BERTagDecoder {
	public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;

	public static final int USERINFO = 1;
	public static final int LOCATION = 2;
	public static final int CALLING = 3;
	public static final int EMERGENCYNUMBER = 4;
	public static final int ROUTABLEEMERGENCYNUMBER = 5;
	public static final int TIME = 6;
	public static final int ERRORCODE = 7;

	private RoutingDeterminationResponse routingDeterminationResponse;

	public RoutingDeterminationResponseDecoder(RoutingDeterminationResponse routingDeterminationResponse) {
		this.routingDeterminationResponse = routingDeterminationResponse;
	}

	public RoutingDeterminationResponse getRoutingDeterminationResponse() {
		return this.routingDeterminationResponse;
	}

	public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
			int ia[], boolean implicit[]) throws IOException {
		if (DEBUG) {
			System.err.println("routingDeterminationResponse ======= " + tag);
		}

		// USERINFO
		if (tag == (USERINFO | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.routingDeterminationResponse.userInfo = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println( "routingDeterminationResponse userInfo ======= " + this.routingDeterminationResponse.userInfo);
			}
			return b;
		}

		// LOCATION
		if (tag == (LOCATION | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.routingDeterminationResponse.location = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println( "routingDeterminationResponse location ======= " + this.routingDeterminationResponse.location);
			}
			return b;
		}
		
		// CALLING
		if (tag == (CALLING | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.routingDeterminationResponse.calling = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println( "routingDeterminationResponse calling ======= " + this.routingDeterminationResponse.calling);
			}
			return b;
		}

		// EMERGENCYNUMBER
		if (tag == (EMERGENCYNUMBER | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.routingDeterminationResponse.emergencyNumber = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println( "routingDeterminationResponse emergencyNumber ======= " + this.routingDeterminationResponse.emergencyNumber);
			}
			return b;
		}
		
		// ROUTABLEEMERGENCYNUMBER
		if (tag == (ROUTABLEEMERGENCYNUMBER | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.routingDeterminationResponse.routableEmergencyNumber = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println( "routingDeterminationResponse routableEmergencyNumber ======= " + this.routingDeterminationResponse.routableEmergencyNumber);
			}
			return b;
		}

		// TIME
		if (tag == (TIME | 0x80)) {
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.routingDeterminationResponse.time = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println( "routingDeterminationResponse time ======= " + this.routingDeterminationResponse.time);
			}
			return b;
		}
		
		// ERRORCODE
		if (tag == (ERRORCODE | 0x80)) {
			BERInteger b = new BERInteger(io, ia);
			this.routingDeterminationResponse.errorCode =b.getValue();
			if (DEBUG) {
				System.err.println( "routingDeterminationResponse errorCode ========================== " + this.routingDeterminationResponse.errorCode);
			}
			return b;
		}
		// else UnknownTag
		BEROctetString b = new BEROctetString(dec, io, ia);
		this.routingDeterminationResponse.setUnknownTag(b, tag);
		if (DEBUG) {
			System.err.println("routingDeterminationResponse setUnknownTag ======= " + this.routingDeterminationResponse.getUnknownTags());
		}
		return b;
	}





}
