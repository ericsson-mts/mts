package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (not in MPS7)
 * EllipsoidPointWithUncertaintyEllipse ::= SEQUENCE 
 * { 
 * EmergencyPositionResult ::= CHOICE 
 * { 
 * ellipsoidPoint  						[1]  IMPLICIT EllipsoidPoint, 
 * ellipsoidPointWithUncertaintyEllipse [2]  IMPLICIT EllipsoidPointWithUncertaintyEllipse, 
 * ellipsoidPointWithUncertaintyCircle  [3]  IMPLICIT EllipsoidPointWithUncertaintyCircle, 
 * errorId                              [4]  IMPLICIT INTEGER 
 * } 
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyPositionResultDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int ELLIPSOIDPOINT = 1;
  public static final int ELLIPSOIDPOINTWITHUNCERTAINTYELLIPSE = 2;
  public static final int ELLIPSOIDPOINTWITHUNCERTAINTYCIRCLE = 3;
  public static final int ELLIPSOIDARC = 4;
  public static final int POLYGON = 5;
  public static final int ERRORID = 6;
  
  private EmergencyPositionResult emergencyPositionResult;

  public EmergencyPositionResultDecoder(EmergencyPositionResult emergency) {
	  this.emergencyPositionResult = emergency;
  }
  
  public EmergencyPositionResult getEmergencyPositionResult() {
  	return this.emergencyPositionResult;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("emergencyPositionResult ======= " + tag);
    }

    // ELLIPSOIDPOINT
    if (tag == (ELLIPSOIDPOINT | 0x80 | 0x20 )) {
    	this.emergencyPositionResult.EmergencyPositionResult_tag = 1;
        EllipsoidPointDecoder EllipsoidPoint_Decoder = new EllipsoidPointDecoder(this.emergencyPositionResult.ellipsoidPoint);
	    BERSequence b = new BERSequence(EllipsoidPoint_Decoder, io, ia);
	    this.emergencyPositionResult.ellipsoidPoint= EllipsoidPoint_Decoder.getEllipsoidPoint();
	    if (DEBUG) {
	          System.err.println("emergencyPositionResult ELLIPSOIDPOINT ==========================");
	    }
	    return b;    
    }
    
    // ELLIPSOIDPOINTWITHUNCERTAINTYELLIPSE
    if (tag == (ELLIPSOIDPOINTWITHUNCERTAINTYCIRCLE | 0x80 | 0x20 )) {
    	this.emergencyPositionResult.EmergencyPositionResult_tag = 2;
    	EllipsoidPointWithUncertaintyCircleDecoder EllipsoidPointWithUncertaintyCircle_Decoder = 
    		new EllipsoidPointWithUncertaintyCircleDecoder(this.emergencyPositionResult.ellipsoidPointWithUncertaintyCircle);
	    BERSequence b = new BERSequence(EllipsoidPointWithUncertaintyCircle_Decoder, io, ia);
	    this.emergencyPositionResult.ellipsoidPointWithUncertaintyCircle= EllipsoidPointWithUncertaintyCircle_Decoder.getEllipsoidPointWithUncertaintyCircle();
	    if (DEBUG) {
	          System.err.println("emergencyPositionResult ELLIPSOIDPOINTWITHUNCERTAINTYCIRCLE ==========================");
	    }
	    return b;    
    }
    
    // ELLIPSOIDPOINTWITHUNCERTAINTYELLIPSE
    if (tag == (ELLIPSOIDPOINTWITHUNCERTAINTYELLIPSE | 0x80 | 0x20 )) {
    	this.emergencyPositionResult.EmergencyPositionResult_tag = 3;
    	EllipsoidPointWithUncertaintyEllipseDecoder EllipsoidPointWithUncertaintyEllipse_Decoder = 
    		new EllipsoidPointWithUncertaintyEllipseDecoder(this.emergencyPositionResult.ellipsoidPointWithUncertaintyEllipse);
	    BERSequence b = new BERSequence(EllipsoidPointWithUncertaintyEllipse_Decoder, io, ia);
	    this.emergencyPositionResult.ellipsoidPointWithUncertaintyEllipse= EllipsoidPointWithUncertaintyEllipse_Decoder.getEllipsoidPointWithUncertaintyEllipse();
	    if (DEBUG) {
	          System.err.println("emergencyPositionResult ELLIPSOIDPOINTWITHUNCERTAINTYELLIPSE ==========================");
	    }
	    return b;    
    }
   
    // ELLIPSOIDARC 
    if (tag == (ELLIPSOIDARC | 0x80 | 0x20 )) {
    	this.emergencyPositionResult.EmergencyPositionResult_tag = 4;
        EllipsoidArcDecoder EllipsoidArc_Decoder = new EllipsoidArcDecoder(this.emergencyPositionResult.ellipsoidArc);
	    BERSequence b = new BERSequence(EllipsoidArc_Decoder, io, ia);
	    this.emergencyPositionResult.ellipsoidArc= EllipsoidArc_Decoder.getEllipsoidArc();
	    if (DEBUG) {
	          System.err.println("emergencyPositionResult ELLIPSOIDARC ==========================");
	    }
	    return b;    
    }
    
    // POLYGON
    if (tag == (POLYGON | 0x80 | 0x20 )) {
    	this.emergencyPositionResult.EmergencyPositionResult_tag = 5;
        PolygonDecoder polygon_Decoder = new PolygonDecoder(this.emergencyPositionResult.polygon);
	    BERSequence b = new BERSequence(polygon_Decoder, io, ia);
	    this.emergencyPositionResult.polygon= polygon_Decoder.getPolygon();
	    if (DEBUG) {
	          System.err.println("emergencyPositionResult POLYGON ==========================");
	    }
	    return b;    
    }
    
	 //	ERRORID
	 if (tag == (ERRORID | 0x80 )) { 		
	     this.emergencyPositionResult.EmergencyPositionResult_tag = 6;
		 BERInteger b = new BERInteger(io, ia);
		 this.emergencyPositionResult.errorId = b.getValue();
	     if (DEBUG) {
	          System.err.println("emergencyPositionResult ERRORID =======");
	     }
	     return b;
	 }
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.emergencyPositionResult.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("emergencyPositionResult setUnknownTag ======= " + this.emergencyPositionResult.getUnknownTags());
    }
    return b;
  }





}