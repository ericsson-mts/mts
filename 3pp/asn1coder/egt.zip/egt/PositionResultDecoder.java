package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 *  ASN1 MPS9  (<>MPS7)
 * PositionResult ::= SEQUENCE
 *{
 * trafficCase            [1]  IMPLICIT TrafficCase,  
 * locationType           [2]  IMPLICIT LocationType OPTIONAL,
 * clientId               [3]  IMPLICIT IA5String OPTIONAL,
 * clientNo               [4]  IMPLICIT IA5String OPTIONAL,
 * pushURL                [5]  IMPLICIT IA5String OPTIONAL,
 * pushId                 [6]  IMPLICIT IA5String OPTIONAL,
 * errorCode              [7]  IMPLICIT INTEGER,
 * clientType             [8]  IMPLICIT ClientType OPTIONAL,
 * privacyOverride        [9]  IMPLICIT INTEGER OPTIONAL,
 * geographicalInfo       [10] IMPLICIT GeographicalInfo OPTIONAL,
 * qos                    [11] IMPLICIT QoS OPTIONAL,
 * requestedPositionTime  [12] IMPLICIT IA5String,
 * singlePositions        [13] IMPLICIT SEQUENCE OF SinglePosition,
 * subclientNo            [14] IMPLICIT IA5String OPTIONAL,
 * clientRequestor        [15] IMPLICIT IA5String OPTIONAL,
 * clientServiceType      [16] IMPLICIT INTEGER OPTIONAL
 *}
 */

/**
 * <p>
 * Titre : EGT
 * </p>
 * <p>
 * Description : enrichisement des log GMPC
 * </p>
 * <p>
 * Copyright : Copyright (c) 2008
 * </p>
 * <p>
 * Soci�t� : Ericsson
 * </p>
 * 
 * @author esforcs
 * @version R3-CP00
 */

public class PositionResultDecoder extends BERTagDecoder
{
	public static final boolean	DEBUG	              = PositionDataRecordDecoder.DEBUG;

	// MPS7 Compatible
	// public static final int TRAFFICCASE = 1;
	// public static int LOCATIONTYPE = 2;
	// public static int CLIENTID = 3;
	// public static int CLIENTNO = 4;
	// public static int PUSHURL = 5;
	// public static int PUSHID = 6;
	// public static int ERRORCODE = 7;
	// public static int CLIENTTYPE = 8;
	// public static int PRIVACYOVERRIDE = 9;
	// public static int GEOGRAPHICALINFO = 10;
	// public static int QOS = 11;
	// public static int REQUESTEDPOSITIONTIME = 13; // 13 in MPS7, 12 in MPS9
	// public static int SINGLEPOSITIONS = 14; // 14 in MPS7, 13 in MPS9
	// public static int SUBCLIENTNO = 15; // 15 in MPS7, 14 in MPS9
	// public static int CLIENTREQUESTOR = 16; // 16 in MPS7, 15 in MPS9
	// public static int CLIENTSERVICETYPE = 17; // 17 in MPS7, 16 in MPS9

	// // MPS9 Compatible
	// public static final int TRAFFICCASE = 1;
	// public static int LOCATIONTYPE = 2;
	// public static int CLIENTID = 3;
	// public static int CLIENTNO = 4;
	// public static int PUSHURL = 5;
	// public static int PUSHID = 6;
	// public static int ERRORCODE = 7;
	// public static int CLIENTTYPE = 8;
	// public static int PRIVACYOVERRIDE = 9;
	// public static int GEOGRAPHICALINFO = 10;
	// public static int QOS = 11;
	// public static int REQUESTEDPOSITIONTIME = 12; // 13 in MPS7, 12 in MPS9
	// public static int SINGLEPOSITIONS = 13; // 14 in MPS7, 13 in MPS9
	// public static int SUBCLIENTNO = 14; // 15 in MPS7, 14 in MPS9
	// public static int CLIENTREQUESTOR = 15; // 16 in MPS7, 15 in MPS9
	// public static int CLIENTSERVICETYPE = 16; // 17 in MPS7, 16 in MPS9

	// MPS10 Compatible
	public static final int	    TRAFFICCASE	          = 1;
	public static int	        LOCATIONTYPE	      = 2;
	public static int	        CLIENTID	          = 3;
	public static int	        CLIENTNO	          = 4;
	public static int	        PUSHURL	              = 5;
	public static int	        PUSHID	              = 6;
	public static int	        ERRORCODE	          = 7;
	public static int	        CLIENTTYPE	          = 8;
	public static int	        PRIVACYOVERRIDE	      = 9;
	public static int	        GEOGRAPHICALINFO	  = 10;
	public static int	        QOS	                  = 11;
	public static int	        REQUESTEDPOSITIONTIME	= 12;
	public static int	        SINGLEPOSITIONS	      = 13;
	public static int	        SUBCLIENTNO	          = 14;
	public static int	        CLIENTREQUESTOR	      = 15;
	public static int	        CLIENTSERVICETYPE	  = 16;
	public static int	        REQUESTID	          = 17;
	public static int	        PUSHRESCODE	          = 18;
	public static int	        GSMSCFADDRESS	      = 19;

	private CDR	                cdr;
	public static boolean	    debug	              = false;

	public PositionResultDecoder(CDR Cdr)
	{
		this.cdr = Cdr;
	}

	public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
	        int ia[], boolean implicit[]) throws IOException
	{
		if (DEBUG)
		{
			System.err.println("PositionResult ========================== "
			        + tag);
		}
		if (tag == (TRAFFICCASE | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.cdr.TrafficCase = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("PositionResult TrafficCase =========================="
				                + this.cdr.TrafficCase);
			}
			return b;
		}
		if (tag == (LOCATIONTYPE | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.cdr.LocationType = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("PositionResult LocationType =========================="
				                + this.cdr.LocationType);
			}
			return b;
		}

		if (tag == (CLIENTID | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.ClientId = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult ClientId =========================="
				                + this.cdr.ClientId);
			}
			return b;
		}

		if (tag == (CLIENTNO | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.clientNo = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult clientNo =========================="
				                + this.cdr.clientNo);
			}
			return b;
		}

		if (tag == (PUSHURL | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.pushURL = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult pushURL =========================="
				                + this.cdr.pushURL);
			}
			return b;
		}

		if (tag == (PUSHID | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.pushId = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult pushId =========================="
				                + this.cdr.pushId);
			}
			return b;
		}

		if (tag == (ERRORCODE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.errorCode = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("PositionResult errorCode =========================="
				                + this.cdr.errorCode);
			}
			return b;
		}

		if (tag == (CLIENTTYPE | 0x80))
		{
			BEREnumerated b = new BEREnumerated(io, ia);
			this.cdr.ClientType = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("PositionResult ClientType =========================="
				                + this.cdr.ClientType);
			}
			return b;
		}

		if (tag == (PRIVACYOVERRIDE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.privacyOverride = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("PositionResult privacyOverride =========================="
				                + this.cdr.privacyOverride);
			}
			return b;
		}

		if (tag == (GEOGRAPHICALINFO | 0x80 | 0x20))
		{
			GeographicalInfoDecoder GeographicalInfo_att_decoder = new GeographicalInfoDecoder(
			        this.cdr);
			BERSequence brs = new BERSequence(GeographicalInfo_att_decoder, io,
			        ia);
			if (DEBUG)
			{
				System.err.println("PositionResult GeographicalInfo ==end");
			}
			return brs;
		}

		if (tag == (QOS | 0x80 | 0x20))
		{
			QoSDecoder QoS_att_decoder = new QoSDecoder(this.cdr);
			BERSequence brs = new BERSequence(QoS_att_decoder, io, ia);
			if (DEBUG)
			{
				System.err.println("PositionResult QoS ==end");
			}
			return brs;
		}

		if (tag == (REQUESTEDPOSITIONTIME | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.requestedPositionTime = new String(b.getValue(), 0, b
			        .getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult requestedPositionTime =========================="
				                + this.cdr.requestedPositionTime);
			}
			return b;
		}

		if (tag == (SINGLEPOSITIONS | 0x80 | 0x20))
		{
			SinglePositionDecoder SinglePosition_att_decoder = new SinglePositionDecoder(
			        this.cdr);
			BERSequence brs = new BERSequence(SinglePosition_att_decoder, io,
			        ia);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult SinglePosition ==========================");
			}
			return brs;
		}

		if (tag == (SUBCLIENTNO | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.subClientNO = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult subClientNO =========================="
				                + this.cdr.subClientNO);
			}
			return b;
		}
		if (tag == (CLIENTREQUESTOR | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.clientRequestor = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult clientRequestor =========================="
				                + this.cdr.clientRequestor);

			}
			return b;
		}
		if (tag == (CLIENTSERVICETYPE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.clientServiceType = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("PositionResult clientServiceType =========================="
				                + this.cdr.clientServiceType);
			}
			return b;
		}
		if (tag == (REQUESTID | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.requestId = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult requestId =========================="
				                + this.cdr.requestId);
			}
			return b;
		}
		if (tag == (PUSHRESCODE | 0x80))
		{
			BERInteger b = new BERInteger(io, ia);
			this.cdr.pushResCode = b.getValue();
			if (DEBUG)
			{
				System.err
				        .println("PositionResult pushResCode =========================="
				                + this.cdr.pushResCode);
			}
			return b;
		}
		if (tag == (GSMSCFADDRESS | 0x80))
		{
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.cdr.gsmSCFAddress = new String(b.getValue(), 0,
			        b.getValue().length);
			if (DEBUG)
			{
				System.err
				        .println("PositionResult gsmSCFAddress =========================="
				                + this.cdr.gsmSCFAddress);
			}
			return b;
		}

		BEROctetString b = new BEROctetString(dec, io, ia);
		this.cdr.setUnknownTag(b, tag);
		if (DEBUG)
		{
			System.err
			        .println("PositionResult setUnknownTag ========================== "
			                + this.cdr.getUnknownTags());
		}

		return b;
	}

}