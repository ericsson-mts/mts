package com.ericsson.mps.egt;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

public class EgtException
    extends Exception {
  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

/**
  *  EgtException
  *
  * @param text error text
  *
  *
  */
  public EgtException(String text) {
    super(text);
  }

  /**
  *  EgtException
  *
  *
  */
  public EgtException() {
    super();
  }

}
