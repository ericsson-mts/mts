package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * SingleWirelineEmergencyLocationRetrieving ::= SEQUENCE
 * {
 * errorCode 									[1] IMPLICIT INTEGER,
 * targetTELURI 								[2] IMPLICIT IA5String OPTIONAL,
 * location 									[3] IMPLICIT IA5String OPTIONAL
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class SingleWirelineEmergencyLocationRetrieving {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";
	private static final int NOT_SET_INT = 0x80000000;

	public int errorCode;
	public String targetTELURI;
	public String location;


	public SingleWirelineEmergencyLocationRetrieving() {

		this.errorCode = NOT_SET_INT;
		this.targetTELURI = NOT_SET;
		this.location = NOT_SET;

	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag + " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n"  
			+ "\t\t\terrorcode " + this.errorCode + "\r\n"					
			+ "\t\t\ttargetTELURI " + this.targetTELURI + "\r\n"
			+ "\t\t\tlocation " + this.location + "\r\n"
			+ "\t\t}\r\n";

		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

}
