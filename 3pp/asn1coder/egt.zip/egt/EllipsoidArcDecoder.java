package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * EllipsoidArc ::= SEQUENCE
 * {
 * time 				[1] IMPLICIT IA5String,
 * coordinate 			[2] IMPLICIT Coordinate,
 * innerradius 			[3] IMPLICIT IA5String,
 * uncertaintyradius 	[4] IMPLICIT IA5String,
 * offsetangle 			[5] IMPLICIT IA5String,
 * includedangle 		[6] IMPLICIT IA5String
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EllipsoidArcDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  public static final int TIME = 1;
  public static final int COORDINATE = 2;
  public static final int INERRADIUS = 3;
  public static final int UNCERTAINTYRADIUS = 4;
  public static final int OFFSETANGLE = 5;
  public static final int INCLUDEANGLE = 6;
	
  private EllipsoidArc ellipsoidArc;

  public EllipsoidArcDecoder(EllipsoidArc ellipsoidArc) {
	  this.ellipsoidArc = ellipsoidArc;
  }
  
  public EllipsoidArc getEllipsoidArc() {
  	return this.ellipsoidArc;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("EllipsoidPoint ========================== " + tag);
    }

    // TIME
    if (tag == (TIME | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidArc.time = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidArc time ========================== " + this.ellipsoidArc.time);
        }
        return b;
    }
    
    //COORDINATE
    if (tag == (COORDINATE | 0x80 | 0x20)) { 
		  CoordinateDecoder Coordinate_decoder = new CoordinateDecoder(this.ellipsoidArc.coordinate);
	      BERSequence b = new BERSequence(Coordinate_decoder, io, ia);
	      this.ellipsoidArc.coordinate= Coordinate_decoder.getCoordinate();
	      if (DEBUG) {
	          System.err.println("ellipsoidArc COORDINATE =======");
	      }
	      return b;
	 }
    
    // INERRADIUS
    if (tag == (INERRADIUS | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidArc.innerradius = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidArc innerradius ========================== " + this.ellipsoidArc.innerradius);
        }
        return b;
    }
    
    // UNCERTAINTYRADIUS
    if (tag == (UNCERTAINTYRADIUS | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidArc.uncertaintyradius = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidArc  uncertaintyradius========================== " + this.ellipsoidArc.uncertaintyradius);
        }
        return b;
    }
    
    // OFFSETANGLE
    if (tag == (OFFSETANGLE | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidArc.offsetangle = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidArc  offsetangle========================== " + this.ellipsoidArc.offsetangle);
        }
        return b;
    }
    
    // INCLUDEANGLE
    if (tag == (INCLUDEANGLE | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidArc.includedangle = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "EllipsoidArc  includedangle ========================== " + this.ellipsoidArc.includedangle);
        }
        return b;
    }
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.ellipsoidArc.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("EllipsoidPoint setUnknownTag ========================== " + this.ellipsoidArc.getUnknownTags());
    }
    return b;
  }





}
