package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.*;

import java.util.*;


/**
 * <p>Titre : EGT</p>
 *  <p>Description : enrichisement des log GMPC</p>
 *  <p>Copyright : Copyright (c) 2008</p>
 *  <p>Soci�t� : Ericsson</p>
 *
 * @author esforcs
 * @version R3-CP00
 */
public class CDR
{
    public static final String NOT_SET = "NotSet";
    public static final int NOT_SET_INT = 0x80000000;
    private String unknown_tags;

    // fileHeader begin
    public String sourceName;
    public String fileName;
    public String date;
    public int noOfRecords;

    // fileHeader end

    // PositionResult begin
    public int TrafficCase;
    public int LocationType;
    public String ClientId;
    public String clientNo;
    public String pushURL;
    public String pushId;
    public int errorCode;
    public int ClientType;
    public int privacyOverride;

    // GeographicalInfo begin
    public int coordinateSystem;
    public int datum;

    // GeographicalInfo end

    // QoS begin
    public int requestedAccuracy;
    public int requestedAccuracyMeters;
    public int responseTime;
    public int maxLocationAge;

    // QoS end
    public String requestedPositionTime;

    // SinglePosision begin
    List singlePositionsList;

    // SinglePosision end
    public String subClientNO;
    public String clientRequestor;
    public int clientServiceType;
    public String requestId;
    public int pushResCode;
    public String gsmSCFAddress;

    // PositionResult end
    public List subscriberDataList;

    // initiation
    public String initiationRequestId;
    public int initiationTriggerCriterionType;
    public String initiationClientId;
    public String initiationClientNo;
    public int initiationspeed;
    public String initiationTime;
    public int initiationErrorCode;
    public String initiationStartTime;
    public String initiationStopTime;
    public int initiationRecurrenceInterval;
    public int initiationrequestedAccuracyMeters;
    public int initiationlocationEstimateIncluded;

    // report
    public String reportRequestId;
    public int reportTriggerCriterionType;
    public String reportClientId;
    public String reportClientNo;
    public int reportspeed;
    public String reportTime;
    public int reportErrorCode;
    public String reportStartTime;
    public String reportStopTime;
    public String reportPushURL;
    public String reportPushID;
    public int reportRecurrentReport;
    public int reportrequestedAccuracyMeters;
    public int reportobtainedAccuracy;
    public int reportlocationEstimateIncluded;

    //allPhonesWithinArea
    public String allPhonesWithinAreaRequestId;
    public String allPhonesWithinAreaClientId;
    public String allPhonesWithinAreaClientNo;
    public int amountOfSubscribersReported;
    public String allPhonesWithinAreaReportTime;
    public int allPhonesWithinAreaErrorCode;
    public String pushUrl;
    public String allPhonesWithinAreaPushId;
    public int locationEstimateIncluded;

    // termination
    public String terminationRequestId;
    public int terminationTriggerCriterionType;
    public String terminationClientId;
    public String terminationClientNo;
    public int terminationspeed;
    public String terminationTime;
    public int terminationErrorCode;
    public String terminationStartTime;
    public String terminationStopTime;

    //	 to minimize memory utilization, this object is define when emergencyPushLocationReporting object exist
    /**
     * Creates a new CDR object.
     */
    public CDR()
    {
        // fileHeader
        this.sourceName = NOT_SET;
        this.fileName = NOT_SET;
        this.date = NOT_SET;
        this.noOfRecords = NOT_SET_INT;

        // PositionResult
        this.TrafficCase = NOT_SET_INT;
        this.LocationType = NOT_SET_INT;
        this.ClientId = NOT_SET;
        this.clientNo = NOT_SET;
        this.pushURL = NOT_SET;
        this.pushId = NOT_SET;
        this.errorCode = NOT_SET_INT;
        this.ClientType = NOT_SET_INT;
        this.privacyOverride = NOT_SET_INT;

        this.requestedPositionTime = NOT_SET;

        this.requestedAccuracy = NOT_SET_INT;
        this.responseTime = NOT_SET_INT;
        this.maxLocationAge = NOT_SET_INT;
        this.coordinateSystem = NOT_SET_INT;
        this.datum = NOT_SET_INT;

        this.singlePositionsList = new ArrayList();

        this.subscriberDataList = new ArrayList();

        this.initiationRequestId = NOT_SET;
        this.initiationTriggerCriterionType = NOT_SET_INT;
        this.initiationClientId = NOT_SET;
        this.initiationClientNo = NOT_SET;
        this.initiationspeed = NOT_SET_INT;
        this.initiationTime = NOT_SET;
        this.initiationErrorCode = NOT_SET_INT;
        this.initiationStartTime = NOT_SET;
        this.initiationStopTime = NOT_SET;
        this.initiationRecurrenceInterval = NOT_SET_INT;
        this.initiationrequestedAccuracyMeters = NOT_SET_INT;

        this.reportRequestId = NOT_SET;
        this.reportTriggerCriterionType = NOT_SET_INT;
        this.reportClientId = NOT_SET;
        this.reportClientNo = NOT_SET;
        this.reportspeed = NOT_SET_INT;
        this.reportTime = NOT_SET;
        this.reportErrorCode = NOT_SET_INT;
        this.reportStartTime = NOT_SET;
        this.reportStopTime = NOT_SET;
        this.reportPushURL = NOT_SET;
        this.reportPushID = NOT_SET;
        this.reportRecurrentReport = NOT_SET_INT;
        this.reportrequestedAccuracyMeters = NOT_SET_INT;
        this.reportobtainedAccuracy = NOT_SET_INT;
        this.reportlocationEstimateIncluded = NOT_SET_INT;

        this.allPhonesWithinAreaRequestId = NOT_SET;
        this.allPhonesWithinAreaClientId = NOT_SET;
        this.allPhonesWithinAreaClientNo = NOT_SET;
        this.amountOfSubscribersReported = NOT_SET_INT;
        this.allPhonesWithinAreaReportTime = NOT_SET;
        this.allPhonesWithinAreaErrorCode = NOT_SET_INT;
        this.pushUrl = NOT_SET;
        this.allPhonesWithinAreaPushId = NOT_SET;
        this.locationEstimateIncluded = NOT_SET_INT;

        this.terminationRequestId = NOT_SET;
        this.terminationTriggerCriterionType = NOT_SET_INT;
        this.terminationClientId = NOT_SET;
        this.terminationClientNo = NOT_SET;
        this.terminationspeed = NOT_SET_INT;
        this.terminationTime = NOT_SET;
        this.terminationErrorCode = NOT_SET_INT;
        this.terminationStopTime = NOT_SET;
        this.terminationStartTime = NOT_SET;

        // to minimize memory utilization, this object is define when emergencyPushLocationReporting object exist
        //this.emergencyPushLocationReporting = new EmergencyPushLocationReporting();
    }

    /**
     * DOCUMENT ME!
     *
     * @param b DOCUMENT ME!
     * @param tag DOCUMENT ME!
     */
    public void setUnknownTag(BEROctetString b, int tag)
    {
        this.unknown_tags = this.unknown_tags + " Unknown tag: " + tag + " Value: " + b.toString() + "\n";
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public String getUnknownTags()
    {
        return this.unknown_tags;
    }

    /**
     * DOCUMENT ME!
     *
     * @param val DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    private String printVal(int val)
    {
        if (val == NOT_SET_INT)
        {
            return NOT_SET;
        }

        return Integer.toString(val);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public String toString2() throws EgtException
    {
        String txt = "";

        if (this.getUnknownTags() != null)
        {
            throw new EgtException(" CDR format error : " + this.getUnknownTags());
        }

        if ((this.sourceName != NOT_SET) && (this.TrafficCase == NOT_SET_INT))
        {
            txt = "GMPC.PositionDataRecord.fileHeader\r\n" + "{\r\n" + "\tsourceName " + this.sourceName + "\r\n"
                  + "\tfileName " + this.fileName + "\r\n" + "\tdate " + this.date + "\r\n" + "\tnoOfRecords "
                  + printVal(this.noOfRecords) + "\r\n" + "}\r\n";
        }

        if ((this.TrafficCase != NOT_SET_INT) && (this.sourceName == NOT_SET))
        {
            txt = txt + "GMPC.PositionDataRecord.positionResult\r\n" + "{\r\n" + "\ttrafficCase "
                  + printVal(this.TrafficCase) + "\r\n" + "\tlocationType " + printVal(this.LocationType) + "\r\n"
                  + "\tclientId " + this.ClientId + "\r\n" + "\tclientNo " + this.clientNo + "\r\n" + "\tpushURL "
                  + this.pushURL + "\r\n" + "\tpushId " + this.pushId + "\r\n" + "\terrorCode "
                  + printVal(this.errorCode) + "\r\n" + "\tclientType " + printVal(this.ClientType) + "\r\n"
                  + "\tprivacyOverride " + printVal(this.privacyOverride) + "\r\n" + "\tGeographicalInfo\r\n"
                  + "\t{\r\n" + "\t\tcoordinateSystem " + this.coordinateSystem + "\r\n" + "\t\tdatum "
                  + printVal(this.datum) + "\r\n" + "\t}\r\n" + "\tQoS\r\n" + "\t{\r\n" + "\t\trequestedAccuracy "
                  + printVal(this.requestedAccuracy) + "\r\n" + "\t\trequestedAccuracyMeters "
                  + printVal(this.requestedAccuracyMeters) + "\r\n" + "\t\tresponseTime " + this.responseTime + "\r\n"
                  + "\t}\r\n" + "\tEmergencyInfo\r\n" + "\t{\r\n" + "\t}\r\n" + "\trequestedPositionTime "
                  + this.requestedPositionTime + "\r\n" + "\tsinglePositions\r\n" + "\t{\r\n";

            int i = 0;
            Iterator a = this.singlePositionsList.iterator();

            while (a.hasNext())
            {
                SinglePosition singleposition = (SinglePosition) a.next();

                if (singleposition.errorCode != NOT_SET_INT)
                {
                    txt = txt + "\t\t[" + i++ + "]\r\n" + singleposition.toString2();
                }
            }

            txt = txt + "\t}\r\n" + "\tsubclientNo " + this.subClientNO + "\r\n" + "\tclientRequestor "
                  + this.clientRequestor + "\r\n" + "\tclientServiceType " + this.clientServiceType + "\r\n}\r\n";
        }

        return txt;
    }

    /**
     * DOCUMENT ME!
     *
     * @param GmpcName DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public String toLog(String GmpcName) throws EgtException
    {
        String txt = "";
        String txttmp = "";

        if (this.getUnknownTags() != null)
        {
            throw new EgtException(" CDR format error : " + this.getUnknownTags());
        }

        if (this.sourceName != NOT_SET)
        {
            txt = this.sourceName + " " + this.date + " " + this.fileName + " " + this.noOfRecords + " records";
        }

        if ((this.TrafficCase != NOT_SET_INT) && (this.sourceName == NOT_SET))
        {
            txttmp = GmpcName + " " + this.requestedPositionTime + " " + this.ClientId + " " + this.ClientType + " "
                     + this.errorCode;

            SinglePosition singleposition = new SinglePosition();
            ListIterator it = this.singlePositionsList.listIterator();
            int i = 0;

            while (it.hasNext())
            {
                singleposition = (SinglePosition) it.next();

                if (singleposition.errorCode != NOT_SET_INT)
                {
                    if (i != 0)
                    {
                        txt = txt + "\r\n" + txttmp + " [" + i + "] " + singleposition.toLog();
                    }
                    else
                    {
                        txt = " [" + i + "] " + singleposition.toLog();
                    }
                }

                i++;
            }

            return txttmp + txt;
        }

        return txt;
    }

    /**
     * DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public void check() throws EgtException
    {
        if (this.getUnknownTags() != null)
        {
            throw new EgtException(" CDR format error : " + this.getUnknownTags());
        }

        SinglePosition singleposition = new SinglePosition();
        ListIterator it = this.singlePositionsList.listIterator();

        while (it.hasNext())
        {
            singleposition = (SinglePosition) it.next();
            singleposition.check();
        }
    }
}
