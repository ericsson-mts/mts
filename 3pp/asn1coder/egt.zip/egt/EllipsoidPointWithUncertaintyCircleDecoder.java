package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (not in MPS7)
 * EllipsoidPointWithUncertaintyCircle ::= SEQUENCE 
 * {
 *  time            [1] IMPLICIT IA5String, 
 *  coordinate      [2] IMPLICIT Coordinate,
 *  radius          [3] IMPLICIT IA5String
 * } 
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EllipsoidPointWithUncertaintyCircleDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int TIME = 1;
  public static final int COORDINATE = 2;
  public static final int RADIUS = 3;
  
  private EllipsoidPointWithUncertaintyCircle ellipsoidPointWithUncertaintyCircle;

  public EllipsoidPointWithUncertaintyCircleDecoder(EllipsoidPointWithUncertaintyCircle ellips) {
	  this.ellipsoidPointWithUncertaintyCircle = ellips;
  }
  
  public EllipsoidPointWithUncertaintyCircle getEllipsoidPointWithUncertaintyCircle() {
  	return this.ellipsoidPointWithUncertaintyCircle;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("ellipsoidPointWithUncertaintyEllipse ======= " + tag);
    }

    // TIME
    if (tag == (TIME | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPointWithUncertaintyCircle.time = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "ellipsoidPointWithUncertaintyCircle time ======= " + this.ellipsoidPointWithUncertaintyCircle.time);
        }
        return b;
    }
    
	 //	COORDINATE
	 if (tag == (COORDINATE | 0x80 | 0x20)) { 		
		  CoordinateDecoder Coordinate_decoder = new CoordinateDecoder(this.ellipsoidPointWithUncertaintyCircle.coordinate);
	      BERSequence b = new BERSequence(Coordinate_decoder, io, ia);
	      this.ellipsoidPointWithUncertaintyCircle.coordinate= Coordinate_decoder.getCoordinate();
	      if (DEBUG) {
	          System.err.println("ellipsoidPointWithUncertaintyCircle COORDINATE =======");
	      }
	      return b;
	 }
    
    
    // ANGLE
    if (tag == (RADIUS | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPointWithUncertaintyCircle.radius = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "ellipsoidPointWithUncertaintyCircle angle =======" + this.ellipsoidPointWithUncertaintyCircle.radius);
        }
        return b;
    }

    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.ellipsoidPointWithUncertaintyCircle.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("ellipsoidPointWithUncertaintyCircle setUnknownTag ======= " + this.ellipsoidPointWithUncertaintyCircle.getUnknownTags());
    }
    return b;
  }





}