package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.BEROctetString;

/**
 * ASN1 MPS9 (Not in MPS7)
 *
 * EmergencyPushLocationReporting ::= CHOICE 
 * { 
 * callOrigination  [1] IMPLICIT EmergencyCallRelated,
 * callRelease      [2] IMPLICIT EmergencyCallRelated,
 * pushResult       [3] IMPLICIT EmergencyPushResult 
 *} 
*/

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyPushLocationReporting {
	private String unknown_tags;

	// begin EmergencyPushLocationReporting
	public EmergencyCallRelated callOrigination;
	public EmergencyCallRelated callRelease;
	public EmergencyPushResult pushResult;
	// end EmergencyPushLocationReporting

	public EmergencyPushLocationReporting() {		
		// begin EmergencyPushLocationReporting
		this.callOrigination = new EmergencyCallRelated();
		this.callRelease = new EmergencyCallRelated();
		this.pushResult = new EmergencyPushResult();
		// end EmergencyPushLocationReporting	
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag
				+ " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : "
					+ this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n" 
				+ "\t\t\tcallOrigination " + this.callOrigination.toString2() + "\r\n"
				+ "\t\t\tcallRelease " + this.callRelease.toString2() + "\r\n"
				+ "\t\t\tpushResult " + this.pushResult.toString2() + "\r\n"
				+ "\t\t}\r\n";
		return txt;
	}

	public String toLog() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}
}
