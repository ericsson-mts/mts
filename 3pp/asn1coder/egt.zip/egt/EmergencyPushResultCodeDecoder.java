package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (not in MPS7)
 * EmergencyPushResultCode ::= CHOICE 
 * { 
 * successCode       [1] IMPLICIT INTEGER, 
 * failureCode       [2] IMPLICIT INTEGER 
 * } 
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyPushResultCodeDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  public static final int SUCCESSCODE = 1;
  public static final int FAILURECODE = 2;

  private EmergencyPushResultCode emergencyPushResultCode;

  public EmergencyPushResultCodeDecoder(EmergencyPushResultCode emergencyPRC) {
	  this.emergencyPushResultCode = emergencyPRC;
  }
  
  public EmergencyPushResultCode getEmergencyPushResultCode() {
  	return this.emergencyPushResultCode;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("emergencyPushResultCode ========================== " + tag);
    }

    // SUCCESSCODE
    if (tag == (SUCCESSCODE | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
  	  	this.emergencyPushResultCode.successCode =b.getValue();
    	if (DEBUG) {
    		System.err.println( "emergencyPushResultCode successCode ========================== " + this.emergencyPushResultCode.successCode);
        }
        return b;
    }
    
    // FAILURECODE
    if (tag == (FAILURECODE | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
  	  	this.emergencyPushResultCode.failureCode =b.getValue();
    	if (DEBUG) {
    		System.err.println( "emergencyPushResultCode failureCode ========================== " + this.emergencyPushResultCode.failureCode);
        }
        return b;
    }
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.emergencyPushResultCode.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("emergencyPushResultCode setUnknownTag ========================== " + this.emergencyPushResultCode.getUnknownTags());
    }
    return b;
  }





}