
package com.ericsson.mps.egt;

import java.util.ArrayList;
import java.util.List;

import com.ericsson.mps.egt.cdrdecoder.BEROctetString;

/**
 * ASN1 MPS10
 * WirelineEmergencyLocationRetrieving::= SEQUENCE
 * {
 * locationType 								[1] IMPLICIT LocationType OPTIONAL,
 * clientId 									[2] IMPLICIT IA5String OPTIONAL,
 * clientNo 									[3] IMPLICIT IA5String OPTIONAL,
 * errorCode 									[4] IMPLICIT INTEGER,
 * clientType 									[5] IMPLICIT ClientType OPTIONAL,
 * privacyOverride 								[6] IMPLICIT INTEGER OPTIONAL,
 * geographicalInfo 							[7] IMPLICIT GeographicalInfo OPTIONAL,
 * qos 											[8] IMPLICIT QoS OPTIONAL,
 * requestedPositionTime 						[9] IMPLICIT IA5String,
 * singleWirelineEmergencyLocationRetrieving 	[10]IMPLICIT SEQUENCE OF SingleWirelineEmergencyLocationRetrieving,
 * subclientNo 									[11] IMPLICIT IA5String OPTIONAL,
 * clientRequestor 								[12] IMPLICIT IA5String OPTIONAL,
 * clientServiceType 							[13] IMPLICIT INTEGER OPTIONAL
 *}
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class WirelineEmergencyLocationRetrieving{
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";
	private static final int NOT_SET_INT = 0x80000000;

	public int locationType;
	public String clientId;
	public String clientNo;
	public int errorCode;
	public int clientType;
	public int privacyOverride;
	public GeographicalInfo geographicalInfo;	
	public QoS qos;
	public String requestedPositionTime;
	public List<SingleWirelineEmergencyLocationRetrieving> singleWirelineEmergencyLocationRetrieving;
	public String subclientNo;
	public String clientRequestor;
	public int clientServiceType;
	


	public WirelineEmergencyLocationRetrieving() {		
		
		this.locationType = NOT_SET_INT;
		this.clientId = NOT_SET;
		this.clientNo = NOT_SET;
		this.errorCode = NOT_SET_INT;
		this.clientType = NOT_SET_INT;
		this.privacyOverride = NOT_SET_INT;
		this.geographicalInfo = new GeographicalInfo();
		this.qos = new QoS();
		this.requestedPositionTime = NOT_SET;
		this.singleWirelineEmergencyLocationRetrieving = new ArrayList<SingleWirelineEmergencyLocationRetrieving>();
		this.subclientNo = NOT_SET;
		this.clientRequestor = NOT_SET;
		this.clientServiceType = NOT_SET_INT;
			
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag
		+ " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : "
					+ this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n" 
			+ "\t\t\tlocationType " + this.locationType + "\r\n"
			+ "\t\t\tclientId " + this.clientId + "\r\n"
			+ "\t\t\tclientNo " + this.clientNo + "\r\n"
			+ "\t\t\terrorCode " + this.errorCode + "\r\n"
			+ "\t\t\tclientType " + this.clientType + "\r\n"
			+ "\t\t\tprivacyOverride " + this.privacyOverride + "\r\n"				
			+ "\t\t\tgeographicalInfo " + this.geographicalInfo.toString2() + "\r\n"
			+ "\t\t\tqos " + this.qos.toString2() + "\r\n"
			+ "\t\t\trequestedPositionTime " + this.requestedPositionTime + "\r\n"
			+ "\t\t\tsingleWirelineEmergencyLocationRetrieving " + this.singleWirelineEmergencyLocationRetrieving + "\r\n"
			+ "\t\t\tsubclientNo " + this.subclientNo + "\r\n"
			+ "\t\t\tclientRequestor " + this.clientRequestor + "\r\n"
			+ "\t\t\tclientServiceType " + this.clientServiceType + "\r\n"
			+ "\t\t}\r\n";
		return txt;
	}

	public String toLog() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}

	private String printVal(int val) {
		if (val == 0x80000000) {
			return NOT_SET;
		}
		return Integer.toString(val);
	}

}
