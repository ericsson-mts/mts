package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.BEROctetString;

/**
 * ASN1 MPS9 (Not in MPS7)
 * EmergencyCallRelated ::= SEQUENCE 
 *{ 
 * clientNo           [1] IMPLICIT IA5String, 
 * mSISDN             [2] IMPLICIT IA5String OPTIONAL, 
 * iMEI               [3] IMPLICIT IA5String OPTIONAL, 
 * iMSI               [4] IMPLICIT IA5String OPTIONAL, 
 * positionResult     [5] EXPLICIT EmergencyPositionResult OPTIONAL, 
 * network            [6] IMPLICIT Network OPTIONAL,
 * usedlocationmethod [7] IMPLICIT UsedLocationMethod OPTIONAL
 *} 
*/

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EmergencyCallRelated {
	private String unknown_tags;

	public static final String NOT_SET = "<Not_Set>";
	private static final int NOT_SET_INT = 0x80000000;

	// begin EmergencyPushResult
	public String clientNo;
	public String mSISDN;
	public String iMEI;
	public String iMSI;
	public EmergencyPositionResult positionResult;
	public int network;
	public int usedlocationmethod;	
	// end EmergencyPushResult

	public EmergencyCallRelated() {		
		// begin EmergencyPositionResult
		this.clientNo = NOT_SET;
		this.mSISDN = NOT_SET;
		this.iMEI = NOT_SET;
		this.iMSI = NOT_SET;
		this.positionResult = new EmergencyPositionResult();
		this.network = NOT_SET_INT;
		this.usedlocationmethod = NOT_SET_INT;
		// end EmergencyPositionResult	
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag
				+ " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : "
					+ this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n" 
				+ "\t\t\tclientNo " + this.clientNo + "\r\n"
				+ "\t\t\tmSISDN " + this.mSISDN + "\r\n"
				+ "\t\t\tiMEI " + this.iMEI + "\r\n"
				+ "\t\t\tiMSI " + this.iMSI + "\r\n"
				+ "\t\t\tpositionResult " + this.positionResult.toString2() + "\r\n"
				+ "\t\t\tnetwork " + printVal(this.network) + "\r\n"				
				+ "\t\t\tusedlocationmethod " + printVal(this.usedlocationmethod) + "\r\n"					
				+ "\t\t}\r\n";
		return txt;
	}

	public String toLog() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
	}
	
	private String printVal(int val) {
		if (val == 0x80000000) {
			return NOT_SET;
		}
		return Integer.toString(val);
	}

}
