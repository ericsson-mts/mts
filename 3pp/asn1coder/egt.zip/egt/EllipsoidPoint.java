package com.ericsson.mps.egt;

import com.ericsson.mps.egt.cdrdecoder.BEROctetString;

/**
 * ASN1 MPS9 (not in MPS7)
 * EllipsoidPoint ::= SEQUENCE 
 * { 
 * latitude             [1] IMPLICIT IA5String, 
 * longitude            [2] IMPLICIT IA5String, 
 * time          		[3] IMPLICIT IA5String 
 * } 
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EllipsoidPoint {
	private String unknown_tags;
	public static final String NOT_SET = "<Not_Set>";

	public String latitude;
	public String longitude;
	public String time;

	public EllipsoidPoint() {
		this.latitude = NOT_SET;
		this.longitude = NOT_SET;
		this.time = NOT_SET;
	}

	public void setUnknownTag(BEROctetString b, int tag) {
		this.unknown_tags = this.unknown_tags + "Unknown tag: " + tag
				+ " Value: " + b.toString() + "\n";
	}

	public String getUnknownTags() {
		return this.unknown_tags;
	}

	public String toString2() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : "
					+ this.getUnknownTags());
		}
		String txt = "";
		txt = "\t\t{\r\n" 
				+ "\t\t\tlatitude " + this.latitude + "\r\n"
				+ "\t\t\tlongitude " + this.longitude + "\r\n"
				+ "\t\t\ttime " + this.time + "\r\n"
				+ "\t\t}\r\n";
		return txt;
	}

	public String toLog() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : " + this.getUnknownTags());
		}
		String txt = "";
		return txt;
	}

	public void check() throws EgtException {
		if (this.getUnknownTags() != null) {
			throw new EgtException(" CDR format error : "
					+ this.getUnknownTags());
		}
	}

}
