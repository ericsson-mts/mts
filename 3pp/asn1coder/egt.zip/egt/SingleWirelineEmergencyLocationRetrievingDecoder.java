package com.ericsson.mps.egt;

import java.io.*;
import java.util.List;

import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10
 * SingleWirelineEmergencyLocationRetrieving ::= SEQUENCE
 * {
 * errorCode 									[1] IMPLICIT INTEGER,
 * targetTELURI 								[2] IMPLICIT IA5String OPTIONAL,
 * location 									[3] IMPLICIT IA5String OPTIONAL
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esfbovi
 * @version R3-CP00
 */

public class SingleWirelineEmergencyLocationRetrievingDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int ERRORCODE = 1;
  public static final int TARGETTELURI = 2;
  public static final int LOCATION = 3;
  
  private SingleWirelineEmergencyLocationRetrieving singleWirelineEmergencyLocationRetrieving;
  private List<SingleWirelineEmergencyLocationRetrieving> singleWirelineEmergencyLocationRetrievingList;

  public SingleWirelineEmergencyLocationRetrievingDecoder(SingleWirelineEmergencyLocationRetrieving singleWirelineEmergencyLocationRetrieving) {
	  this.singleWirelineEmergencyLocationRetrieving = singleWirelineEmergencyLocationRetrieving;
  }
  
  public SingleWirelineEmergencyLocationRetrievingDecoder(List<SingleWirelineEmergencyLocationRetrieving> singleWirelineEmergencyLocationRetrievingList) {
	  this.singleWirelineEmergencyLocationRetrievingList = singleWirelineEmergencyLocationRetrievingList;
  }
  
  public SingleWirelineEmergencyLocationRetrieving getSingleWirelineEmergencyLocationRetrieving() {
  	return this.singleWirelineEmergencyLocationRetrieving;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("SingleWirelineEmergencyLocationRetrieving ======= " + tag);
    }
    
    
    // ERRORCODE
    if (tag == (ERRORCODE | 0x80)) {
        BERInteger b = new BERInteger(io, ia);
        this.singleWirelineEmergencyLocationRetrieving.errorCode =b.getValue();
    	if (DEBUG) {
    		System.err.println( "singleWirelineEmergencyLocationRetrieving errorCode ========================== " + this.singleWirelineEmergencyLocationRetrieving.errorCode);
        }
        return b;
    }

    // TARGETTELURI
    if (tag == (TARGETTELURI | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.singleWirelineEmergencyLocationRetrieving.targetTELURI = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "singleWirelineEmergencyLocationRetrieving targetTELURI ======= " + this.singleWirelineEmergencyLocationRetrieving.targetTELURI);
        }
        return b;
    }
    
    // LOCATION
    if (tag == (LOCATION | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.singleWirelineEmergencyLocationRetrieving.location = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "singleWirelineEmergencyLocationRetrieving location ======= " + this.singleWirelineEmergencyLocationRetrieving.location);
        }
        return b;
    }
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.singleWirelineEmergencyLocationRetrieving.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("singleWirelineEmergencyLocationRetrieving setUnknownTag ======= " + this.singleWirelineEmergencyLocationRetrieving.getUnknownTags());
    }
    return b;
  }





}
