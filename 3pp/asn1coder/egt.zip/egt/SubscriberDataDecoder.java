package com.ericsson.mps.egt;

import java.io.IOException;
import java.io.InputStream;

import com.ericsson.mps.egt.cdrdecoder.BERElement;
import com.ericsson.mps.egt.cdrdecoder.BEREnumerated;
import com.ericsson.mps.egt.cdrdecoder.BEROctetString;
import com.ericsson.mps.egt.cdrdecoder.BERTagDecoder;

/**
 * ASN1 MPS9 (<>MPS7)
 * SubscriberData ::= SEQUENCE
 * {
 * targetMS                [1] IMPLICIT IA5String,
 * numberMSC               [2] IMPLICIT IA5String OPTIONAL,
 * positionTime            [3] IMPLICIT IA5String OPTIONAL,
 * network                 [4] IMPLICIT Network OPTIONAL,
 * usedlocationmethod      [5] IMPLICIT UsedLocationMethod OPTIONAL
 *}
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R3-CP00
 */

public class SubscriberDataDecoder extends BERTagDecoder {
	public static final boolean DEBUG = false;

	public static final int TARGETMS = 1;
	public static final int NUMBERMSC = 2;
	public static final int POSITIONTIME = 3;
	public static final int NETWORK = 4;
	public static final int USEDLOCATIONMETHOD = 5;

	private CDR cdr;

	private SubscriberData subscriberData;

	public SubscriberDataDecoder(CDR aCDR) {
		this.cdr = aCDR;
	}

	public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
			int ia[], boolean implicit[]) throws IOException {
		
		if (DEBUG) {
			System.err.println("SubscriberDataDecoder getElement ========================== " + tag);
		}
		
		// TARGETMS
		if (tag == (TARGETMS | 0x80)) {
			if (this.cdr.subscriberDataList.isEmpty()) {
				this.subscriberData = new SubscriberData();
				this.cdr.subscriberDataList.add(this.subscriberData);
				if (DEBUG) {
					System.err.println("SubscriberDataDecoder TARGETMS== subscriberDataList isEmpty");
				}
			}
			if (DEBUG) {
				System.err.println("SubscriberDataDecoder  ========================== " + this.cdr.subscriberDataList.size());
			}
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.subscriberData = (SubscriberData) this.cdr.subscriberDataList.get(this.cdr.subscriberDataList.size() - 1);

			this.subscriberData.targetMS = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println("SubscriberDataDecoder TARGETMS ========================== " + this.subscriberData.targetMS);
			}
			return b;
		}
		
		// NUMBERMSC
		if (tag == (NUMBERMSC | 0x80)) {
			if (this.cdr.subscriberDataList.isEmpty()) {
				this.subscriberData = new SubscriberData();
				this.cdr.subscriberDataList.add(this.subscriberData);
				if (DEBUG) {
					System.err.println("SubscriberDataDecoder TARGETMS== subscriberDataList isEmpty");
				}
			}
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.subscriberData = (SubscriberData) this.cdr.subscriberDataList.get(this.cdr.subscriberDataList.size() - 1);
			this.subscriberData.numberMSC = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println("SubscriberDataDecoder NUMBERMSC ========================== "+ this.subscriberData.numberMSC);
			}
			return b;
		}
		
		// POSITIONTIME
		if (tag == (POSITIONTIME | 0x80)) {
			if (this.cdr.subscriberDataList.isEmpty()) {
				this.subscriberData = new SubscriberData();
				this.cdr.subscriberDataList.add(this.subscriberData);
				if (DEBUG) {
					System.err.println("SubscriberDataDecoder POSITIONTIME== subscriberDataList isEmpty");
				}
			}
			BEROctetString b = new BEROctetString(dec, io, ia);
			this.subscriberData = (SubscriberData) this.cdr.subscriberDataList.get(this.cdr.subscriberDataList.size() - 1);
			this.subscriberData.positionTime = new String(b.getValue(), 0, b.getValue().length);
			if (DEBUG) {
				System.err.println("SubscriberDataDecoder POSITIONTIME ========================== " + this.subscriberData.positionTime);
			}
			return b;
		}
		
		// NETWORK
		if (tag == (NETWORK | 0x80)) {
			if (this.cdr.subscriberDataList.isEmpty()) {
				this.subscriberData = new SubscriberData();
				this.cdr.subscriberDataList.add(this.subscriberData);
				if (DEBUG) {
					System.err.println("SubscriberDataDecoder NETWORK== subscriberDataList isEmpty");
				}
			}
			BEREnumerated b = new BEREnumerated(io, ia);
			this.subscriberData = (SubscriberData) this.cdr.subscriberDataList.get(this.cdr.subscriberDataList.size() - 1);
			this.subscriberData.network = b.getValue();
			if (DEBUG) {
				System.err.println("SubscriberDataDecoder NETWORK ========================== " + this.subscriberData.positionTime.toString());
			}
			return b;
		}		
		
		// USEDLOCATIONMETHOD
		if (tag == (USEDLOCATIONMETHOD | 0x80)) {
			if (this.cdr.subscriberDataList.isEmpty()) {
				this.subscriberData = new SubscriberData();
				this.cdr.subscriberDataList.add(this.subscriberData);
				if (DEBUG) {
					System.err.println("SubscriberDataDecoder USEDLOCATIONMETHOD== subscriberDataList isEmpty");
				}
			}
			BEREnumerated b = new BEREnumerated(io, ia);
			this.subscriberData = (SubscriberData) this.cdr.subscriberDataList.get(this.cdr.subscriberDataList.size() - 1);
			this.subscriberData.network = b.getValue();
			if (DEBUG) {
				System.err.println("SubscriberDataDecoder USEDLOCATIONMETHOD =================== " + this.subscriberData.positionTime.toString());
			}
			return b;
		}				

		// else UnknownTag
		if (this.cdr.subscriberDataList.isEmpty()) {
			this.subscriberData = new SubscriberData();
			this.cdr.subscriberDataList.add(this.subscriberData);
		}
		BEROctetString b = new BEROctetString(dec, io, ia);
		this.subscriberData = (SubscriberData) this.cdr.subscriberDataList.get(this.cdr.subscriberDataList.size() - 1);
		this.subscriberData.setUnknownTag(b, tag);
		if (DEBUG) {
			System.err.println("SubscriberDataDecoder setUnknownTag ==========================" + this.subscriberData.getUnknownTags());
		}
		return b;
	}

}
