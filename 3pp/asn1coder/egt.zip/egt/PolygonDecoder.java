package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS10 
 * Polygon ::= SEQUENCE
 * {
 * time 			[1] IMPLICIT IA5String,
 * coordinates 		[2] IMPLICIT SEQUENCE OF Coordinate
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class PolygonDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  public static final int TIME = 1;
  public static final int  COORDINATES= 2;

  private Polygon polygon;

  public PolygonDecoder(Polygon polygon) {
	  this.polygon = polygon;
  }
  
  public Polygon getPolygon() {
  	return this.polygon;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("Polygon ========================== " + tag);
    }
    
    // TIME
    if (tag == (TIME | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.polygon.time = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "Polygon time ========================== " + this.polygon.time);
        }
        return b;
    }
    
    // COORDINATES
    if (tag == (COORDINATES | 0x80 | 0x20)) {
    	
    	CoordinateDecoder coordinate_att_decoder = new CoordinateDecoder(this.polygon.coordinates);
        BERSequence brs = new BERSequence(coordinate_att_decoder, io, ia);
        if (DEBUG) {
     	   System.err.println("Polygon coordinate ==========================");
        }
        return brs;
    }
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.polygon.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("Polygon setUnknownTag ========================== " + this.polygon.getUnknownTags());
    }
    return b;
  }





}
