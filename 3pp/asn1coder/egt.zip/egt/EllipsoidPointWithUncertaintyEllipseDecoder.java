package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (not in MPS7)
 * EllipsoidPointWithUncertaintyEllipse ::= SEQUENCE 
 * { 
 * time              [1]  IMPLICIT IA5String, 
 * coordinate        [2]  IMPLICIT Coordinate, 
 * angle             [3]  IMPLICIT IA5String, 
 * semiMajor         [4]  IMPLICIT IA5String, 
 * semiMinor         [5]  IMPLICIT IA5String 
 * } 
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author metchbl
 * @version R3-CP00
 */

public class EllipsoidPointWithUncertaintyEllipseDecoder extends BERTagDecoder {
  public static final boolean DEBUG = PositionDataRecordDecoder.DEBUG;
  
  public static final int TIME = 1;
  public static final int COORDINATE = 2;
  public static final int ANGLE = 3;
  public static final int SEMIMAJOR = 4;
  public static final int SEMIMINOR = 5;
  
  private EllipsoidPointWithUncertaintyEllipse ellipsoidPointWithUncertaintyEllipse;

  public EllipsoidPointWithUncertaintyEllipseDecoder(EllipsoidPointWithUncertaintyEllipse ellips) {
	  this.ellipsoidPointWithUncertaintyEllipse = ellips;
  }
  
  public EllipsoidPointWithUncertaintyEllipse getEllipsoidPointWithUncertaintyEllipse() {
  	return this.ellipsoidPointWithUncertaintyEllipse;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
    	System.err.println("ellipsoidPointWithUncertaintyEllipse ======= " + tag);
    }

    // TIME
    if (tag == (TIME | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPointWithUncertaintyEllipse.time = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "ellipsoidPointWithUncertaintyEllipse time ======= " + this.ellipsoidPointWithUncertaintyEllipse.time);
        }
        return b;
    }
    
	 //	COORDINATE
	 if (tag == (COORDINATE | 0x80 | 0x20)) { 		
		  CoordinateDecoder Coordinate_decoder = new CoordinateDecoder(this.ellipsoidPointWithUncertaintyEllipse.coordinate);
	      BERSequence b = new BERSequence(Coordinate_decoder, io, ia);
	      this.ellipsoidPointWithUncertaintyEllipse.coordinate= Coordinate_decoder.getCoordinate();
	      if (DEBUG) {
	          System.err.println("ellipsoidPointWithUncertaintyEllipse COORDINATE =======");
	      }
	      return b;
	 }
    
    
    // ANGLE
    if (tag == (ANGLE | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPointWithUncertaintyEllipse.angle = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "ellipsoidPointWithUncertaintyEllipse angle =======" + this.ellipsoidPointWithUncertaintyEllipse.angle);
        }
        return b;
    }
    
    // SEMIMAJOR
    if (tag == (SEMIMAJOR | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPointWithUncertaintyEllipse.semiMajor = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "ellipsoidPointWithUncertaintyEllipse semiMajor =======" + this.ellipsoidPointWithUncertaintyEllipse.semiMajor);
        }
        return b;
    }
 
    
    // SEMIMINOR
    if (tag == (SEMIMINOR | 0x80)) {
    	BEROctetString b = new BEROctetString(dec, io, ia);
    	this.ellipsoidPointWithUncertaintyEllipse.semiMinor = new String(b.getValue(), 0, b.getValue().length);
    	if (DEBUG) {
    		System.err.println( "ellipsoidPointWithUncertaintyEllipse semiMinor =======" + this.ellipsoidPointWithUncertaintyEllipse.semiMinor);
        }
        return b;
    }
    
    
    // else UnknownTag
	BEROctetString b = new BEROctetString(dec, io, ia);
	this.ellipsoidPointWithUncertaintyEllipse.setUnknownTag(b, tag);
    if (DEBUG) {
        System.err.println("ellipsoidPointWithUncertaintyEllipse setUnknownTag ======= " + this.ellipsoidPointWithUncertaintyEllipse.getUnknownTags());
    }
    return b;
  }





}