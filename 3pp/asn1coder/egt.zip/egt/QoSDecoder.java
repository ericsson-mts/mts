package com.ericsson.mps.egt;

import java.io.*;
import com.ericsson.mps.egt.cdrdecoder.*;

/**
 * ASN1 MPS9 (=MPS7)
 * QoS ::= SEQUENCE
 * {
 * requestedAccuracy       [1] IMPLICIT HorizontalAccuracy,
 * requestedAccuracyMeters [2] IMPLICIT INTEGER,
 * responseTime            [3] IMPLICIT ResponseTime
 * }
 */

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */

public class QoSDecoder
    extends BERTagDecoder {
	public static final  boolean DEBUG = PositionDataRecordDecoder.DEBUG;

  public static final int REQUESTEDACCURACY = 1;
  public static final int REQUESTEDACCURACYMETERS= 2;
  public static final int RESPONSETIME = 3;
  public static final int MAXLOCATIONAGE = 4; // MPS V3
  private CDR cdr = null;
  private QoS qos = null;

  public QoSDecoder(CDR Cdr) {
    this.cdr = Cdr;
  }
  
  public QoSDecoder(QoS qos) {
	    this.qos = qos;
  }

  public BERElement getElement(BERTagDecoder dec, int tag, InputStream io,
                               int ia[], boolean implicit[]) throws IOException {
    if (DEBUG) {
      System.err.println(
          "QoS ========================== " + tag);
    }

    if (tag == (REQUESTEDACCURACY | 0x80)) {
      BEREnumerated b = new BEREnumerated(io, ia);
      if (cdr != null)
    	  this.cdr.requestedAccuracy = b.getValue();
      else
    	  qos.requestedAccuracy = b.getValue();
      if (DEBUG) {
        System.err.println(
            "QoS requestedAccuracy ========================== " +
            (cdr !=null?this.cdr.requestedAccuracy:qos.requestedAccuracy));
      }

      return b;
    }
	if (tag == (REQUESTEDACCURACYMETERS | 0x80)) {
	      BERInteger b = new BERInteger(io, ia);
	      if (cdr != null)
	    	  this.cdr.requestedAccuracyMeters = b.getValue();
	      else
	    	  qos.requestedAccuracyMeters = b.getValue();
		  
	      if (DEBUG) {
	        System.err.println(
	            "QoS requestedAccuracyMeters ========================== " +  (cdr !=null?this.cdr.requestedAccuracyMeters:qos.requestedAccuracy));
	      }

	      return b;
	    }
    if (tag == (RESPONSETIME | 0x80)) {
      BEREnumerated b = new BEREnumerated(io, ia);
      if (cdr != null)
    	  this.cdr.responseTime = b.getValue();
      else
    	  qos.responseTime = b.getValue();
      if (DEBUG) {
        System.err.println(
            "QoS responseTime ========================== " +  (cdr !=null?this.cdr.responseTime:qos.responseTime));
      }

      return b;
    }
  //MPS V3
    if (tag == (MAXLOCATIONAGE | 0x80)) {
    	BERInteger b = new BERInteger(io, ia);
    	if (cdr != null)
    		this.cdr.maxLocationAge = b.getValue();
        else
      	  qos.maxLocationAge = b.getValue();
		
	    if (DEBUG) {
	    System.err.println(
	         "QoS maxLocationAge ========================== " +  (cdr !=null?this.cdr.maxLocationAge:qos.maxLocationAge));
	      }
      return b;
    }
    //end MPS V3
	BEROctetString b = new BEROctetString(dec, io, ia);
	 this.cdr.setUnknownTag(b, tag);
      if (DEBUG) {
        System.err.println(
            "QoS setUnknownTag ========================== " +
            (cdr !=null?this.cdr.getUnknownTags():qos.getUnknownTags()));
      }

      return b;
  }

}