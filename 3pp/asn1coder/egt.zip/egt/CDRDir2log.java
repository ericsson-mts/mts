package com.ericsson.mps.egt;

import org.apache.log4j.*;

/**
 * <p>Titre : EGT</p>
 * <p>Description : enrichisement des log GMPC</p>
 * <p>Copyright : Copyright (c) 2008</p>
 * <p>Soci�t� : Ericsson</p>
 * @author esforcs
 * @version R1-CP00
 */
import java.io.*;

import java.text.*;

import java.util.*;
import java.util.regex.*;


/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
 */
public class CDRDir2log
{
    //    private static String nameloggerLog = "nameloggerLog";
    //    private static String nameloggertraffic = "nameloggertraffic";
    //	 private static Logger loggerLog = Logger.getLogger(nameloggerLog);
    //	    private static Logger loggertraffic = Logger.getLogger(nameloggertraffic);
    private final static String NAME_LOGGER_LOG = "nameloggerLog";
    private final static String NAME_LOGGER_TRAFFIC = "nameloggertraffic";
    private static Logger loggerLog;
    private static Logger loggerTraffic;
    private static String configFile;
    private static EgtConfig egtconfiguration;

    static
    {
        configFile = "./config/egt.properties";

        loggerLog = Logger.getLogger(NAME_LOGGER_LOG);
        loggerTraffic = Logger.getLogger(NAME_LOGGER_TRAFFIC);
    }

    private static File archivedir;
    private static long sleeptime; // Between 5 and 240
    private static int retention; // Between 1 and 35
    private static boolean startmode_; // 0 or 1

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public final static Logger getLoggerLog()
    {
        return (loggerLog);
    }

    /**
     * DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public final static Logger getLoggerTraffic()
    {
        return (loggerTraffic);
    }

    /**
     * DOCUMENT ME!
     *
     * @param args DOCUMENT ME!
     *
     * @throws EgtException DOCUMENT ME!
     */
    public static void main(String[] args) throws EgtException
    {
        if (args.length > 0)
        {
            if (args[0].toString().startsWith("-v"))
            {
                printBuildVersion();
                System.exit(0);
            }
        }

        startmode_ = validArg(args);

        File sourcedir = null;

        try
        {
            DailyRollingFileAppender rotatelog = new DailyRollingFileAppender(new PatternLayout("%d{yyyy-MM-dd HH:mm:ss,SSS} %p %m \r\n"),
                                                                              "./log/egt.log", "'.'yyyy-MM-dd");
            //loggerLog.addAppender(rotatelog);
            getLoggerLog().addAppender(rotatelog);

            DailyRollingFileAppender rotatetraffic = new DailyRollingFileAppender(new PatternLayout("%m \r\n"),
                                                                                  "./log/traffic.log",
                                                                                  "'.'yyyy-MM-dd_HH");
            //loggertraffic.addAppender(rotatetraffic);
            getLoggerTraffic().addAppender(rotatetraffic);
        }
        catch (Exception ex)
        {
            System.err.println(ex.toString());
            System.exit(2);
        }

        //loggerLog.info("100 egt started");
        getLoggerLog().info("100 egt started");

        try
        {
            egtconfiguration = EgtConfig.getInstance(configFile);
            egtconfiguration.setConfiguration();
            sourcedir = new File(egtconfiguration.sourcedir);
            archivedir = new File(egtconfiguration.archivedir);
            sleeptime = egtconfiguration.sleeptime;
            retention = egtconfiguration.retention;
            //loggerLog.info("101 Configuration load successful");
            getLoggerLog().info("101 Configuration load successful");
        }
        catch (Exception ex)
        {
            //loggerLog.fatal(ex.toString());
            //loggerLog.fatal("400 Configuration load failed");
            getLoggerLog().fatal(ex.toString());
            getLoggerLog().fatal("400 Configuration load failed");
            System.err.println(ex.toString());
            System.exit(2);
        }

        while (true)
        {
            File[] list = sourcedir.listFiles(new FileNameFilterImpl());
            //loggerLog.info("102 " + list.length + " CDR files to decode");
            getLoggerLog().info("102 " + list.length + " CDR files to decode");

            for (int i = 0; i < list.length; i++)
            {
                //loggerLog.info("102 file to decode " + list[i].getName());
                getLoggerLog().info("102 file to decode " + list[i].getName());

                // **********************
                // decode
                // **********************
                java.util.LinkedList cdrs = null;

                try
                {
                    if (list[i].canWrite())
                    {
                        cdrs = decode(list[i].getAbsolutePath());
                        //loggerLog.info("104 file decoded successful " + list[i].getName());
                        getLoggerLog().info("104 file decoded successful " + list[i].getName());
                    }
                    else
                    {
                        throw new EgtException("no write access to file " + list[i].getName());
                    }

                    // validate taht the decoding has work
                    CDR cDr;

                    for (ListIterator lst = cdrs.listIterator(); lst.hasNext();)
                    {
                        cDr = (CDR) lst.next();
                        cDr.check();
                    }
                }
                catch (EgtException e)
                {
                    //loggerLog.fatal(e.toString() + " " + list[i].getName());
                    //loggerLog.fatal("401 file decoded failed " + list[i].getName());
                    getLoggerLog().fatal(e.toString() + " " + list[i].getName());
                    getLoggerLog().fatal("401 file decoded failed " + list[i].getName());
                    System.exit(2);
                }

                try
                {
                    int iteration = 0;
                    String sourcename = "";

                    for (ListIterator lst = cdrs.listIterator(); lst.hasNext();)
                    {
                        if (iteration == 0)
                        {
                            sourcename = printCDR((CDR) lst.next(), sourcename);
                        }

                        if (lst.hasNext())
                        {
                            printCDR((CDR) lst.next(), sourcename);
                        }

                        iteration++;
                    }

                    //loggerLog.info("105 file print to log successful " + list[i].getName());
                    getLoggerLog().info("105 file print to log successful " + list[i].getName());
                }
                catch (Exception e)
                {
                    //loggerLog.fatal(e.toString() + " " + list[i].getName());
                    //loggerLog.fatal("402 file print to log failed " + list[i].getName());
                    getLoggerLog().fatal(e.toString() + " " + list[i].getName());
                    getLoggerLog().fatal("402 file print to log failed " + list[i].getName());
                    System.exit(2);
                }

                // **********************
                // backup decoded CDR
                // **********************
                try
                {
                    if (backup(list[i], archivedir))
                    {
                        //loggerLog.info("106 file backup successful " + list[i].getName());
                        getLoggerLog().info("106 file backup successful " + list[i].getName());
                    }
                    else
                    {
                        if (list[i].exists())
                        {
                            throw new EgtException("could not remove billing source file" + list[i].getName());
                        }

                        //loggerLog.error("200 file backup failed " + list[i].getName());
                        getLoggerLog().error("200 file backup failed " + list[i].getName());
                    }
                }
                catch (Exception ex1)
                {
                    //loggerLog.fatal(ex1.toString());
                    //loggerLog.fatal("403 file backup failed " + list[i].getName());
                    getLoggerLog().fatal(ex1.toString());
                    getLoggerLog().fatal("403 file backup failed " + list[i].getName());
                    System.exit(2);
                }
            }

            // **********************
            // purge des archives
            // **********************
            try
            {
                retention("Billing*", archivedir.getAbsolutePath(), retention);
                retention("egt.log.*", "/opt/mpc/egt/log", retention);
                retention("traffic.log.*", "/opt/mpc/egt/log", retention);
                //loggerLog.info("107 archive purge successful ");
                getLoggerLog().info("107 archive purge successful ");
            }
            catch (Exception ex)
            {
                //loggerLog.warn(ex.toString());
                //loggerLog.warn("300 archive purge failed");
                getLoggerLog().warn(ex.toString());
                getLoggerLog().warn("300 archive purge failed");
            }

            if (startmode_)
            {
                break;
            }

            try
            {
                long tmp = sleeptime * 60000;
                Thread.sleep(tmp);
            }
            catch (InterruptedException ex)
            {
                //loggerLog.fatal(ex.toString());
                //loggerLog.fatal("404 EGT unable to sleep");
                getLoggerLog().fatal(ex.toString());
                getLoggerLog().fatal("404 EGT unable to sleep");
                System.exit(2);
            }
        }

        //loggerLog.info("108 egt stop");
        getLoggerLog().info("108 egt stop");
    }

    /**
     * print build version  this function is use to display version  who exist in src/build.number  Exemple of
     * build.number file: #Mon 18 Feb 12:46:47 CEST 2007 build.number=R3.0-CP00-5331
     */
    private static void printBuildVersion()
    {
        Properties buildNumber = new Properties();

        try
        {
            buildNumber.load(CDRDir2log.class.getResourceAsStream("/build.number"));

            String buildVersion = buildNumber.getProperty("build.number", "no");
            System.out.print("EGT version: " + buildVersion);
        }
        catch (IOException e)
        {
            System.err.print("EGT : Cannot read build.number");
        }
    }

    /**
     * printCDR backup a file to a scpecific directory
     *
     * @param cDR print a CDR file reccord
     * @param sourcename DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    private static String printCDR(CDR cDR, String sourcename)
    {
        try
        {
            //loggertraffic.info(cDR.toLog(sourcename));
            getLoggerTraffic().info(cDR.toLog(sourcename));
        }
        catch (EgtException ex)
        {
            // TODO rien
        }

        return cDR.sourceName;
    }

    /**
     * decode backup a file to a scpecific directory
     *
     * @param filename ASN1 File to decode
     *
     * @return java.util.LinkedList the list of the CDR reccords
     *
     * @throws EgtException
     */
    private static java.util.LinkedList decode(String filename)
    throws EgtException
    {
        FileInputStream cdr_file = null;

        try
        {
            cdr_file = new FileInputStream(filename);
        }
        catch (Exception exception)
        {
            throw new EgtException(exception.toString());
        }

        PositionDataRecordDecoder mydr = new PositionDataRecordDecoder();
        java.util.LinkedList cdrs = mydr.decode(cdr_file);

        try
        {
            cdr_file.close();
        }
        catch (IOException e)
        {
            throw new EgtException(e.toString());
        }

        return cdrs;
    }

    /**
     * backup backup a file to a scpecific directory
     *
     * @param file File to backup
     * @param dir File directory where file is backup
     *
     * @return boolean true if action OK, false if KO
     */
    public static boolean backup(File file, File dir)
    {
        if (!dir.exists())
        {
            dir.mkdir();
        }

        boolean test = false;
        SimpleDateFormat dffile = new SimpleDateFormat("yyyyMMdd_HH-mm-ss");

        if (dir.isDirectory())
        {
            File newfile = new File(dir, file.getName() + "_" + dffile.format(new Date()));
            test = deplacer(file, newfile);

            // use deplacer instaead of rename to prevent disk of fs change.
            // test= file.renameTo(newfile);
        }

        return test;
    }

    /**
     * retention execute a find archivedir -name "FilePrefix" -mtime +Retention -exec rm {} \ ; command
     *
     * @param FilePrefix prefix of the file to delete
     * @param archivedir1 archive sourcedir (WARNING not full path) just archive dir in configuration file
     * @param Retention retention time number of day -1
     *
     * @throws Exception
     * @throws EgtException DOCUMENT ME!
     */
    static void retention(String FilePrefix, String archivedir1, int Retention)
    throws Exception
    {
        String s = null;
        // system command to run
        Retention = Retention - 1;

        // String cmd = "find " + archivedir + " -name '" + FilePrefix + "'
        // -mtime +" +
        // Retention + " -exec rm {} \\ ;";
        // Process p = Runtime.getRuntime().exec(cmd);
        Process p = Runtime.getRuntime()
                           .exec(new String[]
                                 {
                                     "/bin/sh", "-c",
                                     
        "find " + archivedir1 + " -name '" + FilePrefix + "' -mtime +" + Retention + " -exec rm {} \\;"
                                 });

        int i = p.waitFor();

        if (i != 0)
        {
            BufferedReader stdErr = new BufferedReader(new InputStreamReader(p.getErrorStream()));

            // read the output from the command
            String ErrorDetail = "Purge of " + FilePrefix + " file in " + archivedir1 + " diretory failed : ";

            while ((s = stdErr.readLine()) != null)
            {
                ErrorDetail = ErrorDetail + s + " ";
            }

            throw new EgtException(ErrorDetail);
        }
    }

    /**
     * copie le fichier source dans le fichier resultat
     *
     * @param source the source file
     * @param destination the destination directory
     *
     * @return boolean retourne vrai si cela r�ussit
     */
    public static boolean copier(File source, File destination)
    {
        boolean resultat = false;

        // Declaration des flux
        java.io.FileInputStream sourceFile = null;
        java.io.FileOutputStream destinationFile = null;

        try
        {
            // Cr�ation du fichier :
            destination.createNewFile();

            // Ouverture des flux
            sourceFile = new java.io.FileInputStream(source);
            destinationFile = new java.io.FileOutputStream(destination);

            // Lecture par segment de 0.5Mo
            byte[] buffer = new byte[512 * 1024];
            int nbLecture;

            while ((nbLecture = sourceFile.read(buffer)) != -1)
            {
                destinationFile.write(buffer, 0, nbLecture);
            }

            // Copie r�ussie
            resultat = true;
        }
        catch (Exception e)
        {
            //loggerLog.error("file backup copy " + e.toString());
            getLoggerLog().error("file backup copy " + e.toString());
        }
        finally
        {
            // Quoi qu'il arrive, on ferme les flux
            try
            {
                sourceFile.close();
            }
            catch (Exception e)
            {
                // TODO rien
            }

            try
            {
                destinationFile.close();
            }
            catch (Exception e)
            {
                // TODO rien
            }
        }

        return (resultat);
    }

    /**
     * DOCUMENT ME!
     *
     * @param source DOCUMENT ME!
     * @param destination DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public static boolean deplacer(File source, File destination)
    {
        if (!destination.exists())
        {
            // On essaye avec renameTo
            boolean result = source.renameTo(destination);

            if (!result)
            {
                // On essaye de copier
                result = true;
                result &= copier(source, destination);
                result &= source.delete();
            }

            return (result);
        }

        // Si le fichier destination existe, on annule ...
        return (false);
    }

    /**
     * validArg copie le fichier source dans le fichier resultat
     *
     * @param args les argument du programme
     *
     * @return boolean retourne vrai manual false si auto
     *
     * @throws EgtException
     */
    public static boolean validArg(String[] args) throws EgtException
    {
        if (args.length != 1)
        {
            throw new EgtException("com.ericsson.mps.egt.CDRDir2Log : illegal option " + "\r\nusage: egt.sh [0|1]");
        }

        try
        {
            switch (Integer.parseInt(args[0]))
            {
            case 0 :
                return true;

            case 1 :
                return false;

            default :
                throw new EgtException();
            }
        }
        catch (Exception ex)
        {
            throw new EgtException("com.ericsson.mps.egt.CDRDir2Log : illegal option " + "\r\nusage: egt.sh [0|1]");
        }
    }
}


/**
 * DOCUMENT ME!
 *
 * @author $author$
 * @version $Revision$
 */
class FileNameFilterImpl implements FilenameFilter
{
    /**
     * DOCUMENT ME!
     *
     * @param dir DOCUMENT ME!
     * @param name DOCUMENT ME!
     *
     * @return DOCUMENT ME!
     */
    public boolean accept(File dir, String name)
    {
        boolean flag = false;
        File file = new File(dir, name);

        if (file.isFile())
        {
            // modify regular expression to match beginning of line (^) and end
            // of line ($)
            // the (?m) makes ^ and $ match beginning and end of line (instead
            // of file)
            String regexp = "^Billing.*$";
            Pattern pattern = Pattern.compile(regexp);

            Matcher matcher = pattern.matcher(name);
            flag = matcher.find();
        }

        return flag;
    }
}
