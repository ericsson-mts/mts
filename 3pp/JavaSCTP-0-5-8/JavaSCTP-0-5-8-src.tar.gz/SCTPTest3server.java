//Performance test using OneToOne-style sockets
import dk.i1.sctp.*;
import java.net.*;
import java.util.*;
import java.net.*;

class SCTPTest3server {
	public static final void main(String[] argv) throws Exception {
		OneToOneSCTPSocket s = new OneToOneSCTPSocket();
		s.bind(4000);
		sctp_event_subscribe ses = new sctp_event_subscribe();
		ses.sctp_data_io_event = true;
		ses.sctp_association_event = true;
		s.subscribeEvents(ses);
		s.listen();
		Collection<InetAddress> col = s.getLocalInetAddresses();
		System.out.println("Server is listening on:");
		for(InetAddress ia : col)
			System.out.println(ia.toString());
		
		
		System.out.println("server: Doing accept() on server socket");
		OneToOneSCTPSocket c2 = s.accept();
		
		System.out.println("server: receiving 1000000 messages");
		for(int r=0; r<1000000; r++) {
			SCTPChunk chunk = c2.receive();
			assert ((SCTPData)chunk)!=null;
		}
		
		c2.close();
		
		s.close();
		System.out.println("server: finished");
	}
}
