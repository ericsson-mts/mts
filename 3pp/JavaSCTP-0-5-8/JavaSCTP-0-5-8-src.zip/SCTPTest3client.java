//Performance test using OneToOne-style sockets
import dk.i1.sctp.*;
import java.net.*;
import java.util.*;
import java.net.*;

class SCTPTest3client {
	public static final void main(String[] argv) throws Exception {
		OneToOneSCTPSocket c = new OneToOneSCTPSocket();
		c.bind();

		System.out.println("Client: connecting..\n");
		c.connect(InetAddress.getByName("10.0.0.249"),4000);
		
		System.out.println("Client: Sending 1000000 messages Client->Server");
		for(int r=0; r<1000000; r++) {
			byte[] d = new byte[1024];
			SCTPData data = new SCTPData(d);
			c.send(data);
		}
		System.out.println("Client: Done. Closing client socket");
		
		c.close();
	}
}
