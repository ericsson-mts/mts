//Simple test programa for OneToOne-style sockets
import dk.i1.sctp.*;
import java.net.*;
import java.util.*;
import java.net.*;

class SCTPTest2 {
	public static final void main(String[] argv) throws Exception {
		OneToOneSCTPSocket s = new OneToOneSCTPSocket();
		s.bind(4000);
		sctp_event_subscribe ses = new sctp_event_subscribe();
		ses.sctp_data_io_event = true;
		ses.sctp_association_event = true;
		s.subscribeEvents(ses);
		s.listen();
		Collection<InetAddress> col = s.getLocalInetAddresses();
		System.out.println("Server is listening on:");
		for(InetAddress ia : col)
			System.out.println(ia.toString());
		
		
		OneToOneSCTPSocket c = new OneToOneSCTPSocket();
		c.bind();
		c.connect(InetAddress.getByName("localhost"),4000);
		
		System.out.println("Doing accept() on server socket");
		OneToOneSCTPSocket c2 = s.accept();
		
		System.out.println("Sending 1000 messages Server->Client");
		for(int r=0; r<1000; r++) {
			//send a chunk from server to client
			SCTPData data = new SCTPData("Hello world".getBytes());
			c2.send(data);
			SCTPChunk chunk = c.receive();
			assert ((SCTPData)chunk)!=null;
			assert (new String(((SCTPData)chunk).getData())).equals("Hello world");
		}
		System.out.println("Sending 1000 messages Client->Server");
		for(int r=0; r<1000; r++) {
			SCTPData data = new SCTPData("Hello to you".getBytes());
			c.send(data);
			SCTPChunk chunk = c2.receive();
			assert ((SCTPData)chunk)!=null;
			assert (new String(((SCTPData)chunk).getData())).equals("Hello to you");
		}
		System.out.println("Done. Closing client socket");
		
		c.close();
		
		c2.close();
		
		s.close();
	}
}
