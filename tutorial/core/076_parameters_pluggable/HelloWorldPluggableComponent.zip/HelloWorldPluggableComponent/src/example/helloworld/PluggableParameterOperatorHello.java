/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package example.helloworld;

import com.devoteam.srit.xmlloader.core.Parameter;
import com.devoteam.srit.xmlloader.core.Runner;
import com.devoteam.srit.xmlloader.core.exception.ParameterException;
import com.devoteam.srit.xmlloader.core.operations.basic.operators.AbstractPluggableParameterOperator;
import com.devoteam.srit.xmlloader.core.pluggable.PluggableName;
import java.util.Map;

/**
 *
 * @author gpasquiers
 */
public class PluggableParameterOperatorHello extends AbstractPluggableParameterOperator
{

    public PluggableParameterOperatorHello()
    {
        // Set the name of this operator. An operator can have multiple names.
        // A name contains a "deprecated" flag and a priority too.
        // This simple constructor gives the minimal priority and a set the deprecated flag to false.
        this.addPluggableName(new PluggableName("sayhello"));
    }
    
    @Override
    public Parameter operate(Runner runner, Map<String, Parameter> parameters, String operatorName, String resultantName) throws ParameterException
    {
        // Try to read a parameter and throw a ParameterException if not present
        Parameter param = AbstractPluggableParameterOperator.assertAndGetParameter(parameters, "value");
        
        // Create the empty (for now) answer.
        Parameter res = new Parameter();
        
        int len = param.length();
        
        for(int i=0; i<len; i++)
        {
            // Fill the answer. Don't forget a parameter is an array.
            res.add("Hello, " + param.get(i));
        }
        
        return res;
    }

}
