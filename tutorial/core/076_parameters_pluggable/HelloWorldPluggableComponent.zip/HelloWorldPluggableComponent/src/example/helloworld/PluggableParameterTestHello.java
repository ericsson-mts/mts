/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package example.helloworld;

import com.devoteam.srit.xmlloader.core.Parameter;
import com.devoteam.srit.xmlloader.core.Runner;
import com.devoteam.srit.xmlloader.core.exception.AssertException;
import com.devoteam.srit.xmlloader.core.exception.ParameterException;
import com.devoteam.srit.xmlloader.core.operations.basic.operators.AbstractPluggableParameterOperator;
import com.devoteam.srit.xmlloader.core.operations.basic.tests.AbstractPluggableParameterTest;
import com.devoteam.srit.xmlloader.core.pluggable.PluggableName;
import java.util.Map;

/**
 *
 * @author gpasquiers
 */
public class PluggableParameterTestHello extends AbstractPluggableParameterTest
{

    public PluggableParameterTestHello()
    {
        // Set the name of this test. A test can have multiple names.
        // A name contains a "deprecated" flag and a priority too.
        // This simple constructor gives the minimal priority and a set the deprecated flag to false.
        this.addPluggableName(new PluggableName("sayshello"));
    }
    
    @Override
    public void test(Runner runner, Map<String, Parameter> parameters, String testName, String parameterName) throws AssertException, ParameterException
    {
        // The operation of normalizing parameters put all parameters to the same
        // size if possible. If it is not possible it throws a ParameterException.
        // This is the behaviour used in many operations of IMSLoader.
        AbstractPluggableParameterOperator.normalizeParameters(parameters);

        // Try to read a parameters and throw a ParameterException if they are
        // not present
        Parameter param = AbstractPluggableParameterOperator.assertAndGetParameter(parameters, "parameter");
        Parameter value = AbstractPluggableParameterOperator.assertAndGetParameter(parameters, "value");
        
        int len = param.length();
        
        for(int i=0; i<len; i++)
        {
            // Check that all parameter values start with "Hello ," and ends with
            // the content of the parameter value that should contain the "hello-ed"
            // names.
            // throw an assert exception ass soon as an error occurs.
            if(!param.get(i).toString().startsWith("Hello, ")&&
               !param.get(i).toString().endsWith(value.get(i).toString()))
            {
                throw new AssertException("parameter " + parameterName + " ("+ param + ") does not say \"Hello, \" to" + value);
            }
        }
    }
}
