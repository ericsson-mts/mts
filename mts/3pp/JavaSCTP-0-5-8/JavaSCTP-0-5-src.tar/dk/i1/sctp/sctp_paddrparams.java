package dk.i1.sctp;
import java.net.InetSocketAddress;

public class sctp_paddrparams {
	public AssociationId           spp_assoc_id;
	public InetSocketAddress       spp_address;
	public int                     spp_hbinterval;
	public short                   spp_pathmaxrxt;
	public int                     spp_pathmtu;
	public int                     spp_sackdelay;
	public int                     spp_flags;
	public int                     spp_ipv6_flowlabel;
	public byte                    spp_ipv4_tos;
	public static final int SPP_HB_ENABLE=1;
	public static final int SPP_HB_DISABLE=2;
	public static final int SPP_HB_DEMAND=4;
	public static final int SPP_HB_TIME_IS_ZERO=8;
	public static final int SPP_PMTUD_ENABLE=16;
	public static final int SPP_PMTUD_DISABLE=32;
	public static final int SPP_SACKDELAY_ENABLE=64;
	public static final int SPP_SACKDELAY_DISABLE=128;
	public static final int SPP_IPV6_FLOWLABEL=256;
	public static final int SPP_IPV4_TOS=512;
}
