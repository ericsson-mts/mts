gcc -o prf fr_sha1.c fips186prf.c
