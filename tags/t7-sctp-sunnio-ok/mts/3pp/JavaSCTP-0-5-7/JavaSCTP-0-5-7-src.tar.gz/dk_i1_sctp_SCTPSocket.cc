// Copyright (c) 2006 Ivan Skytte J�rgensen
// 
// This software is provided 'as-is', without any express or implied warranty.
// In no event will the authors be held liable for any damages arising from the
// use of this software.
// 
// Permission is granted to anyone to use this software for any purpose,
// including commercial applications, and to alter it and redistribute it
// freely, subject to the following restrictions:
// 
// 1. The origin of this software must not be misrepresented; you must not
//    claim that you wrote the original software. If you use this software
//    in a product, an acknowledgment in the product documentation would be
//    appreciated but is not required.
// 
// 2. Altered source versions must be plainly marked as such, and must not be
//    misrepresented as being the original software.
// 
// 3. This notice may not be removed or altered from any source distribution.

#include "dk_i1_sctp_SCTPSocket.h"
#include "dk_i1_sctp_sctp_sndrcvinfo.h"
#include "dk_i1_sctp_sctp_paddrparams.h"
#include "dk_i1_sctp_SCTPNotificationPeerAddressChange.h"
#include "dk_i1_sctp_OneToOneSCTPSocket.h"
#include <unistd.h>
#include <new>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <netinet/sctp.h>
#include <errno.h>
#include <pthread.h>

#if defined (__linux__)
#warning This file assumes lksctp 1.0.7+. If this is not the case then disable this #if
//The problem is that lksctp 1.0.7 has the necessary symbols but they are not
//#define'd so we cannot test for their presence
#define SCTP_ADAPTATION_INDICATION SCTP_ADAPTATION_INDICATION
#define SCTP_UNORDERED SCTP_UNORDERED
#define SCTP_ADDR_OVER SCTP_ADDR_OVER
#define SCTP_ABORT SCTP_ABORT
#define SCTP_EOF SCTP_EOF
#endif
#if defined(__linux__) || defined(__sun)
#ifndef SCTP_UNORDERED
#define SCTP_UNORDERED MSG_UNORDERED
#endif
#ifndef SCTP_ADDR_OVER
#define SCTP_ADDR_OVER MSG_ADDR_OVER
#endif
#ifndef SCTP_ABORT
#define SCTP_ABORT MSG_ABORT
#endif
#ifndef SCTP_EOF
#define SCTP_EOF MSG_EOF
#endif
#endif




//A very simple buffer for I/O
struct Buffer {
	char *buf;
	size_t bufbytes;
	size_t bufsize;
	Buffer() : buf(0), bufbytes(0), bufsize(0) {}
	~Buffer() { clear(); }
	Buffer(const Buffer &b)
	  : buf(0), bufbytes(0), bufsize(0)
	{
		*this = b;
	}
	Buffer& operator=(const Buffer &b) {
		if(this!=&b) {
			clear();
			reserve(b.bufbytes);
			memcpy(buf,b.buf,b.bufbytes);
			bufbytes=b.bufbytes;
		}
		return *this;
	}
	
	void clear() { delete[] buf; bufbytes=bufsize=0; buf=0; }
	void clear_reserve() { bufbytes=0; }
	bool empty() const { return bufbytes==0; }
	size_t spare() const { return bufsize-bufbytes; }
	void reserve(size_t extra) {
		if(bufbytes+extra>bufsize) {
			size_t new_bufsize=(bufbytes+extra+4095)&~4095;
			char *new_buf=new char[new_bufsize];
			memcpy(new_buf,buf,bufbytes);
			delete[] buf;
			buf=new_buf;
			bufsize=new_bufsize;
		}
	}
	char *end() { return buf+bufbytes; }
};



struct Impl {
	int fd;
	bool is_blocking;
	pthread_mutex_t mtx_close;
	int fd_pipe[2];
	Buffer in_buffer;
};



// Miscellaneous helper functions ---------------------------------------------

static void JNU_ThrowByName(JNIEnv *env, const char *name, const char *msg)
{
	jclass cls = env->FindClass(name);
	/* if cls is NULL, an exception has already been thrown */
	if (cls != NULL) {
		env->ThrowNew(cls, msg);
	}
	/* free the local ref */
	env->DeleteLocalRef(cls);
}


static Impl *getImpl(JNIEnv *env, jobject sctpsocket)
{
	static jfieldID fid = 0;
	if(fid==0) {
		/*Get a reference to obj's class */
		jclass cls = env->GetObjectClass(sctpsocket);
		/* Look for the instance field s in cls */
		fid = env->GetFieldID(cls, "impl", "J");
		if(!fid)
			return 0;
	}
	jlong impl = env->GetLongField(sctpsocket, fid);
	return (Impl*)(intptr_t)impl;
}

static void setImpl(JNIEnv *env, jobject sctpsocket, Impl *impl)
{
	static jfieldID fid = 0;
	if(fid==0) {
		/*Get a reference to obj's class */
		jclass cls = env->GetObjectClass(sctpsocket);
		/* Look for the instance field s in cls */
		fid = env->GetFieldID(cls, "impl", "J");
		if(!fid)
			return;
	}
	env->SetLongField(sctpsocket, fid, (jlong)(intptr_t)impl);
}


static jobject newInetAddress(JNIEnv *env, const void *addr, size_t bytes)
{
	jclass cls = env->FindClass("java/net/InetAddress");
	if(!cls)
		return 0;
	jmethodID mid = env->GetStaticMethodID(cls, "getByAddress", "([B)Ljava/net/InetAddress;");
	if(!mid)
		return 0;
	jbyteArray jaddr = env->NewByteArray(bytes);
	if(!jaddr)
		return 0;
	env->SetByteArrayRegion(jaddr,0,bytes,(jbyte*)addr);
	
	jobject obj = env->CallStaticObjectMethod(cls,mid,jaddr);
	
	env->DeleteLocalRef(jaddr);
	
	return obj;
}


class mlock {
	JNIEnv *env;
	jobject sctpsocket;
	bool in;
	mlock(const mlock &); //don't copy
	mlock& operator=(const mlock&); //don't copy
public:
	mlock(JNIEnv *env_, jobject sctpsocket_)
	  : env(env_), sctpsocket(sctpsocket_), in(false)
	  {}
	~mlock() { leave(); }
	bool enter() {
		if (env->MonitorEnter(sctpsocket) != JNI_OK) {
			JNU_ThrowByName(env,"java/lang/InternalError","env->MonitorEnter() failed on sctp socket");
			return false;
		}
		in = true;
		return true;
	}
	bool leave() {
		if(!in) return true;
		if (env->MonitorExit(sctpsocket) != JNI_OK) {
			JNU_ThrowByName(env,"java/lang/InternalError","env->MonitorLeave() failed on sctp socket");
			return false;
		}
		in = false;
		return true;
	}
};



//-----------------------------------------------------------------------------

static jclass    dk_i1_sctp_AssociationId__cls;
static jmethodID dk_i1_sctp_AssociationId__ctor;
static jfieldID  dk_i1_sctp_AssociationId__id;
static jclass    dk_i1_sctp_sctp_sndrcvinfo__cls;
static jmethodID dk_i1_sctp_sctp_sndrcvinfo__ctor;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_stream;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_ssn;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_flags;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_ppid;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_context;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_timetolive;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_tsn;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_cumtsn;
static jfieldID  dk_i1_sctp_sctp_sndrcvinfo__sinfo_assoc_id;
static jclass    dk_i1_sctp_SCTPData__cls;
static jmethodID dk_i1_sctp_SCTPData__ctor;
static jfieldID  dk_i1_sctp_SCTPData__sndrcvinfo;
static jfieldID  dk_i1_sctp_SCTPData__data;
static jclass    dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__cls;
static jmethodID dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__ctor;
static jclass    dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__cls;
static jmethodID dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__ctor;
static jclass    dk_i1_sctp_SCTPNotificationAssociationChangeRestart__cls;
static jmethodID dk_i1_sctp_SCTPNotificationAssociationChangeRestart__ctor;
static jclass    dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__cls;
static jmethodID dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__ctor;
static jclass    dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__cls;
static jmethodID dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__ctor;
static jclass    dk_i1_sctp_SCTPNotificationPeerAddressChange__cls;
static jmethodID dk_i1_sctp_SCTPNotificationPeerAddressChange__ctor;
static jclass    dk_i1_sctp_SCTPNotificationRemoteError__cls;
static jmethodID dk_i1_sctp_SCTPNotificationRemoteError__ctor;
static jclass    dk_i1_sctp_SCTPNotificationSendFailed__cls;
static jmethodID dk_i1_sctp_SCTPNotificationSendFailed__ctor;
static jclass    dk_i1_sctp_SCTPNotificationShutdownEvent__cls;
static jmethodID dk_i1_sctp_SCTPNotificationShutdownEvent__ctor;
static jclass    dk_i1_sctp_SCTPNotificationAdaptationIndication__cls;
static jmethodID dk_i1_sctp_SCTPNotificationAdaptationIndication__ctor;
static jclass    dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__cls;
static jmethodID dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__ctor;
static jclass    dk_i1_sctp_OneToOneSCTPSocket__cls;
static jmethodID dk_i1_sctp_OneToOneSCTPSocket__ctor;


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_init(JNIEnv *env, jclass /*cls*/)
{
	dk_i1_sctp_AssociationId__cls = env->FindClass("dk/i1/sctp/AssociationId");
	dk_i1_sctp_AssociationId__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_AssociationId__cls);
	dk_i1_sctp_AssociationId__ctor = env->GetMethodID(dk_i1_sctp_AssociationId__cls, "<init>", "(J)V");
	dk_i1_sctp_AssociationId__id = env->GetFieldID(dk_i1_sctp_AssociationId__cls, "id", "J");
	
	dk_i1_sctp_sctp_sndrcvinfo__cls = env->FindClass("dk/i1/sctp/sctp_sndrcvinfo");
	dk_i1_sctp_sctp_sndrcvinfo__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_sctp_sndrcvinfo__cls);
	dk_i1_sctp_sctp_sndrcvinfo__ctor = env->GetMethodID(dk_i1_sctp_sctp_sndrcvinfo__cls, "<init>", "()V");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_stream = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_stream", "S");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_ssn = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_ssn", "S");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_flags = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_flags", "S");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_ppid = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_ppid", "I");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_context = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_context", "I");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_timetolive = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_timetolive", "I");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_tsn = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_tsn", "I");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_cumtsn = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_cumtsn", "I");
	dk_i1_sctp_sctp_sndrcvinfo__sinfo_assoc_id = env->GetFieldID(dk_i1_sctp_sctp_sndrcvinfo__cls, "sinfo_assoc_id", "Ldk/i1/sctp/AssociationId;");
	
	dk_i1_sctp_SCTPData__cls = env->FindClass("dk/i1/sctp/SCTPData");
	dk_i1_sctp_SCTPData__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPData__cls);
	dk_i1_sctp_SCTPData__ctor = env->GetMethodID(dk_i1_sctp_SCTPData__cls, "<init>", "(Ldk/i1/sctp/sctp_sndrcvinfo;[B)V");
	dk_i1_sctp_SCTPData__sndrcvinfo = env->GetFieldID(dk_i1_sctp_SCTPData__cls, "sndrcvinfo", "Ldk/i1/sctp/sctp_sndrcvinfo;");
	dk_i1_sctp_SCTPData__data = env->GetFieldID(dk_i1_sctp_SCTPData__cls, "data", "[B");
	
	dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__cls = env->FindClass("dk/i1/sctp/SCTPNotificationAssociationChangeCommUp");
	dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__cls);
	dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__cls, "<init>", "(SSSSSSSJ)V");
	
	dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__cls = env->FindClass("dk/i1/sctp/SCTPNotificationAssociationChangeCommLost");
	dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__cls);
	dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__cls, "<init>", "(SSSSSSSJ)V");
	
	dk_i1_sctp_SCTPNotificationAssociationChangeRestart__cls = env->FindClass("dk/i1/sctp/SCTPNotificationAssociationChangeRestart");
	dk_i1_sctp_SCTPNotificationAssociationChangeRestart__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationAssociationChangeRestart__cls);
	dk_i1_sctp_SCTPNotificationAssociationChangeRestart__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationAssociationChangeRestart__cls, "<init>", "(SSSSSSSJ)V");
	
	dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__cls = env->FindClass("dk/i1/sctp/SCTPNotificationAssociationChangeShutdownComplete");
	dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__cls);
	dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__cls, "<init>", "(SSSSSSSJ)V");
	
	dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__cls = env->FindClass("dk/i1/sctp/SCTPNotificationAssociationChangeCantStartAssociation");
	dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__cls);
	dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__cls, "<init>", "(SSSSSSSJ)V");
	
	dk_i1_sctp_SCTPNotificationPeerAddressChange__cls = env->FindClass("dk/i1/sctp/SCTPNotificationPeerAddressChange");
	dk_i1_sctp_SCTPNotificationPeerAddressChange__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationPeerAddressChange__cls);
	dk_i1_sctp_SCTPNotificationPeerAddressChange__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationPeerAddressChange__cls, "<init>", "(S[BIIIJ)V");
	
	dk_i1_sctp_SCTPNotificationRemoteError__cls = env->FindClass("dk/i1/sctp/SCTPNotificationRemoteError");
	dk_i1_sctp_SCTPNotificationRemoteError__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationRemoteError__cls);
	dk_i1_sctp_SCTPNotificationRemoteError__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationRemoteError__cls, "<init>", "(SSJ)V");
	
	dk_i1_sctp_SCTPNotificationSendFailed__cls = env->FindClass("dk/i1/sctp/SCTPNotificationSendFailed");
	dk_i1_sctp_SCTPNotificationSendFailed__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationSendFailed__cls);
	dk_i1_sctp_SCTPNotificationSendFailed__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationSendFailed__cls, "<init>", "(SILdk/i1/sctp/sctp_sndrcvinfo;[B)V");
	
	dk_i1_sctp_SCTPNotificationShutdownEvent__cls = env->FindClass("dk/i1/sctp/SCTPNotificationShutdownEvent");
	dk_i1_sctp_SCTPNotificationShutdownEvent__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationShutdownEvent__cls);
	dk_i1_sctp_SCTPNotificationShutdownEvent__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationShutdownEvent__cls, "<init>", "(SJ)V");
	
	dk_i1_sctp_SCTPNotificationAdaptationIndication__cls = env->FindClass("dk/i1/sctp/SCTPNotificationAdaptationIndication");
	dk_i1_sctp_SCTPNotificationAdaptationIndication__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationAdaptationIndication__cls);
	dk_i1_sctp_SCTPNotificationAdaptationIndication__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationAdaptationIndication__cls, "<init>", "(SIJ)V");
	
	dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__cls = env->FindClass("dk/i1/sctp/SCTPNotificationPartialDeliveryEvent");
	dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__cls);
	dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__ctor = env->GetMethodID(dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__cls, "<init>", "(SIJ)V");
	
	dk_i1_sctp_OneToOneSCTPSocket__cls = env->FindClass("dk/i1/sctp/OneToOneSCTPSocket");
	dk_i1_sctp_OneToOneSCTPSocket__cls = (jclass)env->NewWeakGlobalRef(dk_i1_sctp_OneToOneSCTPSocket__cls);
	dk_i1_sctp_OneToOneSCTPSocket__ctor = env->GetMethodID(dk_i1_sctp_OneToOneSCTPSocket__cls, "<init>", "()V");
	
}


static jlong getAssociationId_id(JNIEnv *env, jobject aid) {
	return env->GetLongField(aid, dk_i1_sctp_AssociationId__id);
}

static jobject newAssociationId(JNIEnv *env, jlong aid) {
	return env->NewObject(dk_i1_sctp_AssociationId__cls, dk_i1_sctp_AssociationId__ctor, aid);
}


static jshort sinfo_flags_2_java(uint16_t sinfo_flags) {
	jshort rc=0;
	if(sinfo_flags&SCTP_UNORDERED)
		rc |= dk_i1_sctp_sctp_sndrcvinfo_SCTP_UNORDERED;
	if(sinfo_flags&SCTP_ADDR_OVER)
		rc |= dk_i1_sctp_sctp_sndrcvinfo_SCTP_ADDR_OVER;
	if(sinfo_flags&SCTP_ABORT)
		rc |= dk_i1_sctp_sctp_sndrcvinfo_SCTP_ABORT;
	if(sinfo_flags&SCTP_EOF)
		rc |= dk_i1_sctp_sctp_sndrcvinfo_SCTP_EOF;
#ifdef SCTP_SENDALL
	if(sinfo_flags&SCTP_SENDALL)
		rc |= dk_i1_sctp_sctp_sndrcvinfo_SCTP_SENDALL;
#endif
	return rc;
}

static uint16_t sinfo_flags_2_C(jshort sinfo_flags) {
	uint16_t rc=0;
	if(sinfo_flags&dk_i1_sctp_sctp_sndrcvinfo_SCTP_UNORDERED)
		rc |= SCTP_UNORDERED;
	if(sinfo_flags&dk_i1_sctp_sctp_sndrcvinfo_SCTP_ADDR_OVER)
		rc |= SCTP_ADDR_OVER;
	if(sinfo_flags&dk_i1_sctp_sctp_sndrcvinfo_SCTP_ABORT)
		rc |= SCTP_ABORT;
	if(sinfo_flags&dk_i1_sctp_sctp_sndrcvinfo_SCTP_EOF)
		rc |= SCTP_EOF;
#ifdef SCTP_SENDALL
	if(sinfo_flags&dk_i1_sctp_sctp_sndrcvinfo_SCTP_SENDALL)
		rc |= SCTP_SENDALL;
#endif
	return rc;
}

static jobject newSndRcvInfo(JNIEnv *env) {
	return env->NewObject(dk_i1_sctp_sctp_sndrcvinfo__cls, dk_i1_sctp_sctp_sndrcvinfo__ctor);
}

static jobject newSndRcvInfo(JNIEnv *env, const sctp_sndrcvinfo *sri) {
	jshort sinfo_flags = sinfo_flags_2_java(sri->sinfo_flags);
	
	jobject sndrcvinfo = newSndRcvInfo(env);
	if(!sndrcvinfo) return 0;
	env->SetShortField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_stream, sri->sinfo_stream);
	env->SetShortField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_ssn, sri->sinfo_ssn);
	env->SetShortField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_flags, sinfo_flags);
	env->SetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_ppid, sri->sinfo_ppid);
	env->SetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_context, sri->sinfo_context);
	env->SetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_timetolive, sri->sinfo_timetolive);
	env->SetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_tsn, sri->sinfo_tsn);
	env->SetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_cumtsn, sri->sinfo_cumtsn);
	jobject assoc_id = newAssociationId(env,sri->sinfo_assoc_id);
	env->SetObjectField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_assoc_id, assoc_id);
	return sndrcvinfo;
}

static jobject newSCTPData(JNIEnv *env, jobject sctp_sndrcvinfo, const void *data, size_t bytes)
{
	jbyteArray d = env->NewByteArray(bytes);
	if(!d) return 0;
	env->SetByteArrayRegion(d, 0, bytes, (jbyte*)data);
	return env->NewObject(dk_i1_sctp_SCTPData__cls, dk_i1_sctp_SCTPData__ctor, sctp_sndrcvinfo, d);
}

// static bool getSCTPData(JNIEnv *env, jobject sctpdata, jobject *sctp_sndrcvinfo, void **data, size_t *sz)
// {
// 	*sctp_sndrcvinfo = env->GetObjectField(sctpdata, dk_i1_sctp_SCTPData__sndrcvinfo);
// 	jobject d = env->GetObjectField(sctpdata, dk_i1_sctp_SCTPData__data);
// 	*sz = env->GetArrayLength((jarray)d);
// 	*data = env->GetPrimitiveArrayCritical((jarray)d,0);
// 	return true; //todo
// }


static jobject newSCTPNotificationAssociationChangeCommUp(JNIEnv *env,
                                                          jshort sn_flags,
                                                          jshort sac_type,
                                                          jshort sac_flags,
                                                          jshort sac_state,
                                                          jshort sac_error,
                                                          jshort sac_outbound_streams,
                                                          jshort sac_inbound_streams,
                                                          jlong sac_assoc_id
                                                         )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__cls, 
	                      dk_i1_sctp_SCTPNotificationAssociationChangeCommUp__ctor,
	                      sn_flags,
	                      sac_type,
	                      sac_flags,
	                      sac_state,
	                      sac_error,
	                      sac_outbound_streams,
	                      sac_inbound_streams,
	                      sac_assoc_id
	                     );
}

static jobject newSCTPNotificationAssociationChangeCommLost(JNIEnv *env,
                                                            jshort sn_flags,
                                                            jshort sac_type,
                                                            jshort sac_flags,
                                                            jshort sac_state,
                                                            jshort sac_error,
                                                            jshort sac_outbound_streams,
                                                            jshort sac_inbound_streams,
                                                            jlong sac_assoc_id
                                                           )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__cls, 
	                      dk_i1_sctp_SCTPNotificationAssociationChangeCommLost__ctor,
	                      sn_flags,
	                      sac_type,
	                      sac_flags,
	                      sac_state,
	                      sac_error,
	                      sac_outbound_streams,
	                      sac_inbound_streams,
	                      sac_assoc_id
	                     );
}

static jobject newSCTPNotificationAssociationChangeRestart(JNIEnv *env,
                                                           jshort sn_flags,
                                                           jshort sac_type,
                                                           jshort sac_flags,
                                                           jshort sac_state,
                                                           jshort sac_error,
                                                           jshort sac_outbound_streams,
                                                           jshort sac_inbound_streams,
                                                           jlong sac_assoc_id
                                                          )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationAssociationChangeRestart__cls, 
	                      dk_i1_sctp_SCTPNotificationAssociationChangeRestart__ctor,
	                      sn_flags,
	                      sac_type,
	                      sac_flags,
	                      sac_state,
	                      sac_error,
	                      sac_outbound_streams,
	                      sac_inbound_streams,
	                      sac_assoc_id
	                     );
}

static jobject newSCTPNotificationAssociationChangeShutdownComplete(JNIEnv *env,
                                                                    jshort sn_flags,
                                                                    jshort sac_type,
                                                                    jshort sac_flags,
                                                                    jshort sac_state,
                                                                    jshort sac_error,
                                                                    jshort sac_outbound_streams,
                                                                    jshort sac_inbound_streams,
                                                                    jlong sac_assoc_id
                                                                   )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__cls, 
	                      dk_i1_sctp_SCTPNotificationAssociationChangeShutdownComplete__ctor,
	                      sn_flags,
	                      sac_type,
	                      sac_flags,
	                      sac_state,
	                      sac_error,
	                      sac_outbound_streams,
	                      sac_inbound_streams,
	                      sac_assoc_id
	                     );
}

static jobject newSCTPNotificationAssociationChangeCantStartAssociation(JNIEnv *env,
                                                                        jshort sn_flags,
                                                                        jshort sac_type,
                                                                        jshort sac_flags,
                                                                        jshort sac_state,
                                                                        jshort sac_error,
                                                                        jshort sac_outbound_streams,
                                                                        jshort sac_inbound_streams,
                                                                        jlong sac_assoc_id
                                                                       )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__cls, 
	                      dk_i1_sctp_SCTPNotificationAssociationChangeCantStartAssociation__ctor,
	                      sn_flags,
	                      sac_type,
	                      sac_flags,
	                      sac_state,
	                      sac_error,
	                      sac_outbound_streams,
	                      sac_inbound_streams,
	                      sac_assoc_id
	                     );
}


static jobject newSCTPNotificationPeerAddressChange(JNIEnv *env,
                                                    jshort sn_flags,
                                                    size_t addr_len,
                                                    void *addr_raw,
                                                    jint port,
                                                    uint32_t spc_state,
                                                    jshort spc_error,
                                                    jlong spc_assoc_id)
{
	jint jstate;
	switch(spc_state) {
		case SCTP_ADDR_AVAILABLE:
			jstate = dk_i1_sctp_SCTPNotificationPeerAddressChange_SCTP_ADDR_AVAILABLE;
			break;
		case SCTP_ADDR_UNREACHABLE:
			jstate = dk_i1_sctp_SCTPNotificationPeerAddressChange_SCTP_ADDR_UNREACHABLE;
			break;
		case SCTP_ADDR_REMOVED:
			jstate = dk_i1_sctp_SCTPNotificationPeerAddressChange_SCTP_ADDR_REMOVED;
			break;
		case SCTP_ADDR_ADDED:
			jstate = dk_i1_sctp_SCTPNotificationPeerAddressChange_SCTP_ADDR_ADDED;
			break;
		case SCTP_ADDR_MADE_PRIM:
			jstate = dk_i1_sctp_SCTPNotificationPeerAddressChange_SCTP_ADDR_MADE_PRIM;
			break;
#ifdef SCTP_ADDR_CONFIRMED
		case SCTP_ADDR_CONFIRMED:
			jstate = dk_i1_sctp_SCTPNotificationPeerAddressChange_SCTP_ADDR_CONFIRMED;
			break;
#endif
		default:
			jstate = -1;
	}

	jbyteArray jaddr = env->NewByteArray(addr_len);
	if(!jaddr)
		return 0;
	env->SetByteArrayRegion(jaddr,0,addr_len,(jbyte*)addr_raw);

	jobject r = env->NewObject(dk_i1_sctp_SCTPNotificationPeerAddressChange__cls, 
	                           dk_i1_sctp_SCTPNotificationPeerAddressChange__ctor,
	                           sn_flags,
	                           jaddr,
	                           port,
	                           jstate,
	                           spc_error,
	                           spc_assoc_id);
	env->DeleteLocalRef(jaddr);
	return r;
}

static jobject newSCTPNotificationRemoteError(JNIEnv *env,
                                              jshort sn_flags,
                                              jshort sre_error,
                                              jlong sre_assoc_id
                                             )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationRemoteError__cls, 
	                      dk_i1_sctp_SCTPNotificationRemoteError__ctor,
	                      sn_flags,
	                      sre_error,
	                      sre_assoc_id
	                     );
}

static jobject newSCTPNotificationSendFailed(JNIEnv *env,
                                             jshort sn_flags,
                                             jint ssf_error,
                                             sctp_sndrcvinfo &ssf_info,
                                             jlong ssf_assoc_id,
                                             void *data,
                                             size_t data_len
                                            )
{
	jobject sndrcvinfo = newSndRcvInfo(env, &ssf_info);
	if(!sndrcvinfo) return 0;
	
	jbyteArray jdata = env->NewByteArray(data_len);
	if(!jdata)
		return 0;
	env->SetByteArrayRegion(jdata,0,data_len,(jbyte*)data);
	
	jobject r = env->NewObject(dk_i1_sctp_SCTPNotificationSendFailed__cls, 
	                           dk_i1_sctp_SCTPNotificationSendFailed__ctor,
	                           sn_flags,
	                           ssf_error,
	                           sndrcvinfo,
	                           jdata
	                          );
	env->DeleteLocalRef(jdata);
	return r;
}

static jobject newSCTPNotificationShutdownEvent(JNIEnv *env,
                                                jshort sn_flags,
                                                jlong sse_assoc_id
                                               )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationShutdownEvent__cls, 
	                      dk_i1_sctp_SCTPNotificationShutdownEvent__ctor,
	                      sn_flags,
	                      sse_assoc_id
	                     );
}

static jobject newSCTPNotificationAdaptationIndication(JNIEnv *env,
                                                       jshort sn_flags,
                                                       jint sai_adaptation_ind,
                                                       jlong sai_assoc_id
                                                       )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationAdaptationIndication__cls, 
	                      dk_i1_sctp_SCTPNotificationAdaptationIndication__ctor,
	                      sn_flags,
	                      sai_adaptation_ind,
	                      sai_assoc_id
	                     );
}

static jobject newSCTPNotificationPartialDeliveryEvent(JNIEnv *env,
                                                       jshort sn_flags,
                                                       jint pdapi_indication,
                                                       jlong pdapi_assoc_id
                                                       )
{
	return env->NewObject(dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__cls, 
	                      dk_i1_sctp_SCTPNotificationPartialDeliveryEvent__ctor,
	                      sn_flags,
	                      pdapi_indication,
	                      pdapi_assoc_id
	                     );
}



static jobject newOneToOneSCTPSocket(JNIEnv *env) {
	return env->NewObject(dk_i1_sctp_OneToOneSCTPSocket__cls, 
	                      dk_i1_sctp_OneToOneSCTPSocket__ctor);
}


//-----------------------------------------------------------------------------

JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_open(JNIEnv *env, jobject sctpsocket, jboolean one_to_many)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/BindException","Already open");
		return;
	}
	
	impl = new Impl;
	impl->fd=-1;
	impl->is_blocking = true;
	pthread_mutex_init(&impl->mtx_close,0);
	
	int fd;
	fd = socket(AF_INET6, one_to_many?SOCK_SEQPACKET:SOCK_STREAM, IPPROTO_SCTP);
	if(fd<0)
		fd = socket(AF_INET, one_to_many?SOCK_SEQPACKET:SOCK_STREAM, IPPROTO_SCTP);
	if(fd<0) {
		ml.leave();
		delete impl;
		JNU_ThrowByName(env,"java/net/BindException","SCTP not supported by kernel?");
		return;
	}
	impl->fd = fd;
	if(pipe(impl->fd_pipe)!=0) {
		ml.leave();
		close(impl->fd);
		delete impl;
		JNU_ThrowByName(env,"java/net/BindException","pipe() failed");
		return;
	}
	setImpl(env,sctpsocket,impl);
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_bind_1native(JNIEnv *env, jobject sctpsocket, jbyteArray address, jint port)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	
	Impl *impl = getImpl(env,sctpsocket);
	
	if(port<0 || port>=65536) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/BindException","Port outside [0..65535]");
		return;
	}
	
	int af;
	jint address_length = address?env->GetArrayLength(address):0;
	if(address_length==4)
		af = AF_INET;
	else
		af = AF_INET6;
	
	sockaddr_storage ss;
	socklen_t ssl;
	if(af==AF_INET) {
		sockaddr_in &sin=(sockaddr_in&)ss;
		memset(&sin,0,sizeof(sin));
		sin.sin_family = AF_INET;
		env->GetByteArrayRegion(address,0,4,(jbyte*)&sin.sin_addr);
		sin.sin_port = htons(port);
		ssl = sizeof(sin);
	} else {
		sockaddr_in6 &sin6=(sockaddr_in6&)ss;
		memset(&sin6,0,sizeof(sin6));
		sin6.sin6_family = AF_INET6;
		if(address)
			env->GetByteArrayRegion(address,0,16,(jbyte*)&sin6.sin6_addr);
		sin6.sin6_port = htons(port);
		ssl = sizeof(sin6);
	}
	if(bind(impl->fd,(sockaddr*)(void*)&ss,ssl)!=0) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/BindException","bind() failed");
		return;
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_subscribeEvents(JNIEnv * env, jobject sctpsocket,
                                                                  jboolean sctp_data_io_event,
                                                                  jboolean sctp_association_event,
                                                                  jboolean sctp_address_event,
                                                                  jboolean sctp_send_failure_event,
                                                                  jboolean sctp_peer_error_event,
                                                                  jboolean sctp_shutdown_event,
                                                                  jboolean sctp_partial_delivery_event,
                                                                  jboolean sctp_adaptation_layer_event)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	struct sctp_event_subscribe subscribe;
	memset(&subscribe, 0, sizeof(subscribe));
	subscribe.sctp_data_io_event = sctp_data_io_event==JNI_TRUE;
	subscribe.sctp_association_event = sctp_association_event==JNI_TRUE;
	subscribe.sctp_address_event = sctp_address_event==JNI_TRUE;
	subscribe.sctp_send_failure_event = sctp_send_failure_event==JNI_TRUE;
	subscribe.sctp_peer_error_event = sctp_peer_error_event==JNI_TRUE;
	subscribe.sctp_shutdown_event = sctp_shutdown_event==JNI_TRUE;
	subscribe.sctp_partial_delivery_event = sctp_partial_delivery_event==JNI_TRUE;
#ifdef SCTP_ADAPTATION_INDICATION
	subscribe.sctp_adaptation_layer_event = sctp_adaptation_layer_event==JNI_TRUE;
#else
	subscribe.sctp_adaption_layer_event = sctp_adaptation_layer_event==JNI_TRUE;
#endif
	
	if(setsockopt(impl->fd, IPPROTO_SCTP, SCTP_EVENTS, (char *)&subscribe, (socklen_t)sizeof(subscribe))==-1) {
		int save_errno = errno;
		ml.leave();
		char tmpmsg[512];
		sprintf(tmpmsg,"setsockopt() failed, errno=%d", save_errno);
		JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
		return;
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_configureAutoClose(JNIEnv *env, jobject sctpsocket, jint seconds)
{
	if(seconds<0) {
		JNU_ThrowByName(env,"java/lang/IllegalArgumentException","auto-close seconds must be >=0");
		return;
	}
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	int autoclose_timer=seconds;
	if(setsockopt(impl->fd, IPPROTO_SCTP, SCTP_AUTOCLOSE, (char*)&autoclose_timer, (socklen_t)sizeof(autoclose_timer))!=0) {
		int save_errno = errno;
		ml.leave();
		char tmpmsg[512];
		sprintf(tmpmsg,"setsockopt() failed, errno=%d", save_errno);
		JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
		return;
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_configureBlocking(JNIEnv *env, jobject sctpsocket, jboolean blocking)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl->fd>=0) {
		int fl = blocking?0:O_NONBLOCK;
		if(fcntl(impl->fd,F_SETFL,fl)!=0) {
			ml.leave();
			JNU_ThrowByName(env,"java/net/SocketException","fcntl() call failed");
			return;
		}
	}
	impl->is_blocking = blocking;
}


JNIEXPORT jboolean JNICALL Java_dk_i1_sctp_SCTPSocket_isBlocking(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return JNI_FALSE;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl)
		return impl->is_blocking;
	else
		return JNI_FALSE;
	
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_setSctpNoDelay(JNIEnv *env, jobject sctpsocket, jboolean on)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		int noNagle = on==JNI_FALSE ? 0 : 1;
		int rc = setsockopt(impl->fd, IPPROTO_SCTP, SCTP_NODELAY, (char*)&noNagle, sizeof(noNagle));
		if(rc!=0) {
			ml.leave();
			JNU_ThrowByName(env,"java/net/SocketException","setsockopt() call failed");
			return;
		}
	}
}
JNIEXPORT jboolean JNICALL Java_dk_i1_sctp_SCTPSocket_getSctpNoDelay(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return JNI_FALSE;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		int noNagle = 0;
		socklen_t sl=(socklen_t)sizeof(noNagle);
		int rc = getsockopt(impl->fd, IPPROTO_SCTP, SCTP_NODELAY, (char*)&noNagle, &sl);
		if(rc!=0) {
			ml.leave();
			JNU_ThrowByName(env,"java/net/SocketException","getsockopt() call failed");
			return JNI_FALSE;
		}
		return noNagle ? JNI_TRUE : JNI_FALSE;
	} else
		return JNI_FALSE;
}


JNIEXPORT jint JNICALL Java_dk_i1_sctp_SCTPSocket_getReceiveBufferSize(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return JNI_FALSE;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		int buffer_size = 0;
		socklen_t sl=(socklen_t)sizeof(buffer_size);
		int rc = getsockopt(impl->fd, IPPROTO_SCTP, SO_RCVBUF, (char*)&buffer_size, &sl);
		if(rc!=0) {
			ml.leave();
			JNU_ThrowByName(env,"java/net/SocketException","getsockopt(...SO_RCVBUF) call failed");
			return JNI_FALSE;
		}
		return buffer_size;
	} else
		return 0;
}

JNIEXPORT jint JNICALL Java_dk_i1_sctp_SCTPSocket_getSendBufferSize(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return JNI_FALSE;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		int buffer_size = 0;
		socklen_t sl=(socklen_t)sizeof(buffer_size);
		int rc = getsockopt(impl->fd, IPPROTO_SCTP, SO_SNDBUF, (char*)&buffer_size, &sl);
		if(rc!=0) {
			ml.leave();
			JNU_ThrowByName(env,"java/net/SocketException","getsockopt(...SO_SNDBUF) call failed");
			return JNI_FALSE;
		}
		return buffer_size;
	} else
		return 0;
}

JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_setReceiveBufferSize(JNIEnv *env, jobject sctpsocket, jint buffer_size)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		int size = buffer_size;
		int rc = setsockopt(impl->fd, IPPROTO_SCTP, SO_RCVBUF, (char*)&size, sizeof(size));
		if(rc!=0) {
			ml.leave();
			JNU_ThrowByName(env,"java/net/SocketException","setsockopt() call failed");
			return;
		}
	}
}

JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_setSendBufferSize(JNIEnv *env, jobject sctpsocket, jint buffer_size)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		int size = buffer_size;
		int rc = setsockopt(impl->fd, IPPROTO_SCTP, SO_SNDBUF, (char*)&size, sizeof(size));
		if(rc!=0) {
			ml.leave();
			JNU_ThrowByName(env,"java/net/SocketException","setsockopt() call failed");
			return;
		}
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_setPeerParameters_1native(JNIEnv *env, jobject sctpsocket,
                                                                            jlong spp_assoc_id,
                                                                            jbyteArray spp_address_raw,
                                                                            jint spp_address_port,
                                                                            jint spp_hbinterval,
                                                                            jshort spp_pathmaxrxt,
                                                                            jint spp_pathmtu,
                                                                            jint spp_sackdelay,
                                                                            jint spp_flags,
                                                                            jint spp_ipv6_flowlabel,
                                                                            jbyte spp_ipv4_tos)
{
	sctp_paddrparams spp;
	memset(&spp,0,sizeof(spp));
	spp.spp_hbinterval = spp_hbinterval;
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_HB_ENABLE) {
#if defined(SPP_HB_ENABLE)
		spp.spp_flags |= SPP_HB_ENABLE;
#elif defined(SPP_HB_ENABLED)
		spp.spp_flags |= SPP_HB_ENABLED;
#else
		//nothing - implicit
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_HB_DISABLE) {
#ifdef SPP_HB_DISABLE
		spp.spp_flags |= SPP_HB_DISABLE;
#else
		spp.spp_hbinterval = 0;
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_HB_DEMAND) {
#ifdef SPP_HB_DEMAND
		spp.spp_flags |= SPP_HB_DEMAND;
#else
		JNU_ThrowByName(env,"java/net/SocketException","SPP_HB_DEMAND is not supported");
		return;
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_HB_TIME_IS_ZERO) {
#ifdef SPP_HB_TIME_IS_ZERO
		spp.spp_flags |= SPP_HB_TIME_IS_ZERO;
#else
		//I don't get it....
#endif
	}
	
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_PMTUD_ENABLE) {
#ifdef SPP_PMTUD_ENABLE
		spp.spp_flags |= SPP_PMTUD_ENABLE;
#else
		//implicit
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_PMTUD_DISABLE) {
#ifdef SPP_PMTUD_DISABLE
		spp.spp_flags |= SPP_PMTUD_DISABLE;
#else
		spp.spp_pathmaxrxt = 0;
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_SACKDELAY_ENABLE) {
#ifdef SPP_SACKDELAY_ENABLE
		spp.spp_flags |= SPP_SACKDELAY_ENABLE;
#else
		//ignore it and hope for the best
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_SACKDELAY_DISABLE) {
#ifdef SPP_SACKDELAY_DISABLE
		spp.spp_flags |= SPP_SACKDELAY_DISABLE;
#else
		//ignore it and hope for the best
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_IPV6_FLOWLABEL) {
#ifdef SPP_IPV6_FLOWLABEL
		spp.spp_flags |= SPP_IPV6_FLOWLABEL;
#else
		JNU_ThrowByName(env,"java/net/SocketException","SPP_IPV6_FLOWLABEL is not supported");
		return;
#endif
	}
	if(spp_flags&dk_i1_sctp_sctp_paddrparams_SPP_IPV4_TOS) {
#ifdef SPP_IPV4_TOS
		spp.spp_flags |= SPP_IPV4_TOS;
#else
		JNU_ThrowByName(env,"java/net/SocketException","SPP_IPV4_TOS is not supported");
		return;
#endif
	}
	
	
	spp.spp_assoc_id = (sctp_assoc_t)spp_assoc_id;
	
	if(spp_address_raw) {
		if(env->GetArrayLength(spp_address_raw)==4) {
			sockaddr_in &sin=(sockaddr_in&)spp.spp_address;
			sin.sin_family = AF_INET;
			env->GetByteArrayRegion(spp_address_raw,0,4,(jbyte*)&sin.sin_addr);
			sin.sin_port = htons(spp_address_port);
		} else if(env->GetArrayLength(spp_address_raw)==16) {
			sockaddr_in6 &sin6 = (sockaddr_in6&)spp.spp_address;
			sin6.sin6_family = AF_INET6;
			env->GetByteArrayRegion(spp_address_raw,0,16,(jbyte*)&sin6.sin6_addr);
			sin6.sin6_port = htons(spp_address_port);
		} else {
			JNU_ThrowByName(env,"java/net/SocketException","Unknown address length in spp_address");
			return;
		}
	}
	
	spp.spp_pathmaxrxt = spp_pathmaxrxt;
#ifdef SPP_PMTUD_ENABLE
	spp.spp_pathmtu = spp_pathmtu;
#endif
#ifdef SPP_SACKDELAY_ENABLE
	spp.spp_sackdelay = spp_sackdelay;
#endif
#ifdef SPP_IPV6_FLOWLABEL
	spp.spp_ipv6_flowlabel = spp_ipv6_flowlabel;
#endif
#ifdef SPP_IPV4_TOS
	spp.spp_ipv4_tos = spp_ipv4_tos;
#endif
	
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	int rc = setsockopt(impl->fd,
	                    IPPROTO_SCTP,
	                    SCTP_PEER_ADDR_PARAMS,
	                    &spp,
	                    sizeof(spp));
	if(rc!=0) {
		int save_errno=errno;
		ml.leave();
		char tmpmsg[512];
		sprintf(tmpmsg,"setsockopt() failed, errno=%d", save_errno);
		JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
		return;
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_setInitMsg_1native(JNIEnv *env, jobject sctpsocket,
                                                                     jshort sinit_num_ostreams,
                                                                     jshort sinit_max_instreams,
                                                                     jshort sinit_max_attempts,
                                                                     jshort sinit_max_init_timeo)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	if(!impl || impl->fd<0) {
		JNU_ThrowByName(env,"java/net/SocketException","SCTP socket is closed");
		return;
	}
	
	sctp_initmsg im;
	memset(&im,0,sizeof(im));
	im.sinit_num_ostreams = sinit_num_ostreams;
	im.sinit_max_instreams = sinit_max_instreams;
	im.sinit_max_attempts = sinit_max_attempts;
	im.sinit_max_init_timeo = sinit_max_init_timeo;
	
	if(setsockopt(impl->fd, IPPROTO_SCTP, SCTP_INITMSG, (char *)&im, (socklen_t)sizeof(im))==-1) {
		int save_errno = errno;
		ml.leave();
		char tmpmsg[512];
		sprintf(tmpmsg,"setsockopt() failed, errno=%d", save_errno);
		JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
		return;
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_listen(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	if(listen(impl->fd,1)!=0) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/SocketException","listen() failed");
		return;
	}
}



JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_connect_1native(JNIEnv *env, jobject sctpsocket, jbyteArray addr, jint port)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	
	Impl *impl = getImpl(env,sctpsocket);
	
	jsize addr_bytes = env->GetArrayLength(addr);
	sockaddr_storage ss;
	socklen_t ssl;
	if(addr_bytes==4) {
		sockaddr_in &sin=(sockaddr_in&)ss;
		memset(&sin,0,sizeof(sin));
		sin.sin_family = AF_INET;
		env->GetByteArrayRegion(addr,0,4,(jbyte*)&sin.sin_addr);
		sin.sin_port = htons(port);
		ssl = sizeof(sin);
	} else {
		sockaddr_in6 &sin6=(sockaddr_in6&)ss;
		memset(&sin6,0,sizeof(sin6));
		sin6.sin6_family = AF_INET6;
		env->GetByteArrayRegion(addr,0,16,(jbyte*)&sin6.sin6_addr);
		sin6.sin6_port = htons(port);
		ssl = sizeof(sin6);
	}
	
	int rc = connect(impl->fd, (sockaddr*)(void*)&ss, ssl);
	if(rc!=0) {
		int save_errno=errno;
		if(impl->is_blocking || save_errno!=EINPROGRESS) {
			ml.leave();
			char tmpmsg[512];
			sprintf(tmpmsg,"connect() failed, errno=%d", save_errno);
			JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
			return;
		}
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_close(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	
	Impl *impl = getImpl(env,sctpsocket);
	if(impl) {
		setImpl(env,sctpsocket,0);
		pthread_mutex_lock(&impl->mtx_close);
		pthread_mutex_unlock(&impl->mtx_close);
		pthread_mutex_destroy(&impl->mtx_close);
		close(impl->fd);
		close(impl->fd_pipe[0]);
		close(impl->fd_pipe[1]);
		delete impl;
	}
}


JNIEXPORT jboolean JNICALL Java_dk_i1_sctp_SCTPSocket_isClosed(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return JNI_FALSE;
	
	Impl *impl = getImpl(env,sctpsocket);
	if(impl)
		return JNI_FALSE;
	else
		return JNI_TRUE;
}



static void transformAddresses2Collection(JNIEnv *env, jobject col, sockaddr *ss, int num_addrs)
{
	char *p=(char*)ss;
	for(int i=0; i<num_addrs; i++) {
		sockaddr_storage *ss=(sockaddr_storage*)(void*)p;
		jobject jaddr;
		if(ss->ss_family==AF_INET) {
			sockaddr_in *sin=(sockaddr_in*)(void*)ss;
			jaddr = newInetAddress(env,&sin->sin_addr,4);
			p+= sizeof(*sin);
		} else if(ss->ss_family==AF_INET6) {
			sockaddr_in6 *sin6=(sockaddr_in6*)(void*)ss;
			if(IN6_IS_ADDR_V4MAPPED(&sin6->sin6_addr))
				jaddr = newInetAddress(env,sin6->sin6_addr.s6_addr+12,4);
			else
				jaddr = newInetAddress(env,sin6->sin6_addr.s6_addr,16);
			p+= sizeof(*sin6);
		} else
			break;
		if(!jaddr)
			break;
		//add to collection
		jclass cls = env->GetObjectClass(col);
		if(!cls)
			break;
		jmethodID mid = env->GetMethodID(cls, "add", "(Ljava/lang/Object;)Z");
		if(!mid)
			break;
		env->CallBooleanMethod(col, mid, jaddr);
	}
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_getLocalInetAddresses_1native(JNIEnv *env, jobject sctpsocket, jobject col, jlong aid)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	struct sockaddr *ss=0;
#ifndef __sun
	int num_addrs = sctp_getladdrs(impl->fd, (sctp_assoc_t)aid, &ss);
#else
	int num_addrs = sctp_getladdrs(impl->fd, (sctp_assoc_t)aid, (void**)&ss);
#endif
	if(num_addrs<=0) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/SocketException","sctp_getladdrs() failed");
		return;
	}
	
	transformAddresses2Collection(env, col, ss, num_addrs);
	
	sctp_freeladdrs(ss);
}


JNIEXPORT jint JNICALL Java_dk_i1_sctp_SCTPSocket_getLocalInetPort(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return -1;
	Impl *impl = getImpl(env,sctpsocket);
	
	struct sockaddr *sa=0;
#ifndef __sun
	int num_addrs = sctp_getladdrs(impl->fd, 0, &sa);
#else
	int num_addrs = sctp_getladdrs(impl->fd, 0, (void**)&sa);
#endif
	if(num_addrs<=0) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/SocketException","sctp_getladdrs() failed");
		return -1;
	}
	
	//All the socket address will specify the same port, so we only examine the first
	int port;
	sockaddr_storage *ss=(sockaddr_storage*)sa;
	if(ss->ss_family==AF_INET) {
		sockaddr_in *sin=(sockaddr_in*)(void*)ss;
		port = ntohs(sin->sin_port);
	} else if(ss->ss_family==AF_INET6) {
		sockaddr_in6 *sin6=(sockaddr_in6*)(void*)ss;
		port = ntohs(sin6->sin6_port);
	} else {
		sctp_freeladdrs(sa);
		ml.leave();
		JNU_ThrowByName(env,"java/net/SocketException","sctp_getladdrs() returned unknown address family");
		return -1;
	}
	
	sctp_freeladdrs(sa);
	return port;
}


JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_getPeerInetAddresses_1native(JNIEnv *env, jobject sctpsocket, jobject col, jlong aid)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	struct sockaddr *ss=0;
#ifndef __sun
	int num_addrs = sctp_getpaddrs(impl->fd, (sctp_assoc_t)aid, &ss);
#else
	int num_addrs = sctp_getpaddrs(impl->fd, (sctp_assoc_t)aid, (void**)&ss);
#endif
	if(num_addrs<=0) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/SocketException","sctp_getpaddrs() failed");
		return;
	}
	
	transformAddresses2Collection(env, col, ss, num_addrs);
	
	sctp_freepaddrs(ss);
}


JNIEXPORT jint JNICALL Java_dk_i1_sctp_SCTPSocket_getPeerInetPort_1native(JNIEnv *env, jobject sctpsocket, jlong aid)
{
	jint port = 0;
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return 0;
	Impl *impl = getImpl(env,sctpsocket);
	
	struct sockaddr *ss=0;
#ifndef __sun
	int num_addrs = sctp_getpaddrs(impl->fd, (sctp_assoc_t)aid, &ss);
#else
	int num_addrs = sctp_getpaddrs(impl->fd, (sctp_assoc_t)aid, (void**)&ss);
#endif
	if(num_addrs<=0) {
		ml.leave();
		JNU_ThrowByName(env,"java/net/SocketException","sctp_getpaddrs() failed");
		return 0;
	}
	
	char *p=(char*)ss;
	for(int i=0; i<num_addrs; i++) {
		sockaddr_storage *ss=(sockaddr_storage*)(void*)p;
		if(ss->ss_family==AF_INET) {
			sockaddr_in *sin=(sockaddr_in*)(void*)ss;
			port = ntohs(sin->sin_port);
			break;
		} else if(ss->ss_family==AF_INET6) {
			sockaddr_in6 *sin6=(sockaddr_in6*)(void*)ss;
			port = ntohs(sin6->sin6_port);
			break;
		} else
			break;
	}

	sctp_freepaddrs(ss);
	
	return port;
}



JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_disconnect_1native(JNIEnv *env, jobject sctpsocket, jlong aid, jboolean gracefully)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	//Shut down association
	sctp_sndrcvinfo sri;
	memset(&sri,0,sizeof(sri));
	sri.sinfo_assoc_id = (sctp_assoc_t)aid;
	sri.sinfo_flags = gracefully ? SCTP_EOF : SCTP_ABORT;
	
	//this is not pretty...
	union {
		cmsghdr hdr;
		char _filler[sizeof(cmsghdr)+sizeof(sctp_sndrcvinfo)];
	} cmsg;
	struct msghdr hdr;
	struct iovec iov[1];
	memset(&hdr,0,sizeof(hdr));
	hdr.msg_name = 0;
	hdr.msg_namelen = 0;
	hdr.msg_iov = iov;
	hdr.msg_iovlen = 0;
	hdr.msg_control = &cmsg;
	hdr.msg_controllen = sizeof(cmsg);
	//hdr.msg_flags = 
	
	iov[0].iov_base = (void*)0;
	iov[0].iov_len = 0;
	
	cmsg.hdr.cmsg_len = sizeof(cmsg);
	cmsg.hdr.cmsg_level = IPPROTO_SCTP;
	cmsg.hdr.cmsg_type = SCTP_SNDRCV;
	memcpy((&cmsg.hdr)+1, &sri, sizeof(sri));
	
	ssize_t bytes_sent = sendmsg(impl->fd,
	                             &hdr,
	                             0); //flags
	if(bytes_sent!=0) {
		ml.leave();
		char tmpmgs[512];
		sprintf(tmpmgs,"sendmsg() failed while shutting down association to %ld, errno=%d", (long)aid, errno);
		JNU_ThrowByName(env,"java/net/SocketException",tmpmgs);
		return;
	}

}



JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_send_1native(JNIEnv *env, jobject sctpsocket, jbyteArray data, jobject sndrcvinfo)
{
	if(!sndrcvinfo) {
		JNU_ThrowByName(env,"java/lang/IllegalArgumentException","sndrcvinfo member in SCTPData must not be null when sending");
		return;
	}
	
	sctp_sndrcvinfo sri;
	memset(&sri,0,sizeof(sri));
	sri.sinfo_stream = env->GetShortField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_stream);
	sri.sinfo_ssn = env->GetShortField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_ssn);
	sri.sinfo_flags = sinfo_flags_2_C(env->GetShortField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_flags));
	sri.sinfo_ppid = env->GetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_ppid);
	sri.sinfo_context = env->GetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_context);
	sri.sinfo_timetolive = env->GetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_timetolive);
	sri.sinfo_tsn = env->GetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_tsn);
	sri.sinfo_cumtsn = env->GetIntField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_cumtsn);
	jobject assoc_id = env->GetObjectField(sndrcvinfo,dk_i1_sctp_sctp_sndrcvinfo__sinfo_assoc_id);
	sri.sinfo_assoc_id = (sctp_assoc_t)getAssociationId_id(env,assoc_id);
	
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	jsize raw_bytes = env->GetArrayLength(data);
	void *raw = env->GetPrimitiveArrayCritical(data,0);
	
	//this is not pretty...
	union {
		cmsghdr hdr;
		char _filler[sizeof(cmsghdr)+sizeof(sctp_sndrcvinfo)];
	} cmsg;
	struct msghdr hdr;
	struct iovec iov[1];
	memset(&hdr,0,sizeof(hdr));
	hdr.msg_name = 0;
	hdr.msg_namelen = 0;
	hdr.msg_iov = iov;
	hdr.msg_iovlen = 1;
	hdr.msg_control = &cmsg;
	hdr.msg_controllen = sizeof(cmsg);
	hdr.msg_flags = 0;
	
	iov[0].iov_base = (void*)raw;
	iov[0].iov_len = raw_bytes;
	
	cmsg.hdr.cmsg_len = sizeof(cmsg);
	cmsg.hdr.cmsg_level = IPPROTO_SCTP;
	cmsg.hdr.cmsg_type = SCTP_SNDRCV;
	memcpy((&cmsg.hdr)+1, &sri, sizeof(sri));
	
	ssize_t bytes_sent = sendmsg(impl->fd,
	                             &hdr,
	                             0); //flags
	int save_errno = errno;
	env->ReleasePrimitiveArrayCritical(data,raw,0);
	
	if((size_t)bytes_sent!=(size_t)raw_bytes) {
		ml.leave();
		if(save_errno==EAGAIN ||
		   save_errno==EWOULDBLOCK ||
		   save_errno==EINTR ||
		   save_errno==ENOBUFS ||
		   save_errno==ENOMEM ||
		   save_errno==ENOSR)
			JNU_ThrowByName(env,"java/net/WouldBlockException","sendmsg() system call would block");
		else {
			//severe problem
			char tmpmgs[512];
			sprintf(tmpmgs,"recvmsg() failed, errno=%d", save_errno);
			JNU_ThrowByName(env,"java/net/SocketException",tmpmgs);
		}
		return;
	}
}



static jobject processSCTPData(JNIEnv *env, msghdr &inmsghdr, const void *data, size_t bytes_received)
{
	//Find the sri (if any)
	sctp_sndrcvinfo *sri=0;
	for(struct cmsghdr *cmsgptr=CMSG_FIRSTHDR(&inmsghdr);
	    cmsgptr;
	    cmsgptr = CMSG_NXTHDR(&inmsghdr,cmsgptr)
	   )
	{
		if(cmsgptr->cmsg_level==IPPROTO_SCTP && cmsgptr->cmsg_type==SCTP_SNDRCV)
			sri = (sctp_sndrcvinfo*)CMSG_DATA(cmsgptr);
	}
	//create and fill out a sndrcvinfo object
	jobject sndrcvinfo = sri ? newSndRcvInfo(env, sri) : 0;
	
	return newSCTPData(env, sndrcvinfo, data, bytes_received);
}


static jobject processSCTPNotification(JNIEnv *env, msghdr &inmsghdr)
{
	sctp_notification *sn=(sctp_notification*)inmsghdr.msg_iov[0].iov_base;
	switch(sn->sn_header.sn_type) {
		case SCTP_ASSOC_CHANGE: {
			sctp_assoc_change *sac = &(sn->sn_assoc_change);
			switch(sac->sac_state) {
				case SCTP_COMM_UP:
					return newSCTPNotificationAssociationChangeCommUp(env,
					                                                  sn->sn_header.sn_flags,
					                                                  sac->sac_type,
					                                                  sac->sac_flags,
					                                                  sac->sac_state,
					                                                  sac->sac_error,
					                                                  sac->sac_outbound_streams,
					                                                  sac->sac_inbound_streams,
					                                                  sac->sac_assoc_id
					                                                 );
				case SCTP_COMM_LOST:
					return newSCTPNotificationAssociationChangeCommLost(env,
					                                                    sn->sn_header.sn_flags,
					                                                    sac->sac_type,
					                                                    sac->sac_flags,
					                                                    sac->sac_state,
					                                                    sac->sac_error,
					                                                    sac->sac_outbound_streams,
					                                                    sac->sac_inbound_streams,
					                                                    sac->sac_assoc_id
					                                                   );
				case SCTP_RESTART:
					return newSCTPNotificationAssociationChangeRestart(env,
					                                                   sn->sn_header.sn_flags,
					                                                   sac->sac_type,
					                                                   sac->sac_flags,
					                                                   sac->sac_state,
					                                                   sac->sac_error,
					                                                   sac->sac_outbound_streams,
					                                                   sac->sac_inbound_streams,
					                                                   sac->sac_assoc_id
					                                                  );
				case SCTP_SHUTDOWN_COMP:
					return newSCTPNotificationAssociationChangeShutdownComplete(env,
					                                                            sn->sn_header.sn_flags,
					                                                            sac->sac_type,
					                                                            sac->sac_flags,
					                                                            sac->sac_state,
					                                                            sac->sac_error,
					                                                            sac->sac_outbound_streams,
					                                                            sac->sac_inbound_streams,
					                                                            sac->sac_assoc_id
					                                                           );
				case SCTP_CANT_STR_ASSOC:
					return newSCTPNotificationAssociationChangeCantStartAssociation(env,
					                                                                sn->sn_header.sn_flags,
					                                                                sac->sac_type,
					                                                                sac->sac_flags,
					                                                                sac->sac_state,
					                                                                sac->sac_error,
					                                                                sac->sac_outbound_streams,
					                                                                sac->sac_inbound_streams,
					                                                                sac->sac_assoc_id
					                                                               );
				default:
					char tmpmsg[512];
					sprintf(tmpmsg,"Unknown association change sate, sac_state=%u, sac_assoc_id=%lu", (unsigned)sac->sac_state, (unsigned long)sac->sac_assoc_id);
					JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
					return 0;
			}
		}
		case SCTP_PEER_ADDR_CHANGE: {
			sctp_paddr_change *spc = (sctp_paddr_change*)&(sn->sn_paddr_change);
			if(spc->spc_aaddr.ss_family==AF_INET)
				return newSCTPNotificationPeerAddressChange(env,
				                                            sn->sn_header.sn_flags,
				                                            4,
				                                            &(((sockaddr_in&)spc->spc_aaddr).sin_addr),
				                                            ntohs(((sockaddr_in&)spc->spc_aaddr).sin_port),
				                                            spc->spc_state,
				                                            spc->spc_error,
				                                            spc->spc_assoc_id);
			else if(spc->spc_aaddr.ss_family==AF_INET6)
				return newSCTPNotificationPeerAddressChange(env,
				                                            sn->sn_header.sn_flags,
				                                            16,
				                                            &(((sockaddr_in6&)spc->spc_aaddr).sin6_addr),
				                                            ntohs(((sockaddr_in6&)spc->spc_aaddr).sin6_port),
				                                            spc->spc_state,
				                                            spc->spc_error,
				                                            spc->spc_assoc_id);
			else {
				char tmpmsg[512];
				sprintf(tmpmsg,"Unknown address family (%u) encountered in peer-addr-change for assoc_id=%lu", (unsigned)spc->spc_aaddr.ss_family, (unsigned long)spc->spc_assoc_id);
				JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
				return 0;
			}
		}
		case SCTP_REMOTE_ERROR: {
			sctp_remote_error *sre = (sctp_remote_error*)&(sn->sn_remote_error);
			return newSCTPNotificationRemoteError(env,
			                                      sn->sn_header.sn_flags,
							      sre->sre_error,
							      sre->sre_assoc_id
							     );
		}
		case SCTP_SEND_FAILED: {
			sctp_send_failed *ssf = (sctp_send_failed*)&(sn->sn_send_failed);
			return newSCTPNotificationSendFailed(env,
			                                     sn->sn_header.sn_flags,
							     ssf->ssf_error,
							     ssf->ssf_info,
							     ssf->ssf_assoc_id,
#ifndef __sun
							     ssf->ssf_data,
							     ssf->ssf_length-sizeof(*ssf)
#else
			                                     0,0
#endif
							    );
		}
		case SCTP_SHUTDOWN_EVENT: {
			sctp_shutdown_event *sse = (sctp_shutdown_event*)&(sn->sn_shutdown_event);
			return newSCTPNotificationShutdownEvent(env,
						                sn->sn_header.sn_flags,
						                sse->sse_assoc_id
						               );
		}
#ifdef SCTP_ADAPTATION_INDICATION
		case SCTP_ADAPTATION_INDICATION: {
			sctp_adaptation_event *sai = (sctp_adaptation_event*)&(sn->sn_adaptation_event);
			return newSCTPNotificationAdaptationIndication(env,
			                                               sn->sn_header.sn_flags,
			                                               sai->sai_adaptation_ind,
								       sai->sai_assoc_id);
		}
#else
		//drafts before 13 had "adaptation" ans "adaption"
		case SCTP_ADAPTION_INDICATION: {
			sctp_adaption_event *sai = (sctp_adaption_event*)&(sn->sn_adaption_event);
			return newSCTPNotificationAdaptationIndication(env,
			                                               sn->sn_header.sn_flags,
			                                               sai->sai_adaption_ind,
								       sai->sai_assoc_id);
		}
#endif
		case SCTP_PARTIAL_DELIVERY_EVENT: {
			sctp_pdapi_event *pdapi = (sctp_pdapi_event*)&(sn->sn_pdapi_event);
			return newSCTPNotificationPartialDeliveryEvent(env,
			                                               sn->sn_header.sn_flags,
			                                               pdapi->pdapi_indication,
								       pdapi->pdapi_assoc_id);
		}
		default: {
			char tmpmgs[512];
			sprintf(tmpmgs,"Unknown SCTP notification received, type=%u", sn->sn_header.sn_type);
			JNU_ThrowByName(env,"java/net/SocketException",tmpmgs);
			return 0;
		}
	}
}


JNIEXPORT jboolean JNICALL Java_dk_i1_sctp_SCTPSocket_chunkAvailable(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return 0;
	Impl *impl = getImpl(env,sctpsocket);
	
	pthread_mutex_lock(&impl->mtx_close);
	ml.leave();
	
	//because we don't want the actual message select() is probably more efficient than recvmsg(...MSG_PEEK)
	fd_set fds;
	FD_ZERO(&fds);
	FD_SET(impl->fd,&fds);
	timeval tv={0,0};
	int rc = select(impl->fd+1,&fds,0,0,&tv);
	pthread_mutex_unlock(&impl->mtx_close);
	
	if(rc<0) {
		//severe problem
		char tmpmgs[512];
		sprintf(tmpmgs,"select() failed, errno=%d", errno);
		JNU_ThrowByName(env,"java/net/SocketException",tmpmgs);
		return JNI_TRUE;
	}
	
	return rc==1 ? JNI_TRUE : JNI_FALSE;
}


JNIEXPORT jobject JNICALL Java_dk_i1_sctp_SCTPSocket_receive_1native(JNIEnv *env, jobject sctpsocket, jlong timeout)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return 0;
	Impl *impl = getImpl(env,sctpsocket);
	
	pthread_mutex_lock(&impl->mtx_close);
	ml.leave();
	
	fd_set fds;
	FD_ZERO(&fds);
	int maxfd = impl->fd>impl->fd_pipe[0]?impl->fd:impl->fd_pipe[0];
	FD_SET(impl->fd,&fds);
	FD_SET(impl->fd_pipe[0],&fds);
	
	Buffer &in_buffer = impl->in_buffer;
	jobject result = 0;
	for(;;) {
		fd_set fds_tmp = fds;
		timeval tv;
		timeval *tvp=0;
		if(timeout==0) {
			tvp = 0;
		} else if(timeout==-1) {
			tv.tv_sec=0;
			tv.tv_usec=0;
			tvp=&tv;
		} else {
			tv.tv_sec = (time_t)(timeout/1000);
			tv.tv_usec = (long)((timeout%1000)*1000);
			tvp = &tv;
		}
		int rc = select(maxfd+1,&fds_tmp,0,0,tvp);
		if(rc<0)
			continue;
		if(FD_ISSET(impl->fd_pipe[0],&fds_tmp)) {
			char buf;
			read(impl->fd_pipe[0],&buf,1);
			break;
		}
		if(!FD_ISSET(impl->fd,&fds_tmp)) {
			//Woke from select due to timeout
			if(in_buffer.empty())
				break;
		}
		in_buffer.reserve(4096);
		//now set up stuff for recvmsg()
		union {
			cmsghdr hdr;
			char _filler[sizeof(cmsghdr)+sizeof(sctp_sndrcvinfo)];
		} cmsg;
		
		iovec iniovec[1];
		iniovec[0].iov_base = in_buffer.buf+in_buffer.bufbytes;
		iniovec[0].iov_len = in_buffer.spare();
		
		sockaddr_storage ss; //solaris wants msg_name* set even though we don't need it
		
		msghdr inmsghdr;
		memset(&inmsghdr,0,sizeof(inmsghdr));
		inmsghdr.msg_name = &ss;
		inmsghdr.msg_namelen = sizeof(ss);
		inmsghdr.msg_iov = iniovec;
		inmsghdr.msg_iovlen = 1;
		inmsghdr.msg_control = &cmsg;
		inmsghdr.msg_controllen = sizeof(cmsg);
		inmsghdr.msg_flags = 0;
		
		ssize_t bytes_recv = recvmsg(impl->fd, &inmsghdr, 0);
		if(bytes_recv<0) {
			if(errno==EAGAIN ||
			   errno==EWOULDBLOCK ||
			   errno==EINTR ||
			   errno==ENOBUFS ||
			   errno==ENOMEM ||
			   errno==ENOSR)
			{
				//temporary problem
				if(in_buffer.bufbytes)
					; //just retry
				else {
					//Just return nul
					break;
				}
			} else {
				//severe problem
				char tmpmgs[512];
				sprintf(tmpmgs,"recvmsg() failed, errno=%d", errno);
				JNU_ThrowByName(env,"java/net/SocketException",tmpmgs);
				break;
			}
		}
		if(bytes_recv==0) {
			//Peer closed association only happens for one-to-one sockets.
			result = 0;
			break;
		}
		
		in_buffer.bufbytes += bytes_recv;
		if(inmsghdr.msg_flags&MSG_EOR) {
			//Complete message in data
			if(inmsghdr.msg_flags&MSG_NOTIFICATION) {
				result = processSCTPNotification(env,inmsghdr);
			} else {
				result = processSCTPData(env,inmsghdr,in_buffer.buf,in_buffer.bufbytes);
			}
			in_buffer.clear_reserve();
			break;
		}
	}
	pthread_mutex_unlock(&impl->mtx_close);
	return result;
}



JNIEXPORT void JNICALL Java_dk_i1_sctp_SCTPSocket_wakeup(JNIEnv *env, jobject sctpsocket)
{
	mlock ml(env,sctpsocket);
	if(!ml.enter())
		return;
	Impl *impl = getImpl(env,sctpsocket);
	
	if(impl->fd<0)
		return;
	
	char buf='d';
	write(impl->fd_pipe[1],&buf,1);
}



JNIEXPORT jobject JNICALL Java_dk_i1_sctp_OneToOneSCTPSocket_accept_1native(JNIEnv *env, jobject onetoonesctpsocket)
{
	mlock ml(env,onetoonesctpsocket);
	if(!ml.enter())
		return 0;
	Impl *impl = getImpl(env,onetoonesctpsocket);
	
	if(!impl || impl->fd<0) {
		JNU_ThrowByName(env,"java/net/SocketException","SCTP socket is closed");
		return 0;
	}
	
	int cfd = accept(impl->fd,0,0);
	if(cfd<0) {
		int save_errno = errno;
		ml.leave();
		char tmpmsg[512];
		sprintf(tmpmsg,"accept() failed, errno=%d", save_errno);
		JNU_ThrowByName(env,"java/net/SocketException",tmpmsg);
		return 0;
	}
	
	jobject new_socket = newOneToOneSCTPSocket(env);
	if(env->ExceptionCheck())
		return 0;
	
	Impl *new_impl = getImpl(env,new_socket);
	close(new_impl->fd);
	new_impl->fd = cfd;
	
	return new_socket;
}
