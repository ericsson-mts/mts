package dk.i1.diameter;
import dk.i1.diameter.*;

/**
 * A set of methods that can be helpful when doing Diameter Credit-Control (RFC4006)
 * Most of the methods are obvious and simple, but immensely useful.
 * The methods covers x areas:
<dl>
<dt>Unit-Value AVP (RFC4006 section 8.8)</dt><dd>
  constructUnitValueAVP(),
  makeUnitValueAVP(),
  extractUnitValue_ValueDigits(),
  convertUnitValueAVPToDouble()
</dd>
<dt>Cost-Information (RFC4006 section 8.7)</dt><dd>
  makeCostInformation(),
  extractCostInformation_UnitValue(),
  extractCostInformation_CurrencyCode(),
  extractCostInformation_CostUnit()
</dd>
<dt>Subscription-Id (RFC4006 section 8.46)</dt><dd>
  makeSubscriptionIdAVP(),
  extractSubscriptionId_Type(),
  extractSubscriptionId_Data(),
  extractSubscriptionId()
</dd>
<dt>Service-Parameter-* (RFC4006 section 8.43/44/45)</dt><dd>
  makeServiceParameterInfo(),
  extractServiceParameterInfo_Type(),
  extractServiceParameterInfo_Value(),
  extractServiceParameterInfo_Value_string()
</dl>
 * @since 0.9.7
 */
final public class DCCUtils {
	private DCCUtils() {} //stop javadoc from listing this.
	
	private static long pow10(int p) {
		long v=1;
		while((p--)!=0)
			v *= 10;
		return v;
	}
	
	/**A grouped AVP did not have a supported format**/
	public static class MalformedAVPException extends Exception {
		/**The AVP that did not have the correct size or content. This
		 *can later be wrapped into an Failed-AVP AVP. OR: an example
		 *AVP if the result-code is missing_avp */
		public AVP avp;
		/**Suggested result-code AVP value*/
		public int result_code;
		MalformedAVPException(AVP avp, int result_code) {
			this.avp = new AVP(avp);
			this.result_code = result_code;
		}
		MalformedAVPException(String message, AVP avp, int result_code) {
			super(message);
			this.avp = new AVP(avp);
			this.result_code = result_code;
		}
	}
	
	//methods dealing with Unit-Value AVP (section 8.8)
	
	/**
	 * Create a Unit-Value AVP.
	 * Creates a Unit-Value AVP as per RFC 4006 section 8.8
	 * The grouped avp is formed from the value digits and the exponent.
	 * If the exponent is zero then the exponent part is omitted.
	 * The value of the unit-value AVP will be interpreted as value_digits * 10^exponent
	 * @param value_digits the digits
	 * @param exponent
	 */
	public static final AVP_Grouped constructUnitValueAVP(long value_digits, int exponent) {
		if(exponent!=0)
			return new AVP_Grouped(ProtocolConstants.DI_UNIT_VALUE,
			                       new AVP[] {
			                           new AVP_Integer64(ProtocolConstants.DI_VALUE_DIGITS, value_digits),
			                           new AVP_Integer32(ProtocolConstants.DI_EXPONENT, exponent)
			                       }
			    );
		else
			return new AVP_Grouped(ProtocolConstants.DI_UNIT_VALUE,
			                       new AVP[] {
			                           new AVP_Integer64(ProtocolConstants.DI_VALUE_DIGITS, value_digits)
			                       }
			    );
	}
	
	/**
	 * Creates a Unit-Value AVP as per RFC 4006 section 8.8.
	 * The precision of the unit-value will be limited to the number of digits specified by precision, e.g.:
	 <pre>
	 {123.456; 0}  = 123
	 {123.456; 1}  = 120
	 {123.456; -2} = 123.46
	 </pre>
	 * After the precision has been limited the required exponent value
	 * will be calulated for the unit-value composition, wiz. the precision
	 * is not the exponent.
	 * The behaviour is unspecified if the value is not a number (NaN, INF, ..).
	 * @param value  A value. Must be a number.
	 * @param precision How many digits are important after (or before the comma).
	 */
	public static final AVP_Grouped makeUnitValueAVP(double value, int precision) {
		long value_digits;
		int exponent;
		if(precision>0) {
			long p10 = pow10(precision);
			//obvious:
			//  value_digits = (long)Math.round((value/p10);
			//  exponent = precision;
			//But he following does not lose precision, is easier to debug, and works with more peers
			value_digits = (long)Math.round(value/p10)*p10;
			exponent = 0;
		} else if(precision==0) {
			value_digits = Math.round(value);
			exponent = 0;
		} else { //if precision<0)
			long p10 = pow10(-precision);
			long v = (long)Math.round(value*p10);
			value_digits = v;
			exponent = -precision;
		}
		return constructUnitValueAVP(value_digits,exponent);
	}
	
	public static final AVP_Grouped makeUnitValueAVP(int value, int precision) {
		return constructUnitValueAVP(value,0);
	}
	public static final AVP_Grouped makeUnitValueAVP(long value, int precision) {
		return constructUnitValueAVP(value,0);
	}
	public static final AVP_Grouped makeUnitValueAVP(java.math.BigDecimal bd) {
		int scale=bd.scale();
		if(scale!=0)
			bd = bd.setScale(0);
		long l = bd.longValueExact();
		return makeUnitValueAVP(l,-scale);
	}
	
	private static final long extractUnitValue_ValueDigits(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<1)
			throw new MalformedAVPException("Unit-Value must contain at least one AVP",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[0].code!=ProtocolConstants.DI_VALUE_DIGITS)
			throw new MalformedAVPException("First AVP inside Unit-Value must be Value-Digits",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		long value_digits = new AVP_Integer64(avps[0]).queryValue();
		return value_digits;
	}
	private static final int extractUnitValue_Exponent(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<1)
			throw new MalformedAVPException("Unit-Value must contain at least one AVP",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[0].code!=ProtocolConstants.DI_VALUE_DIGITS)
			throw new MalformedAVPException("First AVP inside Unit-Value must be Value-Digits",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		int exponent;
		if(avps.length>=2 && avps[1].code==ProtocolConstants.DI_EXPONENT)
			exponent = new AVP_Integer32(avps[1]).queryValue();
		else
			exponent = 0;
		return exponent;
	}
	/**
	 *
	 */
	public static final double convertUnitValueAVPToDouble(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		long value_digits = extractUnitValue_ValueDigits(avpg);
		int exponent = extractUnitValue_Exponent(avpg);
		if(exponent>=0)
			return ((double)value_digits)*pow10(exponent);
		else
			return ((double)value_digits)/pow10(exponent);
	}
	public static final long convertUnitValueAVPToLong(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		long value_digits = extractUnitValue_ValueDigits(avpg);
		int exponent = extractUnitValue_Exponent(avpg);
		if(exponent>=0)
			return (value_digits)*pow10(exponent);
		else
			return (value_digits)/pow10(exponent);
	}
	
	public static final java.math.BigDecimal convertUnitValueToBigDecimal(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		long value_digits = extractUnitValue_ValueDigits(avpg);
		int exponent = extractUnitValue_Exponent(avpg);
		return new java.math.BigDecimal(java.math.BigInteger.valueOf(value_digits),-exponent);
	}
	
	//8.7 cost-information
	
	/**
	 * @param unit_value A Unit-Value AVP
	 * @param currency_code The currency code as per ISO 4217
	 * @param cost_unit  A string to be displayed to the user describing the cost. Can be null
	 */
	public static final AVP_Grouped makeCostInformation(AVP_Grouped unit_value, int currency_code, String cost_unit) {
		if(cost_unit != null)
			return new AVP_Grouped(ProtocolConstants.DI_COST_INFORMATION,
			                       new AVP [] {
			                           unit_value,
			                           new AVP_Integer32(ProtocolConstants.DI_CURRENCY_CODE,currency_code),
			                           new AVP_UTF8String(ProtocolConstants.DI_COST_UNIT,cost_unit)
			                       }
			                      );
		else
			return new AVP_Grouped(ProtocolConstants.DI_COST_INFORMATION,
			                       new AVP [] {
			                           unit_value,
			                           new AVP_Integer32(ProtocolConstants.DI_CURRENCY_CODE,currency_code)
			                       }
			                      );
	}
	/**
	 * Creates a Cost-Information AVP from BigDecimal+currency_code+cost_unit
	 * @param unit_value The cost
	 * @param currency_code The currency code as per ISO 4217
	 * @param cost_unit  A string to be displayed to the user describing the cost. Can be null
	 */
	public static final AVP_Grouped makeCostInformation(java.math.BigDecimal unit_value, int currency_code, String cost_unit) {
		return makeCostInformation(makeUnitValueAVP(unit_value),currency_code,cost_unit);
	}
	public static final AVP_Grouped makeCostInformation(double value, int precision, int currency_code, String cost_unit) {
		return makeCostInformation(makeUnitValueAVP(value,precision),currency_code,cost_unit);
	}
	public static final AVP_Grouped makeCostInformation(int value, int precision, int currency_code, String cost_unit) {
		return makeCostInformation(makeUnitValueAVP(value,precision),currency_code,cost_unit);
	}
	public static final AVP_Grouped makeCostInformation(long value, int precision, int currency_code, String cost_unit) {
		return makeCostInformation(makeUnitValueAVP(value,precision),currency_code,cost_unit);
	}
	
	/**
	 */
	public static final AVP_Grouped extractCostInformation_UnitValue(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<2)
			throw new MalformedAVPException("Cost-Information must contain at least 2 AVPs",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[0].code!=ProtocolConstants.DI_COST_INFORMATION)
			throw new MalformedAVPException("First AVP inside Cost-Information must be Unit-Value",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return new AVP_Grouped(avps[0]);
	}
	public static final int extractCostInformation_CurrencyCode(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<2)
			throw new MalformedAVPException("Cost-Information must contain at least 2 AVPs",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[1].code!=ProtocolConstants.DI_CURRENCY_CODE)
			throw new MalformedAVPException("Second AVP inside Cost-Information must be Unit-Value",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return new AVP_Integer32(avps[0]).queryValue();
	}
	public static final String extractCostInformation_CostUnit(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<3)
			return null;
		if(avps[3].code!=ProtocolConstants.DI_COST_INFORMATION)
			throw new MalformedAVPException("Third AVP inside Cost-Information must be Cost-Information",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return new AVP_UTF8String(avps[2]).queryValue();
	}

	//Methods for dealing with Subscription-Id (section 8.46)
	
	/**
	 * Create a Subscription-ID AVP.
	 * @param subscription_id_type  The type of the subscription (e.g. ProtocolConstants.END_USER_E164)
	 * @param  subscription_id_data 
	 * @return A Subscription-ID grouped AVP as per RFC 4006 section 8.46
	 */
	public static final AVP_Grouped makeSubscriptionIdAVP(int subscription_id_type, String subscription_id_data) {
		return new AVP_Grouped(ProtocolConstants.DI_SUBSCRIPTION_ID,
		                       new AVP[] {
		                           new AVP_Integer32(ProtocolConstants.DI_SUBSCRIPTION_ID_TYPE,subscription_id_type),
		                           new AVP_UTF8String(ProtocolConstants.DI_SUBSCRIPTION_ID_DATA,subscription_id_data)
		                       }
				      );
	}
	
	/**
	 * Extract Subscription-Id-Type from Subscription-ID AVP
	 * @return The subscription-id-type as an integer (e.g. ProtocolConstants.END_USER_E164)
	 */
	public static final int extractSubscriptionId_Type(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<2)
			throw new MalformedAVPException("Subscription-ID must contain 2 AVPs",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[0].code!=ProtocolConstants.DI_SUBSCRIPTION_ID_TYPE)
			throw new MalformedAVPException("First AVP inside Subscription-Id must be Subscription-Id-Type",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return new AVP_Integer32(avps[0]).queryValue();
	}
	
	/**
	 * Extract Subscription-Id-Data from Subscription-ID AVP
	 * @return The Subscription-Id-Data string
	 */
	public static final String extractSubscriptionId_Data(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<2)
			throw new MalformedAVPException("Subscription-ID must contain 2 AVPs",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[1].code!=ProtocolConstants.DI_SUBSCRIPTION_ID_DATA)
			throw new MalformedAVPException("Second AVP inside Subscription-Id must be Subscription-Id-Data",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return new AVP_UTF8String(avps[1]).queryValue();
	}
	
	/**
	 * Fetch the subscription-id value of the subscription-id with the desired subscription-id-type
	 * @return The Subscription-Id-Value. Or null if not found
	 */
	public static final String extractSubscriptionId(Message msg, int subscription_id_type) throws InvalidAVPLengthException, MalformedAVPException {
		for(AVP avp : msg.subset(ProtocolConstants.DI_SUBSCRIPTION_ID)) {
			AVP_Grouped avpg = new AVP_Grouped(avp);
			if(extractSubscriptionId_Type(avpg)==subscription_id_type)
				return extractSubscriptionId_Data(avpg);
		}
		return null;
	}
	
	
	// 8.43-8.45 Service-Parameter-*
	
	public static final AVP_Grouped makeServiceParameterInfo(AVP service_parameter_type, AVP service_parameter_value) {
		return new AVP_Grouped(ProtocolConstants.DI_SERVICE_PARAMETER_INFO,
		                       new AVP[] {
		                           service_parameter_type,
		                           service_parameter_value
		                       }
		                      );					   
	}
	public static final AVP_Grouped makeServiceParameterInfo(int service_parameter_type, byte[] service_parameter_value) {
		return makeServiceParameterInfo(new AVP_Unsigned32(ProtocolConstants.DI_SERVICE_PARAMETER_TYPE,service_parameter_type),
		                                new AVP_OctetString(ProtocolConstants.DI_SERVICE_PARAMETER_VALUE,service_parameter_value));
	}
	public static final AVP_Grouped makeServiceParameterInfo(int service_parameter_type, String service_parameter_value) {
		return makeServiceParameterInfo(new AVP_Unsigned32(ProtocolConstants.DI_SERVICE_PARAMETER_TYPE,service_parameter_type),
		                                new AVP_UTF8String(ProtocolConstants.DI_SERVICE_PARAMETER_VALUE,service_parameter_value));
	}
	
	public static final int extractServiceParameterInfo_Type(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<2)
			throw new MalformedAVPException("Service-Parameter-Info must contain 2 AVPs",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[0].code!=ProtocolConstants.DI_SERVICE_PARAMETER_TYPE)
			throw new MalformedAVPException("First AVP inside Service-Parameter-Info must be Service-Parameter-Type",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return new AVP_Integer32(avps[0]).queryValue();
	}
	/**
	 * Extract Service-Parameter-Value from Service-Parameter-Info AVP
	 * @return The Service-Parameter-Value byte[] value
	 */
	public static final byte[] extractServiceParameterInfo_Value(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<2)
			throw new MalformedAVPException("Service-Parameter-Info must contain 2 AVPs",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[1].code!=ProtocolConstants.DI_SERVICE_PARAMETER_VALUE)
			throw new MalformedAVPException("Second AVP inside Service-Parameter-Info must be Service-Parameter-Value",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return avps[1].queryPayload();
	}
	/**
	 * Extract Service-Parameter-Value from Service-Parameter-Info AVP as a string
	 * @return The Service-Parameter-Value value interpreted as an UTF8 string
	 */
	public static final String extractServiceParameterInfo_Value_string(AVP_Grouped avpg) throws InvalidAVPLengthException, MalformedAVPException {
		AVP[] avps = avpg.queryAVPs();
		if(avps.length<2)
			throw new MalformedAVPException("Service-Parameter-Info must contain 2 AVPs",avpg,ProtocolConstants.DIAMETER_RESULT_MISSING_AVP);
		if(avps[1].code!=ProtocolConstants.DI_SERVICE_PARAMETER_VALUE)
			throw new MalformedAVPException("Second AVP inside Service-Parameter-Info must be Service-Parameter-Value",avpg,ProtocolConstants.DIAMETER_RESULT_INVALID_AVP_VALUE);
		return new AVP_UTF8String(avps[1]).queryValue();
	}
	/**
	 * Fetch the service-parameter-value of the service-parameter-info with the desired service-parameter-type
	 * @return The Service-Parameter-Value. Or null if not found
	 */
	public static final byte[] extractServiceParameterInfo_Value(Message msg, int service_parameter_type) throws InvalidAVPLengthException, MalformedAVPException {
		for(AVP avp : msg.subset(ProtocolConstants.DI_SERVICE_PARAMETER_INFO)) {
			AVP_Grouped avpg = new AVP_Grouped(avp);
			if(extractServiceParameterInfo_Type(avpg)==service_parameter_type)
				return extractServiceParameterInfo_Value(avpg);
		}
		return null;
	}
}
